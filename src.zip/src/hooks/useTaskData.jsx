// src/hooks/useTaskData.jsx
"use client"; // Pastikan ini ada di baris paling atas

import { useState, useEffect, useCallback } from 'react';
import { message } from 'antd';
import axiosInstance from "@/utils/axios";
import dayjs from 'dayjs';
// Impor plugin dayjs esensial dan extend
import utc from 'dayjs/plugin/utc';
import timezone from 'dayjs/plugin/timezone';
import customParseFormat from 'dayjs/plugin/customParseFormat';
import relativeTime from 'dayjs/plugin/relativeTime';
import { getStorageUrl } from "@/utils/storageHelpers"; // <-- tambahan: builder URL via /api/file

// Extend dayjs dengan plugin yang diperlukan
dayjs.extend(utc);
dayjs.extend(timezone);
dayjs.extend(customParseFormat);
dayjs.extend(relativeTime);


export const useTaskData = (taskId, form) => {
    const [taskData, setTaskData] = useState(null);
    const [projectOptions, setProjectOptions] = useState([]);
    const [quotationOptions, setQuotationOptions] = useState([]);
    const [poOptions, setPoOptions] = useState([]);
    const [departmentOptions, setDepartmentOptions] = useState([]);
    const [userOptions, setUserOptions] = useState([]);
    const [listTaskAttachment, setListTaskAttachment] = useState([]);
    const [listSubTask, setListSubTask] = useState([]);
    const [listSubTaskItem, setListSubTaskItem] = useState([]);
    const [loadingData, setLoadingData] = useState(false);

    const [loadingProjects, setLoadingProjects] = useState(false);
    const [loadingQuotations, setLoadingQuotations] = useState(false);
    const [loadingPOs, setLoadingPOs] = useState(false);
    const [loadingDepartments, setLoadingDepartments] = useState(false);
    const [loadingUsers, setLoadingUsers] = useState(false);

    // State untuk Activity Log
    const [activityLog, setActivityLog] = useState([]);
    const [loadingActivity, setLoadingActivity] = useState(false);


    const handleApiError = useCallback((error, action) => {
        console.error(`Error ${action}:`, error.response || error.request || error.message);
        message.error(`${action} failed: ${error.response?.data?.error || error.message || 'Unknown error'}`);
    }, []);

    // --- HELPER fetchData DI SINI (Internal ke useTaskData) ---
    // fetchData hanya meneruskan respons API mentah ke setter
    const fetchData = useCallback(async (apiCall, setter, errorMessage, setLoadingState = null) => {
        if (setLoadingState) setLoadingState(true);
        try {
            const response = await apiCall();
            if (response.status === 200 || response.status === 201) {
                if (response.data) {
                    setter(response.data); // Meneruskan respons API mentah langsung ke setter
                }
                return response.data;
            } else {
                console.error(`Failed with status: ${response.status}`, response.data);
                message.error(`${errorMessage} Failed with status: ${response.status}`);
            }
        } catch (error) {
            handleApiError(error, errorMessage);
        } finally {
            if (setLoadingState) setLoadingState(false);
        }
        return null;
    }, [handleApiError]);
    // --- AKHIR HELPER fetchData ---


    const fetchDetailTask = useCallback(async () => {
        if (!taskId) return;
        setLoadingData(true);
        try {
            const response = await axiosInstance.get(`/task/${taskId}`);
            if (response.status === 200 || response.status === 201) {
                const task = response.data?.detailTask;
                setTaskData(task);
                // Mengembalikan ini ke versi yang sesuai dengan data mentah API
                setProjectOptions(response.data?.project || []);
                setQuotationOptions(response.data?.quotation || []);
                setPoOptions(response.data?.po || []);
                setListSubTask(task?.SubTasks || []);
                setListSubTaskItem(task?.SubtaskItems || []);
                setListTaskAttachment(response.data?.taskAttachment || []);

                form.setFieldsValue({
                    title: task?.title,
                    description: task?.description,
                    projectId: task?.project_id,
                    pq_id: task?.pq_id,
                    po_id: task?.po_id,
                    startDate: task?.start_date ? dayjs.unix(task.start_date) : null,
                    endDate: task?.end_date ? dayjs.unix(task.end_date) : null,
                    allottedTime: task?.allotted_time ? dayjs(task.allotted_time, 'HH:mm:ss') : null,
                });
            } else {
                console.error("Failed to fetch task detail with status:", response.status);
                message.error("Failed to load task details.");
            }
        } catch (error) {
            handleApiError(error, "fetching task detail");
        } finally {
            setLoadingData(false);
        }
    }, [taskId, handleApiError]);



    const fetchActivityLog = useCallback(async () => {
        if (!taskId) return;
        setLoadingActivity(true);
        try {
            const commentsResponse = await axiosInstance.get(`/task/${taskId}/comment`);
            const comments = commentsResponse.data?.comments.map(c => ({
                comment_id: c.comment_id,
                type: c.type || 'comment',
                creator: c.creator,
                mentioned: c.mentioned,
                content: c.comment,
                created: dayjs(c.created_at).unix(),
                comment_for: c.comment_for,
                mentioned_user_ids: c.mentioned_user_ids,
                filename: c.filename,
                task_title: taskData?.title,
            })) || [];

            const uploadsAsActivities = listTaskAttachment.map(att => ({
                id: `upload-${att.attachment_id}`,
                type: 'upload',
                user: att.created_by,
                real_filename: att.real_filename,
                created: att.created,
                task_title: taskData?.title,
            }));

            const allActivities = [...comments, ...uploadsAsActivities].sort((a, b) => (b.created || 0) - (a.created || 0));
            setActivityLog(allActivities || []);

        } catch (error) {
            setLoadingActivity(false);
            handleApiError(error, "Failed to fetch activity log.");
        } finally {
            setLoadingActivity(false);
        }
    }, [taskId, handleApiError]);

    // ===== Helper lokal untuk deteksi & normalisasi nama/ekstensi =====
    const IMG_EXTS = new Set(["png", "jpg", "jpeg", "webp", "gif", "bmp", "svg", "tif", "tiff"]);
    const getExt = (name = "") => {
        const m = String(name).toLowerCase().match(/\.([a-z0-9]+)$/i);
        return m ? m[1] : "";
    };
    const stripExt = (name = "") => String(name).replace(/\.[^.]+$/, "");

    /**
     * getFileDisplay
     * - Kompatibel mundur: boleh dipanggil dengan (filepath, filetype) [legacy],
     *   atau langsung dengan objek attachment (disarankan).
     * - Semua URL dibangun via /api/file menggunakan getStorageUrl(...).
     *   * Image  → preview gunakan resized webp: storage/task/resized/<basename>.webp
     *   * Non-img → unduh via storage/task/<filename>
     */
    const getFileDisplay = useCallback((arg1, arg2) => {
        // Normalisasi input
        let att;
        if (arg1 && typeof arg1 === "object" && !arg2) {
            // Pola baru: getFileDisplay(attachmentObject)
            att = arg1;
        } else {
            // Pola lama: getFileDisplay(filepath, filetype)
            att = { filepath: arg1, filetype: arg2 };
        }

        const realName = String(att?.real_filename || "").trim();
        const storedName = String(att?.filename || "").trim();
        const baseNameForDetect = realName || storedName; // deteksi tipe pakai nama file
        const ext = (getExt(baseNameForDetect) || (att?.filetype?.split("/")?.pop?.() || "file")).toUpperCase();

        const isImage = baseNameForDetect
            ? IMG_EXTS.has(getExt(baseNameForDetect).toLowerCase())
            : (att?.filetype ? String(att.filetype).startsWith("image/") : false);

        // Bangun URL final via /api/file (aman):
        // - Jika ada filename dari server (model baru), gunakan itu sebagai sumber kebenaran.
        // - Jika tidak ada, fallback ke filepath lama (akan dipetakan oleh getStorageUrl).
        let href = null;
        if (storedName) {
            if (isImage) {
                // Preview pakai resized .webp
                const base = stripExt(storedName);
                href = getStorageUrl(`storage/task/resized/${base}.webp`);
            } else {
                // Non-image: langsung ke file fisik via gateway /api/file
                href = getStorageUrl(`storage/task/${storedName}`);
            }
        } else if (att?.filepath) {
            // Legacy fallback: map apa adanya ke gateway
            href = getStorageUrl(att.filepath);
        }

        return {
            isImage,
            extension: ext,
            filepath: href, // komponen lama masih baca 'filepath' → kita isi dengan URL /api/file
        };
    }, []);

    const fetchDepartment = useCallback(async () => {
        await fetchData(
            () => axiosInstance.get(`/department`),
            (data) => {
                const options = (data.departments || []).map(d => ({
                    value: d.department_id,
                    label: d.title,
                }));
                setDepartmentOptions(options);
            },
            "Failed to fetch departments.",
            setLoadingDepartments
        );
    }, [fetchData]);

    const fetchUsers = useCallback(async () => {
        await fetchData(
            () => axiosInstance.get(`/user`),
            (data) => {
                setUserOptions(data.data || []);
            },
            "Failed to fetch users.",
            setLoadingUsers
        );
    }, [fetchData]);

    const fetchQuotation = useCallback(async (projectId) => {
        if (!projectId) { setQuotationOptions([]); setPoOptions([]); return; }
        await fetchData(
            () => axiosInstance.get(`/project/${projectId}/quotation`),
            (data) => {
                setQuotationOptions(data.data || []); // <-- Kembali ke data mentah
            },
            "Failed to fetch quotations.",
            setLoadingQuotations
        );
    }, [fetchData]);

    const fetchPo = useCallback(async (qtId) => {
        if (!qtId) { setPoOptions([]); return; }
        await fetchData(
            () => axiosInstance.get(`/project/${form.getFieldValue('projectId')}/quotation/${qtId}/po`),
            (data) => {
                setPoOptions(data.poDoc || []); // <-- Kembali ke data mentah
            },
            "Failed to fetch PO numbers.",
            setLoadingPOs,
        );
    }, [fetchData, form]);

    const fetchProject = useCallback(async () => {
        await fetchData(
            () => axiosInstance.get(`/project`),
            (data) => {
                setProjectOptions(data.data || []); // <-- Kembali ke data mentah
            },
            "Failed to fetch projects.",
            setLoadingProjects,
        );
    }, [fetchData]);

    useEffect(() => {
        if (taskId) {
            fetchDetailTask();
            fetchActivityLog();
        }
    }, [taskId, fetchDetailTask, fetchActivityLog]);

    return {
        form, taskData, projectOptions, quotationOptions, poOptions, departmentOptions, userOptions,
        listTaskAttachment, listSubTask, listSubTaskItem, loadingData, loadingProjects, loadingQuotations,
        loadingPOs, loadingDepartments, loadingUsers,
        activityLog, loadingActivity,
        fetchDetailTask, fetchDepartment, fetchUsers,
        fetchQuotation, fetchPo, fetchProject, setListTaskAttachment, setListSubTask, setListSubTaskItem, setTaskData,
        fetchActivityLog, setActivityLog, getFileDisplay
    };
};
