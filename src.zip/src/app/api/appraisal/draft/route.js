// src/app/api/appraisal/draft/route.js
export const dynamic = "force-dynamic";
export const revalidate = 0;

import { NextResponse } from "next/server";
import db from "@/database/models";
import { withActive } from "@/utils/session";
import {
  nowUnix,
  isTrue,
  getStaffIdField,
  getDepartmentIdField,
  RATING_SCALE,
  buildEmptyAnswers,
} from "../_helper";

const { Appraisal, MasterAppraisalQuestion, User, UserEmployment } = db;

const DEFAULT_TITLE = "Performance Appraisal (Probation Period)";

async function buildQuestionsSnapshot(title) {
  const rows = await MasterAppraisalQuestion.findAll({
    where: {
      deleted: null,
      deleted_by: null,
      is_active: "true",
      ...(title ? { title } : {}),
    },
    order: [
      ["sort_order", "ASC"],
      ["question_id", "ASC"],
    ],
    raw: true,
  });

  return (rows || []).map((q) => ({
    question_id: q.question_id,
    title: q.question_title,   // yang tampil
    description: q.description,
    sort_order: q.sort_order,
    master_title: q.title,     // judul template
  }));
}

async function loadLatestEmployment(userId) {
  const row = await UserEmployment.findOne({
    where: { user_id: userId, deleted: null },
    order: [["employment_id", "DESC"]],
    raw: true,
  });
  return row || null;
}

export const GET = withActive(async function GET_HANDLER(req, ctx, currentUser) {
  try {
    const { searchParams } = new URL(req.url);

    const staffIdField = getStaffIdField();
    const deptField = getDepartmentIdField();

    const title = (searchParams.get("title") || DEFAULT_TITLE).trim();
    const staffIdParam = searchParams.get("staffId"); // superadmin boleh generate untuk user lain
    const myId = Number(currentUser?.user_id);

    const targetStaffId = staffIdParam ? Number(staffIdParam) : myId;
    if (!Number.isFinite(targetStaffId)) {
      return NextResponse.json({ error: "Invalid staffId" }, { status: 400 });
    }

    if (!isTrue(currentUser?.is_superadmin) && targetStaffId !== myId) {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    }

    // cari draft
    let row = await Appraisal.findOne({
      where: {
        [staffIdField]: targetStaffId,
        title,
        status: "draft",
        deleted: null,
        deleted_by: null,
      },
      order: [["appraisal_id", "DESC"]],
    });

    if (row) {
      return NextResponse.json({ ok: true, data: row }, { status: 200 });
    }

    // create draft
    const staff = await User.findOne({
      where: { user_id: targetStaffId, deleted: null, deleted_by: null },
      raw: true,
    });

    if (!staff) {
      return NextResponse.json({ error: "User not found" }, { status: 404 });
    }

    const questions = await buildQuestionsSnapshot(title);
    const answers = buildEmptyAnswers(questions);
    const employment = await loadLatestEmployment(targetStaffId);

    const now = nowUnix();
    const actorId = myId;

    const payload = {
      title,

      [staffIdField]: targetStaffId,
      ...(deptField ? { [deptField]: staff.department_id ?? null } : {}),

      status: "draft",
      current_step: "staff",
      submitted_at: null,

      staff_snapshot_json: {
        user_id: staff.user_id,
        fullname: staff.fullname ?? null,
        email: staff.email ?? null,
        phone: staff.phone ?? null,
        job_position: staff.job_position ?? null,
        department_id: staff.department_id ?? null,
        user_type: staff.user_type ?? null,
      },

      employment_snapshot_json: {
        user_type: staff.user_type ?? null,
        employment: employment,
        before_status: null,
        after_status: null,
      },

      rating_scale_json: RATING_SCALE,
      questions_json: questions,
      answers_json: answers,

      total_score: 0,
      average_score: 0,
      grade: "E",
      scoring_json: {
        rule: { A: 4.1, B: 3.0, C: 2.0, D: 1.1, E: 0 },
        total_score: 0,
        average_score: 0,
        grade: "E",
        note: null,
      },

      approvals_json: {
        history: [],
        hod: null,
        hrd: null,
        director: null,
        superadmin: null,
      },

      general_comment: null,

      created: now,
      created_by: actorId,
      updated: now,
      updated_by: actorId,
      deleted: null,
      deleted_by: null,
    };

    row = await Appraisal.create(payload);

    return NextResponse.json({ ok: true, data: row }, { status: 200 });
  } catch (error) {
    console.error("GET /api/appraisal/draft error:", error);
    return NextResponse.json(
      { error: error?.message || "Failed to create draft." },
      { status: 500 }
    );
  }
});
