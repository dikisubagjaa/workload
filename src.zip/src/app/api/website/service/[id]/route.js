import { Service, sequelize } from "@/database/models/website";
import { getUnixTimestampUTC } from "@/utils/dateHelpers";
import { withAuth } from "@/utils/session";

export async function GET(_, { params }) {
    try {
        await sequelize.sync();
        const service = await Service.findByPk(params.id);
        if (!service) {
            return Response.json({ message: 'Not found' }, { status: 404 });
        }
        return Response.json(service);
    } catch (error) {
        console.error('❌ GET /service/:id error:', error);
        return new Response(
            JSON.stringify({ message: 'Failed to get service', error: error.message }),
            { status: 500 }
        );
    }
}

export const PUT = withAuth(async function PUT_HANDLER(req, { params }, currentUser) {
    try {
        await sequelize.sync();
        const body = await req.json();
        const service = await Service.findByPk(params.id);
        if (!service) {
            return Response.json({ message: 'Not found' }, { status: 404 });
        }
        
        const nowUnix = getUnixTimestampUTC();
        await service.update({
            ...body,
            updated: nowUnix,
            updated_by: currentUser.user_id
        });

        return Response.json({ message: 'Updated' });
    } catch (error) {
        console.error('❌ PUT /service/:id error:', error);
        return new Response(
            JSON.stringify({ message: 'Failed to update service', error: error.message }),
            { status: 500 }
        );
    }
});

export const DELETE = withAuth(async function DELETE_HANDLER(req, { params }, currentUser) {
    try {
        await sequelize.sync();

        const service = await Service.findByPk(params.id);
        if (!service) {
            return Response.json({ message: 'Not found' }, { status: 404 });
        }

        const nowUnix = getUnixTimestampUTC();
        await Service.update(
            {
                deleted: nowUnix,
                deleted_by: currentUser.user_id
            },
            { where: { service_id: params.id } }
        );

        return Response.json({ message: 'Soft deleted' });
    } catch (error) {
        console.error('❌ DELETE /service/:id error:', error);
        return new Response(
            JSON.stringify({ message: 'Failed to delete service', error: error.message }),
            { status: 500 }
        );
    }
});

