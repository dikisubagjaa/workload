export const dynamic = "force-dynamic";
export const revalidate = 0;

import { NextResponse } from "next/server";
import db from "@/database/models";
import { withActive } from "@/utils/session";

const { MasterAnnualAssesmentQuestion } = db;

function safeParseOptions(val) {
  try {
    if (!val) return null;
    return JSON.parse(val);
  } catch (e) {
    return null;
  }
}

export const GET = withActive(async function GET_HANDLER(req, ctx, currentUser) {
  try {
    const rows = await MasterAnnualAssesmentQuestion.findAll({
      where: { is_active: 1 },
      order: [
        ["section_key", "ASC"],
        ["sort_order", "ASC"],
        ["question_id", "ASC"],
      ],
    });

    const data = rows.map((r) => {
      const x = r.toJSON();
      // options_json disimpan TEXT (string JSON)
      x.options = safeParseOptions(x.options_json);
      return x;
    });

    return NextResponse.json({ data }, { status: 200 });
  } catch (error) {
    console.error("GET /annual-assestment/questions error:", error);
    return NextResponse.json(
      { error: error?.message || "Internal error" },
      { status: 500 }
    );
  }
});
