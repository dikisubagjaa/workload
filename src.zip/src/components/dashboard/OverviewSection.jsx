"use client";
import { Dropdown, Button, Card } from "antd";
import { PlusOutlined } from "@ant-design/icons";
export default function OverviewSection({
  onAddPitch,
  onAddProject,
  onAddTask,
  session
}) {
  const buttons = session?.user?.menu?.buttons || [];
  const collectPaths = (buttons) => {
    let paths = [];
    for (const p of buttons) {
      if (p.path) paths.push(p.path);
      if (p.children) paths = paths.concat(collectPaths(p.children));
    }
    return paths;
  };

  const allPaths = collectPaths(buttons);
  return (
    <section className='mb-4'>
      <div className="flex items-center">
        <h3 className='fc-base text-lg me-auto'>Overview</h3>

        {/* Mobile dropdown */}
        <div className='flex gap-x-2 items-center sm:hidden'>
          <Dropdown
            placement='bottomRight'
            trigger="click"
            menu={{
              items: [
                allPaths.includes("add_pitching") && {
                  key: '1',
                  icon: <PlusOutlined />,
                  label: (<button onClick={onAddPitch}>Add Pitch</button>)
                },
                allPaths.includes("add_project") && {
                  key: '2',
                  icon: <PlusOutlined />,
                  label: (<button onClick={onAddProject}>Add Project</button>)
                },
                allPaths.includes("add_task") && {
                  key: '3',
                  icon: <PlusOutlined />,
                  label: (<button onClick={onAddTask}>Add Task</button>)
                },
              ].filter(Boolean) // buang null/false
            }}
          >
            <Button type="primary" className='btn-blue-filled px-5' icon={<PlusOutlined />}>
              Add
            </Button>
          </Dropdown>
        </div>

        {/* Desktop buttons */}
        <div className='hidden sm:flex gap-2'>
          {allPaths.includes("add_pitching") && <Button onClick={onAddPitch} type="primary" className='btn-blue-filled px-5' icon={<PlusOutlined />}>Add Pitch</Button>}
          {allPaths.includes("add_project") && <Button onClick={onAddProject} type="primary" className='btn-blue-filled px-5' icon={<PlusOutlined />}>Add Project</Button>}
          {allPaths.includes("add_task") && <Button onClick={onAddTask} type="primary" className='btn-blue-filled px-5' icon={<PlusOutlined />}>Add Task</Button>}
        </div>
      </div>
    </section>
  );
}
