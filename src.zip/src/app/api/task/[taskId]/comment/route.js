export const dynamic = 'force-dynamic';
export const revalidate = 0;

import { NextResponse } from 'next/server';
import { TaskComment, User, TaskAttachment } from "@/database/models";
import dayjs from 'dayjs';
import utc from 'dayjs/plugin/utc';
import { getUnixTimestampUTC } from "@/utils/dateHelpers";
dayjs.extend(utc);

import { withAuth } from "@/utils/session";
import { notify as notifyUser } from '@/utils/notifier';
import { buildModalUrl } from '@/utils/url';

// ===== Utils kecil =====
const toInt = (v) => {
  const n = Number(v);
  return Number.isFinite(n) ? n : null;
};

const normalizeIdArray = (val) => {
  if (!val) return [];
  if (Array.isArray(val)) return val.map(toInt).filter(Number.isFinite);
  if (typeof val === 'string') {
    try {
      const parsed = JSON.parse(val);
      if (Array.isArray(parsed)) return parsed.map(toInt).filter(Number.isFinite);
    } catch { /* ignore */ }
    const one = toInt(val);
    return Number.isFinite(one) ? [one] : [];
  }
  const one = toInt(val);
  return Number.isFinite(one) ? [one] : [];
};

const safeUnix = (v) => {
  const n = Number(v);
  if (Number.isFinite(n) && n > 1_000_000_000) return n;
  const d = v ? new Date(v) : new Date();
  return Math.floor(d.getTime() / 1000);
};

// ===== POST: tambah komentar =====
export const POST = withAuth(async function POST_HANDLER(req, { params }, currentUser) {
  try {
    const { taskId } = params;
    const body = await req.json();
    const {
      content,
      comment_for,
      mentioned_user_ids,
      mentioned_attachment_ids, // ⬅️ baru
      filename,
      type
    } = body || {};

    if (!content || content.trim() === '') {
      return NextResponse.json({ error: "Comment content cannot be empty." }, { status: 400 });
    }

    const resolvedUserIds = normalizeIdArray(mentioned_user_ids);
    const resolvedFileIds = normalizeIdArray(mentioned_attachment_ids);

    const nowUnix = getUnixTimestampUTC();
    const newComment = await TaskComment.create({
      task_id: taskId,
      user_id: currentUser.user_id || null,
      comment: content.trim(),
      comment_for: comment_for || null,
      mentioned_user_ids: resolvedUserIds.length ? resolvedUserIds : null,
      mentioned_attachment_ids: resolvedFileIds.length ? resolvedFileIds : null, // ⬅️ simpan ID file
      filename: filename || null,
      type: type || 'comment',
      created: nowUnix,
      created_by: currentUser.user_id,
      updated: nowUnix,
      updated_by: currentUser.user_id,
    });

    // kirim notifikasi ke user yang di-mention (non-blocking)
    try {
      if (resolvedUserIds.length > 0) {
        const commentId = Number(newComment?.id ?? newComment?.comment_id);
        const url = buildModalUrl({
          module: 'task',
          id: Number(taskId),
          commentId,
          basePath: '/dashboard',
        });
        const preview = String(content).slice(0, 180);

        await Promise.all(
          resolvedUserIds.map((uid) =>
            notifyUser({
              userId: uid,
              sender: 'task',
              description: 'You were mentioned in a task comment',
              email: true,
              url: url,
              payload: { taskId: Number(taskId), commentId, preview },
            })
          )
        );
      }
    } catch (e) {
      console.warn('Mention notify failed (non-blocking):', e?.message || e);
    }

    return NextResponse.json(
      { message: "Comment added successfully!", comment: newComment.toJSON() },
      { status: 201 }
    );
  } catch (error) {
    console.error("Error adding comment:", error);
    return NextResponse.json(
      { error: error.original?.sqlMessage || error.message || "An error occurred while adding the comment." },
      { status: 500 }
    );
  }
});

// ===== GET: list komentar + mapping mention user & file =====
export async function GET(req, { params }) {
  try {
    const { taskId } = params;

    const comments = await TaskComment.findAll({
      include: [{ model: User, as: 'creator' }],
      where: { task_id: taskId },
      order: [['created', 'ASC']],
    });

    // Jadikan plain JSON dulu
    const raw = comments.map(c => c.toJSON());

    // Kumpulkan semua ID mention (sekali, biar gak N+1)
    const allIds = new Set();
    const allFileIds = new Set(); // ⬅️ tambahan utk attachment

    raw.forEach(c => {
      // ---------- USER MENTIONS ----------
      let ids = c.mentioned_user_ids;

      // Normalisasi: string JSON → array
      if (typeof ids === 'string') {
        try { ids = JSON.parse(ids || '[]'); } catch { ids = []; }
      }
      if (!Array.isArray(ids)) ids = [];

      // Simpan kembali dalam bentuk angka yang bersih
      const numericIds = ids
        .map(x => Number(x))
        .filter(n => Number.isFinite(n));

      c.mention_user_ids = numericIds; // (mengikuti penamaanmu)
      numericIds.forEach(id => allIds.add(id));

      // ---------- FILE MENTIONS (tambahan) ----------
      let fileIds = c.mentioned_attachment_ids;
      if (typeof fileIds === 'string') {
        try { fileIds = JSON.parse(fileIds || '[]'); } catch { fileIds = []; }
      }
      if (!Array.isArray(fileIds)) fileIds = [];

      const numericFileIds = fileIds
        .map(x => Number(x))
        .filter(n => Number.isFinite(n));

      c.mention_attachment_ids = numericFileIds; // simpan normalized utk dipakai di payload
      numericFileIds.forEach(id => allFileIds.add(id));
    });

    // Ambil data user untuk semua mention
    let userMap = new Map();
    if (allIds.size > 0) {
      const users = await User.findAll({
        where: { user_id: Array.from(allIds) },
        attributes: ['user_id', 'uuid', 'fullname', 'email', 'profile_pic'],
      });
      userMap = new Map(users.map(u => [Number(u.user_id), u.toJSON()]));
    }

    // Ambil data attachment untuk semua mention (tambahan)
    let fileMap = new Map();
    if (allFileIds.size > 0) {
      const files = await TaskAttachment.findAll({
        where: { attachment_id: Array.from(allFileIds) },
        attributes: ['attachment_id', 'real_filename', 'filename'],
      });
      fileMap = new Map(files.map(f => [Number(f.attachment_id), f.toJSON()]));
    }

    // Ganti kolom mention_user_ids menjadi array user object
    // + tambahkan mentioned_attachments dari fileMap (baru)
    const payload = raw.map(c => ({
      ...c,
      mentioned: (c.mention_user_ids || [])
        .map(id => userMap.get(id))
        .filter(Boolean),

      // ⬇️ tambahan: daftar file yang di-mention
      mentioned_attachments: (c.mention_attachment_ids || [])
        .map(id => {
          const o = fileMap.get(id);
          if (!o) return null;
          return {
            attachment_id: o.attachment_id,
            real_filename: o.real_filename ?? null,
            filename: o.filename ?? null,
          };
        })
        .filter(Boolean),
    }));

    return NextResponse.json({ comments: payload }, { status: 200 });
  } catch (error) {
    console.error('Error fetching comments:', error);
    return NextResponse.json(
      { error: error.original?.sqlMessage || error.message || 'Failed to fetch comments.' },
      { status: 500 }
    );
  }
}

