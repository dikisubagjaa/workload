export const dynamic = 'force-dynamic';
export const revalidate = 0;

import { NextResponse } from "next/server";
import db from "@/database/models";
import dayjs from "dayjs";
import utc from "dayjs/plugin/utc";
import customParseFormat from "dayjs/plugin/customParseFormat";
import { getUnixTimestampUTC } from "@/utils/dateHelpers";
import { withAuth } from "@/utils/session";
import { notify as notifyUser } from "@/utils/notifier";
import { buildModalUrl } from "@/utils/url";

dayjs.extend(utc);
dayjs.extend(customParseFormat);

const { sequelize, Task, User, TaskAssignment, ProjectTeam, Sequelize } = db;
const { Op } = Sequelize;

// helper: filter yang belum di-delete
const activeDeletedClause = {
  [Op.or]: [{ deleted: null }, { deleted: 0 }, { deleted: "" }],
};

// helper: recalc count_task_child, count_task_child_completed, progress parent
async function recalcParentChildStats(parentTaskId) {
  const numericParentId = Number(parentTaskId);
  if (!Number.isFinite(numericParentId) || numericParentId <= 0) return;

  const baseWhere = {
    parent_id: numericParentId,
    ...activeDeletedClause,
  };

  const totalChild = await Task.count({ where: baseWhere });

  const totalCompleted = await Task.count({
    where: {
      ...baseWhere,
      todo: "completed", // hanya status "completed" yang dianggap selesai
    },
  });

  let progress = 0;
  if (totalChild > 0) {
    progress = Math.round((totalCompleted / totalChild) * 100);
    if (progress < 0) progress = 0;
    if (progress > 100) progress = 100;
  }

  await Task.update(
    {
      count_task_child: totalChild,
      count_task_child_completed: totalCompleted,
      progress,
    },
    { where: { task_id: numericParentId } }
  );
}

// ============================ PUT ============================
export const PUT = withAuth(async function PUT_HANDLER(req, { params }, currentUser) {
  try {
    const { subtaskItemId } = params;
    const body = await req.json();

    const subtaskItem = await Task.findByPk(subtaskItemId);
    if (!subtaskItem) {
      return NextResponse.json({ error: "Subtask item not found" }, { status: 404 });
    }

    const nowUnix = getUnixTimestampUTC();
    const actorId = currentUser.user_id;
    const url = buildModalUrl({ module: "task", id: Number(subtaskItemId), commentId: null, basePath: "/dashboard" });

    if (body.type === "assign_to") {
      const userIds = (Array.isArray(body.value) ? body.value : [body.value])
        .map(Number)
        .filter(Number.isInteger);

      // 1) Reset assignment lama di task_assignment → tulis yang baru
      await TaskAssignment.destroy({ where: { task_id: subtaskItemId } });
      if (userIds.length) {
        const rows = userIds.map((uid) => ({
          task_id: subtaskItemId,
          user_id: uid,
          created: nowUnix,
          created_by: actorId,
          updated: nowUnix,
          updated_by: actorId,
        }));
        await TaskAssignment.bulkCreate(rows);
      }

      await subtaskItem.update({ updated: nowUnix, updated_by: actorId });

      // 2) Sinkron ke project_team (ORM only)
      const projectId = subtaskItem.project_id;

      // Hapus yang tidak lagi dipilih
      await ProjectTeam.destroy({
        where: {
          project_id: projectId,
          task_id: subtaskItemId,
          ...(userIds.length ? { user_id: { [Op.notIn]: userIds } } : {}), // kalau kosong, hapus semua
        },
      });

      // Tambah yang belum ada (kalau sudah ada → diabaikan)
      await Promise.all(
        userIds.map((uid) =>
          ProjectTeam.findOrCreate({
            where: { project_id: projectId, task_id: subtaskItemId, user_id: uid },
            defaults: {
              source: "task",
              created: nowUnix,
              created_by: actorId,
              updated: nowUnix,
              updated_by: actorId,
            },
          })
        )
      );

      // Notifikasi (opsional)
      if (userIds.length) {
        await Promise.all(
          userIds.map((uid) =>
            notifyUser({
              userId: uid,
              sender: "system",
              description: `Kamu di-assign ke subtask: ${subtaskItem.title}`,
              url,
              payload: { type: "assign", taskId: subtaskItemId },
            })
          )
        );
      }
    } else if (body.type === "end_date") {
      await subtaskItem.update({
        end_date: dayjs(body.value).unix(),
        start_date: nowUnix,
        updated: nowUnix,
        updated_by: actorId,
      });

      const assignees = await TaskAssignment.findAll({
        where: { task_id: subtaskItemId },
        attributes: ["user_id"],
      });
      const uids = assignees.map((a) => a.user_id);
      if (uids.length) {
        await Promise.all(
          uids.map((uid) =>
            notifyUser({
              userId: uid,
              sender: "system",
              description: `Due date subtask diperbarui: ${dayjs(body.value).format("DD MMM YYYY")}.`,
              url,
              payload: { type: "reschedule", taskId: subtaskItemId, newDue: dayjs(body.value).unix() },
            })
          )
        );
      }

    } else if (body.type === "todo") {
      await recalcParentChildStats(subtaskItem.parent_id);
    } else {
      await subtaskItem.update({
        [body.type]: body.value,
        updated: nowUnix,
        updated_by: actorId,
      });
    }

    // 3) Balikkan subTaskItem lengkap untuk realtime UI
    const updated = await Task.findOne({
      where: { task_id: subtaskItemId },
      attributes: [
        "task_id", "title", "description", "project_id", "parent_id", "ts_id",
        "start_date", "end_date", "created", "created_by", "updated", "updated_by",
      ],
      include: [
        { model: User, as: "creator", attributes: ["user_id", "fullname", "profile_pic"], required: false },
        { model: User, as: "AssignedUser", attributes: ["user_id", "fullname", "profile_pic"], through: { attributes: [] }, required: false },
      ],
    });
    if (!updated) return NextResponse.json({ error: 'not found' }, { status: 404 });

    const json = updated.toJSON();
    const formattedUsers =
      Array.isArray(json.AssignedUser) && json.AssignedUser.length
        ? json.AssignedUser.map((u) => ({
          user_id: u.user_id,
          fullname: u.fullname.trim(),
          profile_pic: u.profile_pic || null,
        }))
        : [];

    json.assign_to = formattedUsers;
    json.AssignedUser = formattedUsers;

    return NextResponse.json(
      { message: "Subtask item berhasil diubah", subTaskItem: json },
      { status: 200 }
    );
  } catch (error) {
    console.error("Error updating subtask item:", error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
});

// ============================ GET ============================
export const GET = withAuth(async function GET_HANDLER(req, { params }, currentUser) {
  try {
    const Tasks = await Task.findAll();
    return NextResponse.json({ Task: Tasks }, { status: 200 });
  } catch (error) {
    console.error("Error fetching Tasks:", error);
    return NextResponse.json({ error: "Gagal mengambil data" }, { status: 500 });
  }
});

// ============================ DELETE ============================
export const DELETE = withAuth(async function DELETE_HANDLER(req, { params }, currentUser) {
  const { taskId, subtaskItemId } = params;
  if (!taskId || !subtaskItemId) {
    return NextResponse.json({ error: "taskId dan subtaskItemId wajib" }, { status: 400 });
  }

  const nowUnix = getUnixTimestampUTC();
  const actorId = currentUser?.user_id ?? currentUser;
  const t = await sequelize.transaction();

  try {
    // Soft-delete subtask item
    const [affected] = await Task.update(
      { deleted: nowUnix, deleted_by: actorId, updated: nowUnix, updated_by: actorId },
      { where: { task_id: subtaskItemId }, transaction: t }
    );

    // Hapus semua anggota project_team utk subtask ini (simpel)
    await ProjectTeam.destroy({ where: { task_id: subtaskItemId }, transaction: t });

    await t.commit();

    if (!affected) {
      return NextResponse.json({ error: "Subtask item tidak ditemukan atau sudah terhapus" }, { status: 404 });
    }

    await recalcParentChildStats(taskId);

    return NextResponse.json({ message: "Subtask item di-soft-delete", subtaskItemId });
  } catch (err) {
    await t.rollback();
    console.error("Soft delete subtask item error:", err);
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
});
