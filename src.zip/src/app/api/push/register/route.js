// src/app/api/push/register/route.js
export const dynamic = "force-dynamic";
export const revalidate = 0;

import { NextResponse } from "next/server";
import db from "@/database/models";

export async function POST(req) {
    try {
        const { userId, token, app } = await req.json();
        const created_by = Number(userId);

        if (!created_by || !token) {
            return NextResponse.json({ ok: false, error: "Bad request" }, { status: 400 });
        }

        const { NotificationPush } = db;
        const ua = req.headers.get("user-agent") || "";
        const now = Math.floor(Date.now() / 1000);

        // upsert by (created_by, token)
        const [row, created] = await NotificationPush.findOrCreate({
            where: { created_by, token },
            defaults: {
                created_by,
                token,
                app: app || "web",
                ua,
                status: "active",
                last_seen: now,
                created: now,
                updated: now,
            },
        });

        if (!created) {
            row.app = app || row.app || "web";
            row.ua = ua;
            row.status = "active";
            row.last_seen = now;
            await row.save();
        }

        return NextResponse.json({
            ok: true,
            id: row.notification_push_id,
            created,
        });
    } catch (e) {
        return NextResponse.json(
            { ok: false, error: e?.message || "Internal error" },
            { status: 500 }
        );
    }
}
