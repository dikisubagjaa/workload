// src/app/api/appraisal/submit/route.js
export const dynamic = "force-dynamic";
export const revalidate = 0;

import { NextResponse } from "next/server";
import db from "@/database/models";
import { withActive } from "@/utils/session";
import {
  nowUnix,
  isTrue,
  getStaffIdField,
  calcScore,
  requireAllAnswered,
} from "../_helper";

const { Appraisal } = db;

export const POST = withActive(async function POST_HANDLER(req, ctx, currentUser) {
  try {
    // ✅ yang boleh submit hanya superadmin (sesuai request kamu)
    if (!isTrue(currentUser?.is_superadmin)) {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    }

    const body = await req.json().catch(() => ({}));
    const appraisalId = Number(body?.appraisalId);

    if (!Number.isFinite(appraisalId)) {
      return NextResponse.json({ error: "Invalid appraisalId" }, { status: 400 });
    }

    const row = await Appraisal.findOne({
      where: { appraisal_id: appraisalId, deleted: null, deleted_by: null },
    });
    if (!row) return NextResponse.json({ error: "Not found" }, { status: 404 });

    if (String(row.status) !== "draft") {
      return NextResponse.json({ error: "Only draft can be submitted." }, { status: 400 });
    }

    // wajib semua terisi (1..5)
    const check = requireAllAnswered(row.questions_json, row.answers_json);
    if (!check.ok) {
      return NextResponse.json(
        { error: `Answer required for question_id=${check.missing}` },
        { status: 400 }
      );
    }

    const now = nowUnix();
    const actorId = Number(currentUser?.user_id);

    // recompute score
    const score = calcScore(row.questions_json, row.answers_json);

    // approvals_json: simpan siapa yang submit (superadmin)
    const prevApprovals =
      row.approvals_json && typeof row.approvals_json === "object" ? row.approvals_json : {};

    const submitterSnapshot = {
      user_id: actorId,
      fullname: currentUser?.fullname || null,
      email: currentUser?.email || null,
      job_position: currentUser?.job_position || null,
      approved_at: now, // dipakai sebagai submitted_at juga boleh
    };

    const updates = {
      status: "submitted",
      // ✅ start approval dari HOD
      current_step: "hod",
      submitted_at: now,

      // score
      total_score: score.total_score,
      average_score: score.average_score,
      grade: score.grade,
      scoring_json: {
        ...(row.scoring_json && typeof row.scoring_json === "object" ? row.scoring_json : {}),
        ...score,
      },

      approvals_json: {
        ...prevApprovals,
        superadmin: submitterSnapshot,
        // jangan auto-approve HOD/HRD/Director di sini
        hod: prevApprovals.hod || null,
        hrd: prevApprovals.hrd || null,
        director: prevApprovals.director || null,
      },

      updated: now,
      updated_by: actorId,
    };

    await row.update(updates);

    return NextResponse.json({ ok: true, data: row }, { status: 200 });
  } catch (error) {
    console.error("POST /api/appraisal/submit error:", error);
    return NextResponse.json({ error: error?.message || "Failed." }, { status: 500 });
  }
});
