export const dynamic = "force-dynamic";
export const revalidate = 0;

import { NextResponse } from "next/server";
import dayjs from "dayjs";
import db from "@/database/models";
import { withAuth } from "@/utils/session";

const { ProjectPurchaseOrder, ProjectQuotation } = db;

export const DELETE = withAuth(async function DELETE_HANDLER(req, { params }, currentUser) {
  const { projectId, qtId, poId } = params;

  try {
    if (!poId || poId === "undefined") {
      return NextResponse.json(
        { status: "error", message: "PO ID is required." },
        { status: 400 }
      );
    }
    if (!qtId || qtId === "undefined") {
      return NextResponse.json(
        { status: "error", message: "Quotation ID is required." },
        { status: 400 }
      );
    }

    const po = await ProjectPurchaseOrder.unscoped().findByPk(poId);
    if (!po || po.deleted) {
      return NextResponse.json(
        { status: "error", message: "PO not found." },
        { status: 404 }
      );
    }

    // pastikan PO memang milik quotation di URL
    if (String(po.pq_id) !== String(qtId)) {
      return NextResponse.json(
        { status: "error", message: "PO not found." },
        { status: 404 }
      );
    }

    // pastikan quotation milik project yang dimaksud
    const quotation = await ProjectQuotation.unscoped().findByPk(qtId);
    if (!quotation || quotation.deleted || String(quotation.project_id) !== String(projectId)) {
      return NextResponse.json(
        { status: "error", message: "PO not found." },
        { status: 404 }
      );
    }

    const nowUnix = dayjs().unix();

    await po.update({
      deleted: nowUnix,
      deleted_by: currentUser.user_id,
      updated: nowUnix,
      updated_by: currentUser.user_id,
    });

    return NextResponse.json(
      { status: "success", message: "PO deleted." },
      { status: 200 }
    );
  } catch (err) {
    console.error("DELETE PO error:", err);
    return NextResponse.json(
      { status: "error", message: "Failed to delete PO." },
      { status: 500 }
    );
  }
});
