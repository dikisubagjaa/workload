export const dynamic = 'force-dynamic';
export const revalidate = 0;

import { NextResponse } from 'next/server';
import db from "@/database/models";
import { withActive } from "@/utils/session";

const { Project, Client } = db;

export const GET = withActive(async function GET_HANDLER(req) {
    try {
        // Mengambil 10 entri terbaru dari tabel project
        const recentActivity = await Project.findAll({
            limit: 10,
            order: [['created', 'DESC']],
            include: [{
                model: Client,
                as: 'Client',
                attributes: ['client_name']
            }]
        });
        return NextResponse.json({ data: recentActivity });
    } catch (error) {
        console.error("Error fetching recent activity:", error);
        return NextResponse.json({ error: "Failed to fetch recent activity." }, { status: 500 });
    }
});