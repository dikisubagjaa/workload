export const dynamic = 'force-dynamic';
export const revalidate = 0;

import { NextResponse } from "next/server";
import db from "@/database/models";
import dayjs from "dayjs";
import { withActive } from "@/utils/session";
const { TaskRevision, Task, Project } = db;

/**
 * GET /api/revisions/under-review
 * Query (opsional):
 *   - status: in_review|revise|done (default: in_review,revise)
 */
export const GET = withActive(async function GET_HANDLER(req, _ctx, currentUser) {
  try {
    const { searchParams } = new URL(req.url);
    const statusParam = searchParams.get("status");
    const statusList = statusParam
      ? statusParam.split(",").map(s => s.trim())
      : ["in_review", "revise"]; // default: yg belum selesai

    // Ambil semua yang match status, urutkan terbaru → dedup by task_id di JS untuk ambil latest per task
    const rows = await TaskRevision.findAll({
      where: { status: statusList },
      include: [
        {
          model: Task,
          as: "Task",
          required: true,
          include: [{ model: Project, as: "Project", required: false }],
        },
      ],
      order: [["created", "DESC"]],
      subQuery: false,
    });

    // Dedup: latest per task_id
    const seen = new Set();
    const latest = [];
    for (const r of rows) {
      const t = r.Task;
      if (!t) continue;
      if (seen.has(t.task_id)) continue;
      seen.add(t.task_id);
      latest.push(r);
    }

    // Map ke bentuk yang table kamu pakai
    const dataTaskReview = latest.map(r => {
      const t = r.Task;
      const p = t?.Project;
      const submitted = r.created || r.submitted_at || r.updated || dayjs().unix();
      const daysSince = Math.max(0, dayjs().diff(dayjs.unix(submitted), "day"));

      return {
        key: String(r.revision_id),
        revision_id: r.revision_id,
        task_id: t.task_id,
        name: t.title || t.name || `Task #${t.task_id}`,
        version: r.version ? `v${String(r.version).padStart(2, "0")}` : "v01",
        projectClient: p?.title || p?.name || "-",
        progress: Number(t.progress ?? 0),
        SubmittedDated: dayjs.unix(submitted).format("DD MMM YYYY"),
        DaysSince: `${daysSince} Days`,
        status: (r.status || "in_review").replace("_", " "),
        // tombol check non-aktif kalau sudah done
        btnCheck: r.status === "done",
      };
    });

    return NextResponse.json({ dataTaskReview }, { status: 200 });
  } catch (err) {
    console.error("GET under-review error:", err);
    return NextResponse.json({ error: err.message || "Failed to fetch under-review." }, { status: 500 });
  }
});
