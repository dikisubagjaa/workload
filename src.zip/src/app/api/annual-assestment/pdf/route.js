export const dynamic = "force-dynamic";
export const revalidate = 0;
export const runtime = "nodejs";

import db from "@/database/models";
import { withActive } from "@/utils/session";

import PDFDocument from "pdfkit";
import archiver from "archiver";
import { PassThrough, Readable } from "stream";

const { AnnualAssestment, User, MasterAnnualAssesmentQuestion } = db;

function getRunningPeriod() {
  const year = new Date().getFullYear();
  return { periodFromYear: year - 1, periodToYear: year };
}

function normalizeBool(v) {
  return v === true || v === "true" || v === 1 || v === "1";
}

function getRole(currentUser) {
  return String(currentUser?.user_role || currentUser?.role || "").toLowerCase();
}

function isSuperOrHrd(currentUser) {
  const r = getRole(currentUser);
  return r === "superadmin" || r === "hrd";
}

function isHod(currentUser) {
  return normalizeBool(currentUser?.is_hod);
}

function ratingLabel(n) {
  const num = Number(n);
  if (num === 1) return "1 - Mengecewakan";
  if (num === 2) return "2 - Perlu Ditingkatkan";
  if (num === 3) return "3 - Baik / Cukup Baik";
  if (num === 4) return "4 - Sangat Baik";
  if (num === 5) return "5 - Di Atas Rata-rata";
  return String(n ?? "-");
}

function safeObj(val, fallback = {}) {
  try {
    if (val == null) return fallback;
    if (typeof val === "object") return val;
    return JSON.parse(String(val));
  } catch {
    return fallback;
  }
}

function getAnswers(assestmentRow, kind /* 'staff'|'hod' */) {
  if (!assestmentRow) return {};

  if (kind === "staff") {
    if (assestmentRow.staff_answers_json && typeof assestmentRow.staff_answers_json === "object") {
      return assestmentRow.staff_answers_json;
    }
    const payload = safeObj(assestmentRow.staff_payload_json, {});
    if (payload?.answers && typeof payload.answers === "object") return payload.answers;
    return {};
  }

  if (assestmentRow.hod_answers_json && typeof assestmentRow.hod_answers_json === "object") {
    return assestmentRow.hod_answers_json;
  }
  const payload = safeObj(assestmentRow.hod_payload_json, {});
  if (payload?.answers && typeof payload.answers === "object") return payload.answers;
  return {};
}

function getAnswerValue(raw) {
  if (raw == null) return null;
  if (typeof raw === "object") {
    if (typeof raw.value !== "undefined") return raw.value;
    return null;
  }
  return raw;
}

function getAnswerText(raw) {
  if (raw == null) return "";
  if (typeof raw === "object") {
    if (typeof raw.text === "string") return raw.text;
    if (typeof raw.note === "string") return raw.note;
    return "";
  }
  if (typeof raw === "string") return raw;
  return "";
}

function sanitizeFileName(s) {
  return String(s || "")
    .trim()
    .replace(/[\\/:*?"<>|]+/g, "")
    .replace(/\s+/g, " ")
    .slice(0, 120);
}

async function loadQuestionsSnapshot(assestmentRow) {
  // prefer snapshot per assessment (biar konsisten walau master berubah)
  if (Array.isArray(assestmentRow?.questions_json) && assestmentRow.questions_json.length) {
    return assestmentRow.questions_json;
  }

  // fallback master
  const rows = await MasterAnnualAssesmentQuestion.findAll({
    where: {
      is_active: 1,
      deleted: null,
      deleted_by: null,
    },
    order: [
      ["section_key", "ASC"],
      ["sort_order", "ASC"],
      ["question_id", "ASC"],
    ],
  });

  return rows.map((q) => ({
    question_key: q.question_key,
    title: q.title,
    description: q.description,
    input_type: q.input_type,
  }));
}

async function loadLatestAssessmentByStaff(staffId, periodToYear) {
  // ambil yang terbaru untuk periode itu
  const row = await AnnualAssestment.findOne({
    where: {
      staff_id: staffId,
      period_to_year: periodToYear,
    },
    order: [
      ["annual_assestment_id", "DESC"],
    ],
  });
  return row;
}

async function loadUsers(staffId, hodId) {
  const users = await User.findAll({
    where: {
      user_id: [staffId, hodId].filter(Boolean),
      deleted: null,
      deleted_by: null,
    },
  });

  const byId = {};
  users.forEach((u) => {
    byId[u.user_id] = u;
  });

  return {
    staff: byId[staffId] || null,
    hod: hodId ? byId[hodId] || null : null,
  };
}

async function assertCanDownloadSingle({ currentUser, targetStaffId, assestmentRow }) {
  const meId = Number(currentUser?.user_id);

  // superadmin/hrd: bebas
  if (isSuperOrHrd(currentUser)) return;

  // staff biasa: hanya dirinya sendiri
  if (!isHod(currentUser)) {
    if (Number(targetStaffId) !== meId) {
      const err = new Error("Forbidden");
      err.statusCode = 403;
      throw err;
    }
    return;
  }

  // HOD: boleh dirinya sendiri, atau staff yang dia review (hod_id match)
  if (Number(targetStaffId) === meId) return;

  const hodId = Number(assestmentRow?.hod_id || 0);
  if (hodId && hodId === meId) return;

  const err = new Error("Forbidden");
  err.statusCode = 403;
  throw err;
}

function buildPdfBuffer({ assestmentRow, staff, hod, questions, staffAnswers, hodAnswers }) {
  return new Promise((resolve, reject) => {
    try {
      const doc = new PDFDocument({ size: "A4", margin: 50 });
      const chunks = [];

      doc.on("data", (c) => chunks.push(c));
      doc.on("end", () => resolve(Buffer.concat(chunks)));
      doc.on("error", reject);

      const periodFrom = assestmentRow?.period_from_year ?? "-";
      const periodTo = assestmentRow?.period_to_year ?? "-";

      const staffName = staff?.fullname || staff?.name || staff?.full_name || `Staff ${assestmentRow?.staff_id}`;
      const hodName = hod?.fullname || hod?.name || hod?.full_name || "-";
      const status = assestmentRow?.status || "-";

      doc.fontSize(16).text("Annual Review", { align: "center" });
      doc.moveDown(0.5);
      doc.fontSize(11).text(`Period: ${periodFrom} - ${periodTo}`);
      doc.text(`Staff: ${staffName} (ID: ${assestmentRow?.staff_id || "-"})`);
      doc.text(`HOD: ${hodName}`);
      doc.text(`Status: ${status}`);
      doc.text(`Generated: ${new Date().toLocaleString("en-GB")}`);
      doc.moveDown(1);

      questions.forEach((q, idx) => {
        const key = q.question_key || q.questionKey || q.key;
        if (!key) return;

        const inputType = String(q.input_type || q.inputType || "rating").toLowerCase();
        const staffRaw = staffAnswers?.[key];
        const hodRaw = hodAnswers?.[key];

        doc.fontSize(12).text(`${idx + 1}. ${q.title || "-"}`, { continued: false });
        if (q.description) {
          doc.fontSize(10).fillColor("#444").text(String(q.description));
          doc.fillColor("black");
        }
        doc.moveDown(0.25);

        // STAFF ALWAYS shown
        if (inputType === "rating") {
          const sVal = getAnswerValue(staffRaw);
          const sNote = getAnswerText(staffRaw);
          doc.fontSize(11).text(`Staff Rating: ${sVal ? ratingLabel(sVal) : "-"}`);
          if (sNote) doc.fontSize(10).fillColor("#333").text(`Staff Note: ${sNote}`).fillColor("black");

          // ✅ Per requirement: pembanding HOD hanya untuk rating
          const hVal = getAnswerValue(hodRaw);
          const hNote = getAnswerText(hodRaw);
          doc.fontSize(11).text(`HOD Rating: ${hVal ? ratingLabel(hVal) : "-"}`);
          if (hNote) doc.fontSize(10).fillColor("#333").text(`HOD Note: ${hNote}`).fillColor("black");
        } else {
          // ✅ selain rating: tidak ada pembanding HOD
          const sText = getAnswerText(staffRaw);
          doc.fontSize(11).text(`Staff Answer: ${sText || "-"}`);
        }

        doc.moveDown(0.75);
        doc.moveTo(doc.x, doc.y).lineTo(545, doc.y).strokeColor("#EEE").stroke();
        doc.strokeColor("black");
        doc.moveDown(0.75);
      });

      doc.end();
    } catch (e) {
      reject(e);
    }
  });
}

function jsonError(message, status = 500) {
  return new Response(JSON.stringify({ error: message }), {
    status,
    headers: { "Content-Type": "application/json" },
  });
}

export const GET = withActive(async function GET_HANDLER(req, ctx, currentUser) {
  try {
    const url = new URL(req.url);

    const download = String(url.searchParams.get("download") || "").toLowerCase(); // 'zip' untuk all
    const scope = String(url.searchParams.get("scope") || "").toLowerCase(); // 'all'
    const statusFilter = String(url.searchParams.get("status") || "finalized").toLowerCase(); // finalized|all

    const yearParam = url.searchParams.get("year");
    const { periodToYear } = getRunningPeriod();
    const year = yearParam ? Number(yearParam) : periodToYear;

    if (!year || Number.isNaN(year)) {
      return jsonError("Invalid year", 400);
    }

    // =========================
    // ZIP MODE (superadmin/hrd only)
    // =========================
    if (download === "zip") {
      if (!isSuperOrHrd(currentUser)) {
        return jsonError("Forbidden", 403);
      }

      // scope=all (default all)
      const wantAll = scope === "all" || !scope;

      if (!wantAll) {
        return jsonError("Invalid scope. Use scope=all for ZIP.", 400);
      }

      const where = {
        period_to_year: year,
      };

      if (statusFilter !== "all") {
        where.status = "finalized";
      }

      const rows = await AnnualAssestment.findAll({
        where,
        order: [["annual_assestment_id", "ASC"]],
      });

      const pass = new PassThrough();
      const zip = archiver("zip", { zlib: { level: 9 } });

      zip.on("error", (err) => {
        pass.destroy(err);
      });

      zip.pipe(pass);

      // generate sequential (lebih aman untuk memory)
      for (const row of rows) {
        const staffId = Number(row.staff_id);
        const hodId = row.hod_id ? Number(row.hod_id) : null;

        const { staff } = await loadUsers(staffId, hodId);
        const staffName =
          staff?.fullname || staff?.name || staff?.full_name || `staff_${staffId}`;

        const questions = await loadQuestionsSnapshot(row);
        const staffAnswers = getAnswers(row, "staff");
        const hodAnswers = getAnswers(row, "hod");

        const pdfBuffer = await buildPdfBuffer({
          assestmentRow: row,
          staff,
          hod: null,
          questions,
          staffAnswers,
          hodAnswers,
        });

        const fileName = sanitizeFileName(
          `${year}_AnnualReview_${staffName}_ID${staffId}.pdf`
        );

        zip.append(pdfBuffer, { name: fileName });
      }

      await zip.finalize();

      const webStream = Readable.toWeb(pass);

      return new Response(webStream, {
        status: 200,
        headers: {
          "Content-Type": "application/zip",
          "Content-Disposition": `attachment; filename="annual_review_${year}_all.zip"`,
        },
      });
    }

    // =========================
    // SINGLE PDF MODE
    // =========================
    const staffIdParam = url.searchParams.get("staffId");
    const targetStaffId = staffIdParam ? Number(staffIdParam) : Number(currentUser?.user_id);

    if (!targetStaffId || Number.isNaN(targetStaffId)) {
      return jsonError("Invalid staffId", 400);
    }

    const row = await loadLatestAssessmentByStaff(targetStaffId, year);

    if (!row) {
      return jsonError("Assessment not found", 404);
    }

    await assertCanDownloadSingle({
      currentUser,
      targetStaffId,
      assestmentRow: row,
    });

    const staffId = Number(row.staff_id);
    const hodId = row.hod_id ? Number(row.hod_id) : null;
    const { staff, hod } = await loadUsers(staffId, hodId);

    const questions = await loadQuestionsSnapshot(row);
    const staffAnswers = getAnswers(row, "staff");
    const hodAnswers = getAnswers(row, "hod");

    const pdfBuffer = await buildPdfBuffer({
      assestmentRow: row,
      staff,
      hod,
      questions,
      staffAnswers,
      hodAnswers,
    });

    const staffName =
      staff?.fullname || staff?.name || staff?.full_name || `staff_${staffId}`;
    const fileName = sanitizeFileName(`${year}_AnnualReview_${staffName}.pdf`);

    return new Response(pdfBuffer, {
      status: 200,
      headers: {
        "Content-Type": "application/pdf",
        "Content-Disposition": `attachment; filename="${fileName}"`,
      },
    });
  } catch (e) {
    const code = e?.statusCode || 500;
    return jsonError(e?.message || "Internal error", code);
  }
});
