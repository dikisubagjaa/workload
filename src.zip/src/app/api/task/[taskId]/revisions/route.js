// src/app/api/task/[taskId]/revisions/route.js
import { NextResponse } from "next/server";
import db from "@/database/models";
import dayjs from "dayjs";
import { withAuth } from "@/utils/session";
import { notify as notifyUser } from "@/utils/notifier";
import { buildModalUrl } from "@/utils/url";

const { TaskRevision, Task, TaskTodo, TaskAssignment, Sequelize } = db;
const { Op } = Sequelize || {};
const sequelize = db.sequelize;

// ================= GET: list revisions for a task =================
export const GET = withAuth(async function GET_HANDLER(req, { params }) {
  try {
    const { taskId } = params;
    const rows = await TaskRevision.findAll({
      where: { task_id: taskId },
      order: [["created", "DESC"]],
      include: [{ model: Task, as: "Task", required: false }],
    });
    return NextResponse.json(
      { revisions: rows.map((r) => r.toJSON()) },
      { status: 200 }
    );
  } catch (err) {
    console.error("GET revisions error:", err);
    return NextResponse.json(
      { error: err.message || "Failed to fetch revisions." },
      { status: 500 }
    );
  }
});

// ================= POST: create revision =================
export const POST = withAuth(
  async function POST_HANDLER(req, { params }, currentUser) {
    const t = await sequelize.transaction();
    try {
      const { taskId } = params;
      const body = (await req.json().catch(() => ({}))) || {};

      const nowUnix = dayjs().unix();

      // due_date bisa null, jangan paksa dayjs(null)
      let dueDateUnix = null;
      if (
        body.due_date !== undefined &&
        body.due_date !== null &&
        body.due_date !== ""
      ) {
        const num = Number(body.due_date);
        if (Number.isFinite(num)) {
          dueDateUnix = num;
        }
      }

      // pastikan task ada
      const task = await Task.findByPk(taskId, { transaction: t });
      if (!task) {
        await t.rollback();
        return NextResponse.json(
          { error: "Task not found." },
          { status: 404 }
        );
      }

      // --- VALIDASI STATUS TODO ---
      const fromTodo = body.from_todo || task.todo || null;
      let targetTodo = body.target_todo || null;

      // kalau target_todo tidak dikirim, mapping otomatis
      if (!targetTodo) {
        if (fromTodo === "need_review_ae") {
          // AE → revisi ke staff
          targetTodo = "revise_account";
        } else if (fromTodo === "need_review_hod") {
          // HOD → revisi ke staff
          targetTodo = "revise_hod";
        }
      }

      const allowedTargets = ["revise_account", "revise_hod"];
      console.log("Target todo:", targetTodo);
      // kalau masih belum kebentuk, atau bukan salah satu yang diizinkan → tolak
      if (!targetTodo || !allowedTargets.includes(targetTodo)) {
        await t.rollback();
        return NextResponse.json(
          {
            error:
              `Invalid revision status. Only transitions from need_review_ae→revise_account or need_review_hod→revise_hod are allowed. ${targetTodo ? `(got: ${targetTodo})` : ""}`,
          },
          { status: 400 }
        );
      }

      const requestBy =
        body?.request_by === "client" || body?.request_by === "internal"
          ? body.request_by
          : "internal";

      const reason = body?.reason ?? "";

      // ambil versi terakhir, next version = last.version + 1
      const last = await TaskRevision.findOne({
        where: { task_id: taskId },
        order: [["version", "DESC"]],
        attributes: ["version"],
        transaction: t,
      });
      const nextVersion = Number(last?.version ?? 0) + 1;

      // buat revision
      const created = await TaskRevision.create(
        {
          task_id: Number(taskId),
          version: nextVersion,
          reason: reason,
          request_by: requestBy,
          start_revision: nowUnix,
          end_revision: dueDateUnix, // pakai kolom ini untuk due date revisi
          submitted_at: nowUnix,
          created: nowUnix,
          created_by: currentUser?.user_id ?? null,
          updated: nowUnix,
          updated_by: currentUser?.user_id ?? null,
        },
        { transaction: t }
      );

      // label last_version (Client 1 / Internal 2, dsb)
      const lastVersionLabel = `${requestBy} ${nextVersion}`;

      // update task utama
      await task.update(
        {
          todo: targetTodo, // HARUS revise_account / revise_hod
          start_data: nowUnix,
          end_date: dueDateUnix,
          count_revision: nextVersion,
          last_version: lastVersionLabel,
          updated: nowUnix,
          updated_by: currentUser?.user_id ?? null,
        },
        { transaction: t }
      );

      // catat history todo
      await TaskTodo.create(
        {
          task_id: taskId,
          todo: targetTodo,
          created: nowUnix,
          created_by: currentUser?.user_id ?? null,
          updated: nowUnix,
          updated_by: currentUser?.user_id ?? null,
        },
        { transaction: t }
      );

      await t.commit();

      // --- Kirim notifikasi ke staff setelah revisi sukses ---
      try {
        // siapa yang harus dikasih tahu? → semua assignee task ini
        const assignees = await TaskAssignment.findAll({
          where: {
            task_id: taskId
          },
          attributes: ["user_id"],
        });

        if (assignees.length) {
          // URL untuk membuka modal task di dashboard
          const url = buildModalUrl({
            module: "task",
            id: Number(taskId),
            commentId: null,
            basePath: "/dashboard",
          });

          // Pesan beda tergantung sumber revisi
          let description = "Revision requested for your task.";
          if (fromTodo === "need_review_ae" && targetTodo === "revise_account") {
            description = "Client requested a revision for your task.";
          } else if (fromTodo === "need_review_hod" && targetTodo === "revise_hod") {
            description = "HOD requested a revision for your task.";
          }

          // ID revision (kalau mau dipakai di payload)
          const revisionId =
            created?.revision_id ?? created?.id ?? null;

          await Promise.all(
            assignees.map((a) =>
              notifyUser({
                userId: a.user_id,
                sender: "task",
                description,
                url,
                payload: {
                  type: "taskRevisionRequested",
                  taskId: Number(taskId),
                  revisionId,
                },
              })
            )
          );
        }
      } catch (e) {
        console.warn(
          "Failed to send revision notification:",
          e?.message || e
        );
      }

      return NextResponse.json(
        {
          message: "Revision request created.",
          revision: created.toJSON(),
          todo: targetTodo,
        },
        { status: 201 }
      );
    } catch (err) {
      await t.rollback();
      console.error("POST revision error:", err);
      return NextResponse.json(
        { error: err.message || "Failed to create revision." },
        { status: 500 }
      );
    }
  }
);
