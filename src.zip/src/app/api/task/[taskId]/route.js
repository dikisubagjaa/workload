export const dynamic = 'force-dynamic';
export const revalidate = 0;

import { NextResponse } from "next/server";
import { User, Task, Project, Department, SubTask, TaskAttachment, TaskAssignment, ProjectQuotation, ProjectPurchaseOrder } from "@/database/models"; // Pastikan path sesuai dengan lokasi model
import dayjs from 'dayjs';
import { getUnixTimestampUTC } from "@/utils/dateHelpers";
import { withAuth } from "@/utils/session";
import { recordPerformanceEvent } from "@/database/services/performanceEvent";
import { Op } from "sequelize";

const TZ = process.env.NEXT_PUBLIC_APP_TIMEZONE || "Asia/Jakarta";

// Helper: ambil ID parent kalau child, kalau bukan child kembalikan ID sendiri
function resolveTargetTaskId(rec, fallbackId) {
    const parentId = Number(rec?.parent_id);
    if (Number.isFinite(parentId) && parentId > 0) return parentId; // child → naik ke parent
    return Number(fallbackId); // parent → pakai sendiri
}

export async function GET(req, { params }) {
    try {
        const { taskId } = params;
        if (!taskId) {
            return NextResponse.json({ error: "Task not found" }, { status: 404 });
        }

        const rawId = taskId;
        const id = Number(rawId);
        if (!Number.isFinite(id) || id <= 0) {
            return NextResponse.json({ error: "Invalid task id." }, { status: 400 });
        }

        const brief = await Task.findOne({
            where: { task_id: id },
            attributes: ["task_id", "parent_id"],
        });
        if (!brief) {
            return NextResponse.json({ error: "Task is Not Found." }, { status: 404 });
        }

        const targetId = resolveTargetTaskId(brief, id);
        const detailTask = await Task.findOne({
            where: { task_id: targetId },
            include: [
                { model: User, as: 'creator' },
                {
                    model: SubTask,
                    as: 'SubTasks',
                    required: false
                },
                {
                    model: Task,
                    as: 'SubtaskItems',
                    required: false,
                    include: [
                        {
                            model: TaskAttachment,
                            as: 'Attachments',
                            separate: true,
                            where: { revision_id: null },
                            required: false,
                            order: [['attachment_id', 'DESC']],
                            include: [
                                {
                                    model: TaskAttachment,
                                    as: 'revisionFiles',
                                    separate: true,
                                    order: [['attachment_id', 'DESC']],
                                    required: false,
                                },
                            ],
                        },
                        { model: User, as: 'AssignedUser', attributes: ["fullname", "profile_pic", "user_id"], required: false },
                    ]
                }
            ]
        });
        if (!detailTask) {
            return NextResponse.json({ error: "Data Task not found" }, { status: 404 });
        }

        const [projectData, quotationData, poData, attachmentData] = await Promise.all([
            Project.findAll({ where: { published: 'published' } }),
            ProjectQuotation.findAll({
                where: { project_id: detailTask.project_id },
                attributes: ["pq_id", "quotation_number", "project_id"],
                order: [["pq_id", "DESC"]],
            }),
            ProjectPurchaseOrder.findAll({
                where: { pq_id: detailTask.pq_id },
                attributes: ["po_id", "po_number"],
                order: [["pq_id", "DESC"]],
            }),
            TaskAttachment.findAll({
                where: { task_id: detailTask.task_id }
            })
        ]);


        return NextResponse.json({ detailTask: detailTask, project: projectData, quotation: quotationData, po: poData, taskAttachment: attachmentData }, { status: 200 });
    } catch (error) {
        console.error("Error fetching Tasks:", error);
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}


export const PUT = withAuth(async function PUT_HANDLER(req, { params }, currentUser) {
    try {
        const { taskId } = params;
        const body = await req.json();

        const detail = await Task.findOne({ where: { task_id: taskId } });
        if (!detail) {
            return NextResponse.json({ error: "Task tidak ditemukan" }, { status: 404 });
        }

        const detailAssignment = await TaskAssignment.findOne({ where: { task_id: taskId } });
        const nowUnix = getUnixTimestampUTC();
        const updatePayload = {
            updated: nowUnix,
            updated_by: currentUser.user_id,
        };
        let daysDiff = 0;
        if (body.type === "todo") {
            updatePayload.todo = body.value;
            if (body.value === 'completed') {
                const deadline = dayjs.unix(detail.end_date).tz(TZ);
                const now = dayjs.unix(nowUnix).tz(TZ);
                daysDiff = deadline.startOf("day").diff(now.startOf("day"), "day");

                let bucket = "on_deadline";
                if (daysDiff > 0) bucket = "early";
                else if (daysDiff < 0) {
                    bucket = "overdue";
                    daysDiff = Math.abs(daysDiff);
                    updatePayload.is_overdue = 'true';
                }

                // 🧠 untuk overdue & on_deadline: days null aja biar match dengan config yang kamu punya
                const selector = {
                    type: "task_complete",
                    bucket,
                    days: bucket === "early" ? daysDiff : null,
                };

                const note = `Task ${taskId} ${bucket}${daysDiff ? ` (${daysDiff} hari)` : ""}`;
                // await recordPerformanceEvent({
                //     userId: detailAssignment.user_id,
                //     source: "task",
                //     selector,
                //     eventDate: dayjs().tz(TZ).format("YYYY-MM-DD"),
                //     refId: taskId,
                //     note,
                //     meta: { bucket, daysDiff },
                // });
            }
        }
        else if (body.type === "department") {
            // ====== VERSI SIMPLE: TERIMA ARRAY ID ======
            if (Array.isArray(body.value)) {
                const ids = [...new Set(
                    (body.value || [])
                        .map(Number)
                        .filter(Number.isInteger)
                )];

                if (ids.length === 0) {
                    updatePayload.department = []; // kosong
                } else {
                    const rows = await Department.findAll({
                        where: { department_id: { [Op.in]: ids } },
                        attributes: ["department_id", "title"],
                    });

                    const titleById = new Map(rows.map(r => [Number(r.department_id), r.title]));

                    updatePayload.department = ids.map(id => ({
                        department_id: id,
                        title: titleById.get(id) || "",
                    }));
                }
            } else {
                // ====== BACKWARD COMPAT (kalau ada request lama kirim 1 id) ======
                const depId = Number(body.value);
                if (!Number.isInteger(depId)) throw new Error("Invalid department_id");

                let current = Array.isArray(detail.department) ? [...detail.department] : [];
                const idx = current.findIndex(d => Number(d.department_id) === depId);

                if (idx >= 0) {
                    current.splice(idx, 1); // remove
                } else {
                    const dept = await Department.findByPk(depId, { attributes: ["department_id", "title"] });
                    if (!dept) throw new Error("Department not found");
                    current.push({ department_id: dept.department_id, title: dept.title });
                }
                updatePayload.department = current;
            }
        } else if (body.type === "end_date" || body.type === "start_date") {
            updatePayload[body.type] = body.value ? dayjs(body.value).unix() : null;
        } else {
            updatePayload[body.type] = body.value;
        }

        await Task.update(updatePayload, {
            where: { task_id: taskId },
        });

        const updatedTask = await Task.findOne({ where: { task_id: taskId }, include: [{ model: User, as: 'creator' }] });

        // Mengembalikan data task yang sudah diperbarui
        return NextResponse.json({ message: "Task berhasil diubah", task: updatedTask }, { status: 200 });

    } catch (error) {
        console.error("Error updating Task:", error);
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
});


