export const dynamic = "force-dynamic";
export const revalidate = 0;

import { NextResponse } from "next/server";
import db from "@/database/models";
import { withActive } from "@/utils/session";

const { AnnualAssestment, MasterAnnualAssesmentPeriod } = db;

const isTrue = (v) => v === "true" || v === true || v === 1 || v === "1";

function safeObj(val, fallback = null) {
  try {
    if (val == null) return fallback;
    if (typeof val === "object") return val;
    return JSON.parse(String(val));
  } catch {
    return fallback;
  }
}

function normalizePayload(payload) {
  const p = safeObj(payload, null) || payload;
  if (!p || typeof p !== "object") return { answers: {} };
  if (!p.answers || typeof p.answers !== "object") return { answers: {} };
  return { answers: p.answers };
}

async function getPeriodForYear(year) {
  const row = await MasterAnnualAssesmentPeriod.findOne({
    where: {
      year,
      deleted: null,
      deleted_by: null,
      is_active: 1,
    },
    raw: true,
  });
  return row || null;
}

function getPeriodState(periodRow, now) {
  if (!periodRow) return { configured: false, isOpen: false };

  const openAt = Number(periodRow.open_at);
  const closeAt = Number(periodRow.close_at);

  const isOpen =
    Number.isFinite(openAt) &&
    Number.isFinite(closeAt) &&
    now >= openAt &&
    now <= closeAt;

  return { configured: true, isOpen, openAt, closeAt };
}

function canSubmitStatus(status) {
  // staff submit hanya dari draft
  return status === "draft";
}

export const POST = withActive(async function POST_HANDLER(req, ctx, currentUser) {
  try {
    const now = Math.floor(Date.now() / 1000);

    const { searchParams } = new URL(req.url);
    const body = await req.json();

    // year bisa dari body atau query
    const yearParam = body?.year ?? searchParams.get("year");
    const periodToYear = yearParam ? Number(yearParam) : new Date().getFullYear();

    if (!Number.isFinite(periodToYear)) {
      return NextResponse.json({ error: "Invalid year" }, { status: 400 });
    }
    const periodFromYear = periodToYear - 1;

    const staffId = Number(currentUser?.user_id);
    if (!Number.isFinite(staffId)) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const isSuperadmin = isTrue(currentUser?.is_superadmin);
    const isHrd = isTrue(currentUser?.is_hrd);
    const privileged = isSuperadmin || isHrd;

    // period check (staff biasa wajib ikut jadwal)
    const periodRow = await getPeriodForYear(periodToYear);
    const periodState = getPeriodState(periodRow, now);

    if (!periodState.configured && !privileged) {
      return NextResponse.json(
        {
          error: `Assessment period is not configured for year ${periodToYear}. Please contact HRD.`,
          meta: { year: periodToYear },
        },
        { status: 400 }
      );
    }

    if (periodState.configured && !periodState.isOpen && !privileged) {
      const msg =
        now < periodState.openAt
          ? "Assessment period is not open yet."
          : "Assessment period is closed.";

      return NextResponse.json(
        {
          error: msg,
          meta: {
            year: periodToYear,
            openAt: periodState.openAt,
            closeAt: periodState.closeAt,
            now,
          },
        },
        { status: 400 }
      );
    }

    const annualAssestmentId =
      body?.annualAssestmentId != null ? Number(body.annualAssestmentId) : null;

    const payload = normalizePayload(body?.payload);
    const answersOnly = payload?.answers || {};

    // cari row: by id (kalau dikirim) atau by staff+year
    let row = null;

    if (Number.isFinite(annualAssestmentId) && annualAssestmentId > 0) {
      row = await AnnualAssestment.findOne({
        where: {
          annual_assestment_id: annualAssestmentId,
          staff_id: staffId, // ✅ staff only, no impersonation
        },
      });
    } else {
      row = await AnnualAssestment.findOne({
        where: {
          staff_id: staffId,
          period_to_year: periodToYear,
        },
        order: [["annual_assestment_id", "DESC"]],
      });
    }

    if (!row) {
      return NextResponse.json({ error: "Draft not found." }, { status: 404 });
    }

    // lock status check
    if (!canSubmitStatus(row.status)) {
      return NextResponse.json(
        { error: "Cannot submit. Current status is not draft." },
        { status: 400 }
      );
    }

    // update snapshot period (jaga-jaga)
    const updatePayload = {
      period_from_year: row.period_from_year || periodFromYear,
      period_to_year: row.period_to_year || periodToYear,

      // simpan payload + flattened answers untuk kemudahan query/report
      staff_payload_json: payload,
      staff_answers_json: answersOnly,

      status: "submitted_by_staff",
      staff_submitted_at: now,
      staff_submitted_by: staffId,

      updated: now,
      updated_by: staffId,
    };

    await row.update(updatePayload);

    return NextResponse.json(
      {
        message: "Submitted.",
        data: {
          annual_assestment_id: row.annual_assestment_id,
          staff_id: row.staff_id,
          hod_id: row.hod_id,
          status: row.status,
          period_from_year: row.period_from_year,
          period_to_year: row.period_to_year,
          staff_submitted_at: row.staff_submitted_at,
        },
        meta: {
          period: periodRow,
          periodState,
        },
      },
      { status: 200 }
    );
  } catch (error) {
    console.error("POST /annual-assestment/submit error:", error);
    return NextResponse.json(
      { error: error?.message || "Internal error" },
      { status: 500 }
    );
  }
});
