// src/app/api/cron/performance-score/complete-overdue-task/route.js
import 'server-only';
import { Task, PerformanceEventLog, Sequelize } from '@/database/models';
import dayjs from 'dayjs';
import tz from 'dayjs/plugin/timezone';
import { withCronLock } from '@/utils/cronLock';
dayjs.extend(tz);

export const dynamic = 'force-dynamic';
export const revalidate = 0;

const TZ = process.env.NEXT_PUBLIC_APP_TIMEZONE || 'Asia/Jakarta';
const PERF_CONFIG_ID = 9;   // Complete Overdue Task
const SCORE_VALUE = 2;      // point untuk menyelesaikan task yang sudah overdue

// Status yang dianggap selesai
const DONE_STATUSES = ['completed'];

export async function GET(req) {
    const t0 = Date.now();
    const { Op } = Sequelize;

    try {
        const { searchParams } = new URL(req.url);
        const dateParam = searchParams.get('date');
        const dryRun = String(searchParams.get('dryRun') || '').toLowerCase() === 'true';

        // default ke hari ini (Asia/Jakarta)
        const eventDate = (dateParam && /^\d{4}-\d{2}-\d{2}$/.test(dateParam))
            ? dateParam
            : dayjs().tz(TZ).format('YYYY-MM-DD');

        const periodYear = Number(dayjs(eventDate).year());
        const periodMonth = Number(dayjs(eventDate).month() + 1);
        const periodStart = dayjs(eventDate).startOf('month').format('YYYY-MM-DD');

        const res = await withCronLock(`perf-complete-overdue-${eventDate}`, async () => {
            const taskAttrs = Task.rawAttributes || {};
            const hasEndDate = 'end_date' in taskAttrs;
            const hasTodo = 'todo' in taskAttrs;
            const hasIsOverdue = 'is_overdue' in taskAttrs;
            const hasUpdated = 'updated' in taskAttrs;

            // Hitungan hari (pakai TZ) -> dipakai untuk filter by unix timestamp
            const dayStart = dayjs.tz(eventDate, TZ).startOf('day').unix();
            const dayEnd = dayjs.tz(eventDate, TZ).endOf('day').unix();

            // ================================
            // 1) Tandai task yang sudah overdue tapi BELUM selesai
            //    is_overdue: 'true' jika end_date < hari ini & todo belum selesai
            // ================================
            let overdueScanned = 0;
            let overdueMarked = 0;
            let overdueSample = [];

            if (hasEndDate && hasTodo && hasIsOverdue) {
                const overdueWhere = {
                    end_date: { [Op.lt]: dayStart },
                    todo: { [Op.notIn]: [...DONE_STATUSES, 'cancel'] },
                    [Op.or]: [
                        { is_overdue: null },
                        { is_overdue: { [Op.ne]: 'true' } },
                    ],
                };

                // Ambil kandidat untuk keperluan logging / dryRun
                const overdueTasks = await Task.findAll({
                    where: overdueWhere,
                    attributes: ['task_id', 'title', 'end_date', 'todo', 'is_overdue'],
                    raw: true,
                });

                overdueScanned = overdueTasks.length;
                overdueSample = overdueTasks.slice(0, 5);

                if (!dryRun && overdueTasks.length) {
                    const [affected] = await Task.update(
                        { is_overdue: 'true' },
                        { where: overdueWhere }
                    );
                    overdueMarked = affected || 0;
                }
            }

            // ================================
            // 2) Beri poin untuk task yang diselesaikan HARI INI tapi DEADLINE-nya sudah lewat (overdue)
            // ================================
            if (!hasEndDate || !hasUpdated || !hasTodo) {
                // Tidak bisa lanjut logika tanpa kolom ini
                return {
                    inserted: 0,
                    scanned: 0,
                    skipped: 0,
                    note: 'Task model missing required columns',
                    overdueScanned,
                    overdueMarked,
                    overdueSample,
                };
            }

            // Task yang:
            //   - sudah selesai (todo di DONE_STATUSES)
            //   - diupdate hari ini
            //   - deadline (end_date) sebelum hari ini (overdue)
            const completedOverdueTasks = await Task.findAll({
                where: {
                    todo: { [Op.in]: DONE_STATUSES },
                    updated: { [Op.between]: [dayStart, dayEnd] },
                    end_date: { [Op.lt]: dayStart },
                },
                attributes: ['task_id', 'title', 'end_date'],
                raw: true,
            });

            if (!completedOverdueTasks.length) {
                return {
                    inserted: 0,
                    scanned: 0,
                    skipped: 0,
                    note: 'no completed overdue tasks',
                    overdueScanned,
                    overdueMarked,
                    overdueSample,
                };
            }

            const taskIds = completedOverdueTasks.map(t => t.task_id);

            // Ambil semua assignee aktif (defaultScope TaskAssignment sudah exclude deleted)
            const assigns = await TaskAssignment.findAll({
                where: { task_id: { [Op.in]: taskIds } },
                attributes: ['task_id', 'user_id'],
                raw: true,
            });

            if (!assigns.length) {
                return {
                    inserted: 0,
                    scanned: completedOverdueTasks.length,
                    skipped: 0,
                    note: 'no assignees',
                    overdueScanned,
                    overdueMarked,
                    overdueSample,
                };
            }

            // Map assignees per task
            const usersByTask = new Map();
            for (const a of assigns) {
                if (!usersByTask.has(a.task_id)) usersByTask.set(a.task_id, []);
                usersByTask.get(a.task_id).push(a.user_id);
            }

            // Siapkan pasangan (user_id, task_id)
            const allRefPairs = [];
            for (const t of completedOverdueTasks) {
                const users = usersByTask.get(t.task_id) || [];
                for (const uid of users) {
                    if (!uid) continue;
                    allRefPairs.push({ ref_id: t.task_id, user_id: uid });
                }
            }
            if (!allRefPairs.length) {
                return {
                    inserted: 0,
                    scanned: completedOverdueTasks.length,
                    skipped: 0,
                    note: 'no assignees after mapping',
                    overdueScanned,
                    overdueMarked,
                    overdueSample,
                };
            }

            const refIds = [...new Set(allRefPairs.map(p => p.ref_id))];

            // Cek existing (idempotent) — per (user_id, task_id, perf_config_id) di eventDate
            const existing = await PerformanceEventLog.findAll({
                where: {
                    perf_config_id: PERF_CONFIG_ID,
                    event_date: eventDate,
                    ref_id: { [Op.in]: refIds },
                },
                attributes: ['ref_id', 'user_id'],
                raw: true,
            });
            const existed = new Set(existing.map(e => `${e.user_id}:${e.ref_id}`));

            const byIdTitle = new Map(
                completedOverdueTasks.map(t => [t.task_id, t.title])
            );
            const byIdDeadline = new Map(
                completedOverdueTasks.map(t => [t.task_id, t.end_date])
            );

            const nowUnix = Math.floor(Date.now() / 1000);
            const rows = [];
            let skipped = 0;

            for (const { ref_id, user_id } of allRefPairs) {
                const key = `${user_id}:${ref_id}`;
                if (existed.has(key)) { skipped++; continue; }

                const deadlineUnix = byIdDeadline.get(ref_id);
                const deadlineYmd = deadlineUnix
                    ? dayjs.unix(deadlineUnix).tz(TZ).format('YYYY-MM-DD')
                    : null;

                rows.push({
                    user_id,
                    event_date: eventDate, // tanggal penyelesaian (hari ini)
                    period_year: periodYear,
                    period_month: periodMonth,
                    period_start_date: periodStart,
                    perf_config_id: PERF_CONFIG_ID,
                    score_value: SCORE_VALUE,
                    source: 'task',
                    ref_id,
                    note: `Complete Overdue Task: [#${ref_id}] ${byIdTitle.get(ref_id) || '(no title)'}`,
                    meta: JSON.stringify({
                        task_id: ref_id,
                        title: byIdTitle.get(ref_id) || null,
                        deadline: deadlineYmd,
                        status: 'completed_overdue',
                        bucket: 'overdue',
                    }),
                    created: nowUnix,
                    updated: nowUnix,
                });
            }

            if (dryRun) {
                return {
                    scanned: completedOverdueTasks.length,
                    inserted: 0,
                    skipped,
                    willInsert: rows.length,
                    sample: rows.slice(0, 5),
                    overdueScanned,
                    overdueMarked,
                    overdueSample,
                    dryRun: true,
                };
            }

            // Insert ke PerformanceEventLog
            let inserted = 0;
            if (rows.length) {
                const result = await PerformanceEventLog.bulkCreate(rows, { ignoreDuplicates: true });
                inserted = Array.isArray(result) ? result.length : 0;
            }

            return {
                inserted,
                scanned: completedOverdueTasks.length,
                skipped,
                overdueScanned,
                overdueMarked,
                overdueSample,
            };
        }, { ttlSec: 60 });

        if (res?.locked) {
            return new Response(
                JSON.stringify({ ok: false, rule: 'complete-overdue', date: eventDate, busy: true }),
                { status: 423 },
            );
        }

        return Response.json({
            ok: true,
            rule: 'complete-overdue',
            date: eventDate,
            ...res,
            ms: Date.now() - t0,
        });
    } catch (err) {
        console.error('[cron][complete-overdue] error:', err);
        return new Response(
            JSON.stringify({ ok: false, error: String(err?.message || err) }),
            { status: 500 },
        );
    }
}
