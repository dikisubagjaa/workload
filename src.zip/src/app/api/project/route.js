export const dynamic = 'force-dynamic';
export const revalidate = 0;

import { NextResponse } from 'next/server';
import { withActive } from "@/utils/session";
import db from '@/database/models';

const { Project, Client, ProjectTeam, User, ProjectType, Task, Sequelize } = db;
const { Op } = Sequelize;

export const GET = withActive(async function GET_HANDLER(req, context, currentUser) {
  try {
    // 1) Ambil list project + Client (alias sesuai model)
    const projects = await Project.findAll({
      where: { published: "published" },
      include: [
        { model: Client, as: "Client", attributes: ["client_id", "client_name"] },
      ],
      order: [["project_id", "DESC"]],
    });

    const rows = projects.map(p => p.toJSON());
    const projectIds = rows.map(p => p.project_id);

    // 2) Kumpulkan semua pt_id dari field JSON project.project_type
    const allPtIds = Array.from(
      new Set(
        rows
          .flatMap(p => Array.isArray(p.project_type) ? p.project_type : [])
          .map(v => Number.parseInt(v, 10))
          .filter(n => Number.isFinite(n))
      )
    );

    // 3) Ambil master ProjectType (sekali saja), buat map pt_id -> {pt_id, title}
    let ptMap = {};
    if (allPtIds.length) {
      const types = await ProjectType.findAll({
        where: { pt_id: { [Op.in]: allPtIds }, deleted: null },
        attributes: ["pt_id", "title"],
        order: [["pt_id", "ASC"]],
      });
      ptMap = Object.fromEntries(types.map(t => [t.pt_id, { pt_id: t.pt_id, title: t.title }]));
    }

    // 4) Ambil anggota dari project_team (gabungan pitching & task), include User
    let membersByProject = {};
    if (projectIds.length) {
      const pts = await ProjectTeam.findAll({
        where: { project_id: { [Op.in]: projectIds }, deleted: null },
        attributes: ["project_id", "user_id"],
        include: [{ model: User, as: "User", attributes: ["user_id", "fullname", "profile_pic"] }],
        order: [["project_id", "ASC"], ["user_id", "ASC"]],
      });

      for (const pt of pts) {
        const projId = pt.project_id;
        const u = pt.User;
        if (!u) continue;
        if (!membersByProject[projId]) membersByProject[projId] = [];
        const arr = membersByProject[projId];
        if (!arr.some(x => x.user_id === u.user_id)) {
          arr.push({
            user_id: u.user_id,
            fullname: u.fullname || "",
            profile_pic: u.profile_pic || null,
          });
        }
      }
    }

    // 5) Hitung progress berbasis TASK CHILD (parent_id != null), status todo === 'completed'
    //    defaultScope Task sudah exclude deleted.
    let progressByProject = {};
    if (projectIds.length) {
      const childTasks = await Task.findAll({
        where: {
          project_id: { [Op.in]: projectIds },
          parent_id: { [Op.ne]: null },        // hanya child task
        },
        attributes: ["task_id", "project_id", "todo"],
        order: [["project_id", "ASC"]],
      });

      for (const t of childTasks) {
        const pid = t.project_id;
        if (!progressByProject[pid]) progressByProject[pid] = { total: 0, done: 0 };
        progressByProject[pid].total += 1;
        if (t.todo === "completed") {
          progressByProject[pid].done += 1;
        }
      }
    }

    // 6) Sisipkan 'members', 'ProjectType' (mapping), dan progress counts
    const enriched = rows.map(p => {
      const pid = p.project_id;
      const prog = progressByProject[pid] || { total: 0, done: 0 };
      const remaining = Math.max(0, prog.total - prog.done);
      return {
        ...p,
        members: membersByProject[pid] || [],
        ProjectType: Array.isArray(p.project_type)
          ? p.project_type.map(v => ptMap[Number.parseInt(v, 10)]).filter(Boolean)
          : [],
        completed_task_count: prog.done,
        remaining_task_count: remaining,
      };
    });

    return NextResponse.json({ status: "success", data: enriched }, { status: 200 });
  } catch (error) {
    console.error("GET /project error:", error);
    return NextResponse.json({ status: "error", message: error.message }, { status: 500 });
  }
});
