export const dynamic = "force-dynamic";
export const revalidate = 0;

import { NextResponse } from "next/server";
import db from "@/database/models";
import { withActive } from "@/utils/session";

const { AnnualAssestment, MasterAnnualAssesmentPeriod } = db;

export const GET = withActive(async function GET_HANDLER(req, ctx, currentUser) {
  try {
    const { searchParams } = new URL(req.url);

    const yearParam = searchParams.get("year");
    const currentYear = new Date().getFullYear();
    const periodToYear = yearParam ? Number(yearParam) : currentYear;

    if (!Number.isFinite(periodToYear)) {
      return NextResponse.json({ error: "Invalid year" }, { status: 400 });
    }

    const staffId = Number(currentUser?.user_id);
    if (!Number.isFinite(staffId)) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    // ✅ ALWAYS: only my own assessment (no staffId param allowed)
    const row = await AnnualAssestment.findOne({
      where: {
        staff_id: staffId,
        period_to_year: periodToYear,
      },
      order: [["annual_assestment_id", "DESC"]],
      raw: true,
    });

    // period info (optional, buat UI kalau perlu)
    const periodRow = await MasterAnnualAssesmentPeriod.findOne({
      where: { year: periodToYear },
      raw: true,
    });

    if (!row) {
      return NextResponse.json(
        {
          data: null,
          period: periodRow
            ? {
                year: periodRow.year,
                open_at: periodRow.open_at,
                close_at: periodRow.close_at,
                is_active: periodRow.is_active,
              }
            : null,
        },
        { status: 200 }
      );
    }

    const periodFromYear = Number(row.period_from_year) || periodToYear - 1;
    const periodToYearOut = Number(row.period_to_year) || periodToYear;

    return NextResponse.json(
      {
        data: {
          annual_assestment_id: row.annual_assestment_id,
          staff_id: row.staff_id,
          hod_id: row.hod_id,
          status: row.status,
          staff_submitted_at: row.staff_submitted_at || null,
          created: row.created || null,
          period_from_year: periodFromYear,
          period_to_year: periodToYearOut,
        },
        period: periodRow
          ? {
              year: periodRow.year,
              open_at: periodRow.open_at,
              close_at: periodRow.close_at,
              is_active: periodRow.is_active,
            }
          : null,
      },
      { status: 200 }
    );
  } catch (error) {
    console.error("GET /annual-assestment/me error:", error);
    return NextResponse.json({ error: "Internal error" }, { status: 500 });
  }
});
