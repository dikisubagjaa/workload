export const dynamic = 'force-dynamic';
export const revalidate = 0;

import { NextResponse } from "next/server";
import db from "@/database/models";
import { withActive } from "@/utils/session";

const { Notification } = db;

// Util kecil untuk normalisasi userId agar tidak NaN
function normalizeUserId(u) {
  const raw = u?.user_id ?? u?.id ?? u?.userId;
  if (raw == null) return null;
  const n = typeof raw === "string" ? parseInt(raw, 10) : Number(raw);
  return Number.isFinite(n) && n > 0 ? n : null;
}

export const GET = withActive(async function GET_HANDLER(_req, _ctx, currentUser) {
  try {
    const userId = normalizeUserId(currentUser);
    if (!userId) {
      return NextResponse.json({ error: "Unauthenticated" }, { status: 401 });
    }

    const unread = await Notification.count({
      where: {
        user_id: userId,
        is_read: "false", // ENUM('true','false') → simpan string
      },
    });

    return NextResponse.json({ unread }, { status: 200 });
  } catch (err) {
    return NextResponse.json({ error: err?.message || "Failed" }, { status: 500 });
  }
});
