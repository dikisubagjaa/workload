export const dynamic = 'force-dynamic';
export const revalidate = 0;

import { NextResponse } from "next/server";
import { Department } from "@/database/models"; // Pastikan path sesuai dengan lokasi model
import dayjs from 'dayjs';

// Ambil semua profil dari database
export async function GET() {
    try {
        const Departments = await Department.findAll();
        return NextResponse.json({ departments: Departments }, { status: 200 });
    } catch (error) {
        console.error("Error fetching Departments:", error);
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}


export async function POST(req) {
    try {
        const body = await req.json();

        // Simpan data ke database
        const newDepartment = await Department.create({
            "title": body.title,
            "created": dayjs().format('YYYY-MM-DD HH:mm:ss'),
            "created_by": 1,
            "updated": dayjs().format('YYYY-MM-DD HH:mm:ss'),
            "updated_by": 1,
        });

        return NextResponse.json({ message: "Profil berhasil ditambahkan", Department: newDepartment });
    } catch (error) {
        console.error("Error adding Department:", error);
        return NextResponse.json({ error: "Gagal menambah profil" }, { status: 500 });
    }
}

