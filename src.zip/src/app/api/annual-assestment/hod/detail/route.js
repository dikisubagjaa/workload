export const dynamic = "force-dynamic";
export const revalidate = 0;

import { NextResponse } from "next/server";
import db from "@/database/models";
import { withActive } from "@/utils/session";

const { AnnualAssestment, User, MasterAnnualAssesmentQuestion } = db;

function normalizeBool(v) {
  return v === true || v === "true" || v === 1 || v === "1";
}

function getRunningPeriod() {
  const year = new Date().getFullYear();
  return { periodFromYear: year - 1, periodToYear: year };
}

function safeObj(val, fallback = null) {
  try {
    if (val == null) return fallback;
    if (typeof val === "object") return val;
    return JSON.parse(String(val));
  } catch {
    return fallback;
  }
}

async function loadQuestionsSnapshot(assestmentRow) {
  // prefer snapshot per assessment (biar konsisten walau master berubah)
  if (Array.isArray(assestmentRow?.questions_json) && assestmentRow.questions_json.length) {
    return assestmentRow.questions_json;
  }

  // fallback master
  const rows = await MasterAnnualAssesmentQuestion.findAll({
    where: {
      is_active: 1,
      deleted: null,
      deleted_by: null,
    },
    order: [
      ["section_key", "ASC"],
      ["sort_order", "ASC"],
      ["question_id", "ASC"],
    ],
  });

  return rows.map((q) => ({
    question_id: q.question_id,
    section_key: q.section_key,
    question_key: q.question_key,
    title: q.title,
    description: q.description,
    input_type: q.input_type,
    options_json: q.options_json,
    scale_min: q.scale_min,
    scale_max: q.scale_max,
    sort_order: q.sort_order,
  }));
}

function getPayloadFromRow(row, kind /* 'staff'|'hod' */) {
  if (!row) return null;

  if (kind === "staff") {
    if (row.staff_payload_json && typeof row.staff_payload_json === "object") return row.staff_payload_json;
    return safeObj(row.staff_payload_json, { answers: {} }) || { answers: {} };
  }

  if (row.hod_payload_json == null) return null;
  if (row.hod_payload_json && typeof row.hod_payload_json === "object") return row.hod_payload_json;
  return safeObj(row.hod_payload_json, null);
}

export const GET = withActive(async function GET_HANDLER(req, ctx, currentUser) {
  try {
    // ✅ HOD only
    if (!normalizeBool(currentUser?.is_hod)) {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    }

    const url = new URL(req.url);
    const staffIdParam = url.searchParams.get("staffId");
    const staffId = Number(staffIdParam);

    if (!staffId || Number.isNaN(staffId)) {
      return NextResponse.json({ error: "Invalid staffId" }, { status: 400 });
    }

    const yearParam = url.searchParams.get("year");
    const { periodToYear } = getRunningPeriod();
    const year = yearParam ? Number(yearParam) : periodToYear;

    if (!year || Number.isNaN(year)) {
      return NextResponse.json({ error: "Invalid year" }, { status: 400 });
    }

    // ✅ get assessment that belongs to this HOD
    const assessment = await AnnualAssestment.findOne({
      where: {
        staff_id: staffId,
        hod_id: currentUser.user_id,
        period_to_year: year,
      },
      order: [["annual_assestment_id", "DESC"]],
      include: [
        {
          model: User,
          as: "staff",
          attributes: ["user_id", "fullname", "name", "email", "department_id"],
          required: false,
        },
      ],
    });

    if (!assessment) {
      return NextResponse.json({ error: "Assessment not found" }, { status: 404 });
    }

    const questions = await loadQuestionsSnapshot(assessment);

    // staff payload always exists (NOT NULL)
    const staffPayload = getPayloadFromRow(assessment, "staff") || { answers: {} };
    const hodPayload = getPayloadFromRow(assessment, "hod"); // can be null (belum diisi)

    const staff = assessment.staff
      ? {
          user_id: assessment.staff.user_id,
          fullname: assessment.staff.fullname || assessment.staff.name || null,
          name: assessment.staff.name || null,
          email: assessment.staff.email || null,
          department_id: assessment.staff.department_id ?? null,
        }
      : {
          user_id: staffId,
          fullname: null,
          name: null,
          email: null,
          department_id: null,
        };

    // assessment data minimal (yang FE butuhin)
    const assessmentSlim = {
      annual_assestment_id: assessment.annual_assestment_id,
      staff_id: assessment.staff_id,
      hod_id: assessment.hod_id,
      period_from_year: assessment.period_from_year,
      period_to_year: assessment.period_to_year,
      status: assessment.status,
      staff_submitted_at: assessment.staff_submitted_at || assessment.submitted_at || null,
      hod_submitted_at: assessment.hod_submitted_at || null,
      created: assessment.created || null,
      updated: assessment.updated || null,
    };

    return NextResponse.json(
      {
        data: {
          staff,
          assessment: assessmentSlim,
          questions,
          staffPayload,
          hodPayload,
        },
      },
      { status: 200 }
    );
  } catch (error) {
    console.error("GET /annual-assestment/hod/detail error:", error);
    return NextResponse.json(
      { error: error?.message || "Internal error" },
      { status: 500 }
    );
  }
});
