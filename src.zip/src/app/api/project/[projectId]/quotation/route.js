export const dynamic = "force-dynamic";
export const revalidate = 0;

import { NextResponse } from "next/server";
import db from "@/database/models";
import { withAuth } from "@/utils/session";
import dayjs from "dayjs";
import { writeFile } from "fs/promises";
import path from "path";
import fs from "fs";

const { ProjectQuotation, ProjectPurchaseOrder } = db;

/**
 * Save quotation file into: storage/project/quotation/<filename>
 * Return stored filename only (basename), NOT "/uploads/..."
 */
async function saveQuotationFile(file) {
  const bytes = await file.arrayBuffer();
  const buffer = Buffer.from(bytes);

  const fileExtension = path.extname(file.name || "");
  const uniqueSuffix = Date.now() + "-" + Math.round(Math.random() * 1e9);
  const storedFilename = `${uniqueSuffix}${fileExtension}`;

  const uploadDir = path.join(process.cwd(), "storage", "project", "quotation");
  const filePath = path.join(uploadDir, storedFilename);

  if (!fs.existsSync(uploadDir)) {
    fs.mkdirSync(uploadDir, { recursive: true });
  }

  await writeFile(filePath, buffer);
  return storedFilename;
}

/**
 * GET handler to fetch all quotations for a project, including their associated POs.
 */
export const GET = withAuth(async function GET_HANDLER(req, { params }) {
  const { projectId } = params;
  try {
    const quotations = await ProjectQuotation.findAll({
      where: {
        project_id: projectId,
        deleted: null,
      },
      include: [
        {
          model: ProjectPurchaseOrder,
          as: "PurchaseOrderByQuotation", // Sesuai dengan alias di model
          where: { deleted: null },
          required: false, // LEFT JOIN agar quotation tanpa PO tetap muncul
        },
      ],
      order: [["created", "DESC"]],
    });

    return NextResponse.json({ status: "success", data: quotations });
  } catch (error) {
    console.error("Error fetching quotations:", error);
    return NextResponse.json(
      { status: "error", message: "Failed to fetch quotations." },
      { status: 500 }
    );
  }
});

/**
 * POST handler to upload a new quotation.
 */
export const POST = withAuth(async function POST_HANDLER(req, { params }, currentUser) {
  const { projectId } = params;

  try {
    const formData = await req.formData();
    const file = formData.get("file");
    const quotationNumber = formData.get("quotation_number");

    if (!file || !quotationNumber) {
      return NextResponse.json(
        { status: "error", message: "Quotation file and number are required." },
        { status: 400 }
      );
    }

    const storedFilename = await saveQuotationFile(file);

    const nowUnix = dayjs().unix();
    const newQuotation = await ProjectQuotation.create({
      project_id: projectId,
      quotation_number: quotationNumber,
      quotation_doc: storedFilename, // ✅ basename only
      created: nowUnix,
      created_by: currentUser.user_id,
      updated: nowUnix,
      updated_by: currentUser.user_id,
    });

    return NextResponse.json(
      {
        status: "success",
        message: "Quotation uploaded successfully!",
        data: newQuotation,
      },
      { status: 201 }
    );
  } catch (error) {
    console.error("Error uploading quotation:", error);
    return NextResponse.json(
      { status: "error", message: "Failed to upload quotation." },
      { status: 500 }
    );
  }
});
