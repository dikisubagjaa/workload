export const dynamic = "force-dynamic";
export const revalidate = 0;

import { NextResponse } from "next/server";
import db from "@/database/models";
import { withActive } from "@/utils/session";

// optional notifier (kalau ada di project kamu)
let notifier = null;
try {
  // kalau path kamu beda, ganti sesuai project
  // eslint-disable-next-line global-require, import/no-unresolved
  notifier = require("@/utils/notifier");
} catch (e) {
  notifier = null;
}

const { AnnualAssestment, User } = db;

function normalizeBool(v) {
  return v === true || v === "true" || v === 1 || v === "1";
}

function safeObj(val, fallback = null) {
  try {
    if (val == null) return fallback;
    if (typeof val === "object") return val;
    return JSON.parse(String(val));
  } catch {
    return fallback;
  }
}

function normalizePayload(payload) {
  // payload harus bentuk { answers: { ... } }
  const p = safeObj(payload, null) || payload;
  if (!p || typeof p !== "object") return { answers: {} };
  if (!p.answers || typeof p.answers !== "object") return { answers: {} };
  return { answers: p.answers };
}

async function assertHodAccess(currentUser, staffId, periodToYear) {
  const row = await AnnualAssestment.findOne({
    where: {
      staff_id: staffId,
      hod_id: currentUser.user_id,
      period_to_year: periodToYear,
    },
    order: [["annual_assestment_id", "DESC"]],
  });

  if (!row) {
    const err = new Error("Assessment not found");
    err.statusCode = 404;
    throw err;
  }

  return row;
}

function canFinalizeStatus(status) {
  return status === "submitted_by_staff" || status === "reviewed_by_hod";
}

async function trySendFinalizedNotif({ staffUser, hodUser, staffId, year }) {
  if (!notifier || !notifier.sendNotification) return;

  try {
    await notifier.sendNotification({
      type: "annual_assessment_finalized",
      title: "Annual Review Finalized",
      message: "Your annual review has been finalized. Please check the PDF.",
      toUserId: staffUser?.user_id || staffId,
      meta: { year },
      fromUserId: hodUser?.user_id || null,
    });
  } catch (e) {
    // jangan bikin finalize gagal gara-gara notif
    console.error("annual_assestment hod submit notifier error:", e);
  }
}

export const POST = withActive(async function POST_HANDLER(req, ctx, currentUser) {
  try {
    // ✅ HOD only
    if (!normalizeBool(currentUser?.is_hod)) {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    }

    const body = await req.json();
    const staffId = Number(body?.staffId);

    if (!staffId || Number.isNaN(staffId)) {
      return NextResponse.json({ error: "Invalid staffId" }, { status: 400 });
    }

    const payload = normalizePayload(body?.payload);

    // year periode berjalan
    const year = new Date().getFullYear();
    const periodToYear = year;

    // ✅ scope check
    const row = await assertHodAccess(currentUser, staffId, periodToYear);

    // ✅ status check: staff harus sudah submit
    if (!canFinalizeStatus(row.status)) {
      return NextResponse.json(
        { error: "Cannot finalize. Staff has not submitted yet." },
        { status: 400 }
      );
    }

    const now = Math.floor(Date.now() / 1000);

    // simpan HOD payload + answers_json (biar gampang dipakai FE/PDF)
    // (kalau table kamu gak punya hod_answers_json, remove field itu)
    const answersOnly = payload?.answers || {};

    await row.update({
      hod_payload_json: payload,
      hod_answers_json: answersOnly, // kalau kolom ini ada
      status: "finalized",
      hod_submitted_at: now,
      hod_submitted_by: currentUser.user_id,
      updated: now,
      updated_by: currentUser.user_id,
    });

    // Ambil staff user buat email/notif (kalau ada)
    let staffUser = null;
    let hodUser = null;
    try {
      const users = await User.findAll({
        where: { user_id: [staffId, currentUser.user_id] },
      });
      users.forEach((u) => {
        if (u.user_id === staffId) staffUser = u;
        if (u.user_id === currentUser.user_id) hodUser = u;
      });
    } catch (e) {
      // ignore
    }

    // Notif/email optional (tidak memblok finalize)
    await trySendFinalizedNotif({ staffUser, hodUser, staffId, year: periodToYear });

    return NextResponse.json(
      {
        message: "Finalized. PDF has been emailed to staff.",
        data: {
          annual_assestment_id: row.annual_assestment_id,
          staff_id: row.staff_id,
          hod_id: row.hod_id,
          status: row.status,
          period_to_year: row.period_to_year,
          hod_submitted_at: row.hod_submitted_at,
        },
      },
      { status: 200 }
    );
  } catch (error) {
    console.error("POST /annual-assestment/hod/submit error:", error);
    const code = error?.statusCode || 500;
    return NextResponse.json(
      { error: error?.message || "Internal error" },
      { status: code }
    );
  }
});
