// src/app/api/webhook/office-ip/route.js
export const dynamic = "force-dynamic";
export const revalidate = 0;

import { NextResponse } from "next/server";
import dayjs from "dayjs";
import db from "@/database/models";

const { AttendanceConfig } = db;

function getClientPublicIp(headers) {
  const xff = headers.get?.("x-forwarded-for") || headers["x-forwarded-for"];
  if (xff) {
    const parts = xff.split(",").map((s) => s.trim()).filter(Boolean);
    if (parts.length > 0) return parts[0];
  }
  const rip = headers.get?.("x-real-ip") || headers["x-real-ip"];
  if (rip) return rip;
  const cip = headers.get?.("cf-connecting-ip") || headers["cf-connecting-ip"];
  if (cip) return cip;
  return null;
}

function unauthorized(msg = "Unauthorized") {
  return NextResponse.json({ error: msg }, { status: 401 });
}

export async function POST(req) {
  try {
    const secret = req.headers.get("x-office-webhook-secret") || "";
    const expected = process.env.OFFICE_WEBHOOK_SECRET || "";

    if (!expected) {
      return NextResponse.json(
        { error: "OFFICE_WEBHOOK_SECRET is not set on server." },
        { status: 500 }
      );
    }

    if (!secret || secret !== expected) {
      return unauthorized();
    }

    const ip = getClientPublicIp(req.headers) || "0.0.0.0";
    if (!ip || ip === "0.0.0.0") {
      return NextResponse.json({ error: "Unable to detect client IP." }, { status: 400 });
    }

    // optional body: { label, note }
    let body = {};
    try {
      body = await req.json();
    } catch {
      body = {};
    }

    const label = String(body?.label || "Office").slice(0, 100);
    const note = body?.note != null ? String(body.note) : null;

    const nowUnix = dayjs().unix();
    const systemUserId = parseInt(process.env.OFFICE_WEBHOOK_USER_ID || "1", 10) || 1;

    // upsert: kalau ip sudah ada aktif → update timestamp/note/label
    const existing = await AttendanceConfig.findOne({
      where: { ip, active: 1 },
    });

    if (existing) {
      await existing.update({
        label,
        note,
        updated: nowUnix,
        updated_by: systemUserId,
      });

      return NextResponse.json(
        { status: "success", message: "Office IP refreshed.", ip, id: existing.id },
        { status: 200 }
      );
    }

    // kalau belum ada → create baru
    const created = await AttendanceConfig.create({
      label,
      ip,
      active: 1,
      note,
      created: nowUnix,
      created_by: systemUserId,
      updated: nowUnix,
      updated_by: systemUserId,
    });

    return NextResponse.json(
      { status: "success", message: "Office IP registered.", ip, id: created.id },
      { status: 201 }
    );
  } catch (e) {
    console.error("[webhook/office-ip] error:", e);
    return NextResponse.json({ error: "Internal Server Error" }, { status: 500 });
  }
}
