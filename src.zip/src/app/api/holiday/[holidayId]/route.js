// src/app/api/holiday/[holidayId]/route.js
import { NextResponse } from "next/server";
import db from "@/database/models";
import dayjs from "dayjs";
import utc from "dayjs/plugin/utc";
import { withAuth } from "@/utils/session";

dayjs.extend(utc);

const { Holiday, Sequelize } = db;
const { Op } = Sequelize || {};
const nowUnix = () => dayjs().utc().unix();

const ALLOWED_TYPES = new Set(["holiday", "leave"]);

/**
 * GET /api/holiday/[holidayId]
 */
export const GET = withAuth(async function GET_HANDLER(_req, { params }, _currentUser) {
  try {
    const { holidayId } = params;

    const holiday = await Holiday.findByPk(holidayId);
    if (!holiday) {
      return NextResponse.json({ error: "Holiday not found." }, { status: 404 });
    }

    return NextResponse.json({ holiday: holiday.toJSON() }, { status: 200 });
  } catch (error) {
    console.error("Error fetching holiday detail:", error);
    return NextResponse.json(
      { error: error.message || "Failed to fetch holiday detail." },
      { status: 500 }
    );
  }
});

/**
 * PUT /api/holiday/[holidayId]
 * Body (JSON) — minimal 1 field:
 *  {
 *    "type": "holiday"|"leave",    // optional
 *    "date": "2025-05-01",         // optional
 *    "description": "Labour Day"   // optional
 *  }
 */
export const PUT = withAuth(async function PUT_HANDLER(req, { params }, currentUser) {
  try {
    const { holidayId } = params;
    const body = await req.json().catch(() => ({}));

    const fields = {};

    // Update type (NEW)
    if (body.type !== undefined) {
      const rawType = body.type;
      const type = rawType != null ? String(rawType).trim().toLowerCase() : "";

      if (!type) {
        return NextResponse.json({ error: "Field 'type' cannot be empty." }, { status: 400 });
      }

      if (!ALLOWED_TYPES.has(type)) {
        return NextResponse.json(
          { error: "Field 'type' must be 'holiday' or 'leave'." },
          { status: 400 }
        );
      }

      fields.type = type;
    }

    // Update date
    if (body.date !== undefined) {
      const rawDate = body.date;
      const date =
        rawDate != null && String(rawDate).trim() !== ""
          ? String(rawDate).trim().slice(0, 10)
          : "";

      if (!date) {
        return NextResponse.json({ error: "Field 'date' cannot be empty." }, { status: 400 });
      }

      if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) {
        return NextResponse.json(
          { error: "Field 'date' must be in format YYYY-MM-DD." },
          { status: 400 }
        );
      }

      // Cek duplikat tanggal di holiday lain
      if (Op?.ne) {
        const existing = await Holiday.findOne({
          where: {
            date,
            holiday_id: { [Op.ne]: holidayId },
          },
        });
        if (existing) {
          return NextResponse.json(
            { error: "Holiday for this date already exists." },
            { status: 400 }
          );
        }
      }

      fields.date = date;
    }

    // Update description
    if (body.description !== undefined) {
      const description = body.description != null ? String(body.description).trim() : "";

      if (!description) {
        return NextResponse.json({ error: "Field 'description' cannot be empty." }, { status: 400 });
      }

      if (description.length > 120) {
        return NextResponse.json(
          { error: "Field 'description' must not exceed 120 characters." },
          { status: 400 }
        );
      }

      fields.description = description;
    }

    if (Object.keys(fields).length === 0) {
      return NextResponse.json({ error: "No valid fields to update." }, { status: 400 });
    }

    const userId = currentUser?.user_id ?? currentUser?.id ?? null;
    if (!userId) {
      return NextResponse.json({ error: "Invalid current user (missing user_id)." }, { status: 500 });
    }

    const now = nowUnix();
    fields.updated = now;
    fields.updated_by = userId;

    const [updatedCount] = await Holiday.update(fields, {
      where: { holiday_id: holidayId },
    });

    if (updatedCount === 0) {
      return NextResponse.json(
        { error: "Holiday not found or no changes applied." },
        { status: 404 }
      );
    }

    const updatedHoliday = await Holiday.findByPk(holidayId);

    return NextResponse.json(
      { message: "Holiday updated", holiday: updatedHoliday?.toJSON() || null },
      { status: 200 }
    );
  } catch (error) {
    console.error("Error updating holiday:", error);
    return NextResponse.json(
      { error: error.message || "Failed to update holiday." },
      { status: 500 }
    );
  }
});

/**
 * DELETE /api/holiday/[holidayId]
 * Soft delete → isi deleted & deleted_by
 */
export const DELETE = withAuth(async function DELETE_HANDLER(_req, { params }, currentUser) {
  try {
    const { holidayId } = params;

    const userId = currentUser?.user_id ?? currentUser?.id ?? null;
    if (!userId) {
      return NextResponse.json({ error: "Invalid current user (missing user_id)." }, { status: 500 });
    }

    const now = nowUnix();

    const [deletedCount] = await Holiday.update(
      { deleted: now, deleted_by: userId },
      { where: { holiday_id: holidayId } }
    );

    if (deletedCount === 0) {
      return NextResponse.json({ error: "Holiday not found or already deleted." }, { status: 404 });
    }

    return NextResponse.json({ message: "Holiday deleted" }, { status: 200 });
  } catch (error) {
    console.error("Error deleting holiday:", error);
    return NextResponse.json(
      { error: error.message || "Failed to delete holiday." },
      { status: 500 }
    );
  }
});
