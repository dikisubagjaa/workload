// src/app/api/appraisal/question/route.js
export const dynamic = "force-dynamic";
export const revalidate = 0;

import { NextResponse } from "next/server";
import db from "@/database/models";
import { withActive } from "@/utils/session";

const { MasterAppraisalQuestion } = db;

export const GET = withActive(async function GET_HANDLER(req, ctx, currentUser) {
  try {
    const { searchParams } = new URL(req.url);
    const title = (searchParams.get("title") || "").trim();

    const where = {
      deleted: null,
      deleted_by: null,
      is_active: "true",
    };
    if (title) where.title = title;

    const rows = await MasterAppraisalQuestion.findAll({
      where,
      order: [
        ["sort_order", "ASC"],
        ["question_id", "ASC"],
      ],
    });

    return NextResponse.json({ ok: true, data: rows }, { status: 200 });
  } catch (error) {
    console.error("GET /api/appraisal/question error:", error);
    return NextResponse.json(
      { error: error?.message || "Failed to fetch questions." },
      { status: 500 }
    );
  }
});
