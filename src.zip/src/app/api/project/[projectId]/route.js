export const dynamic = "force-dynamic";
export const revalidate = 0;

import { NextResponse } from "next/server";
import { withActive } from "@/utils/session";
import dayjs from "dayjs";
import db from "@/database/models";
import { nowUnix } from "../../appraisal/_helper";

const { Project, Client, ProjectType, ProjectTeam, User, Sequelize } = db;
const { Op } = Sequelize;

/* =========================== Helpers =========================== */

/** Ambil projectId dari params atau query ?projectId / ?id (integer > 0) */
function parseProjectId(req, params) {
    const url = new URL(req.url);
    const qId = url.searchParams.get("projectId") ?? url.searchParams.get("id");
    const fromParams = params?.projectId ?? params?.project_id;
    const parsed = Number.parseInt(qId || fromParams, 10);
    return Number.isFinite(parsed) && parsed > 0 ? parsed : null;
}

/** Jadikan input jadi array (terima string "1,2,3", JSON, single value) */
function toArray(v) {
    if (Array.isArray(v)) return v;
    if (v == null) return [];
    if (typeof v === "string") {
        const s = v.trim();
        if (!s) return [];
        // coba parse JSON array, kalau gagal pakai split koma
        if ((s.startsWith("[") && s.endsWith("]")) || (s.startsWith("{") && s.endsWith("}"))) {
            try {
                const parsed = JSON.parse(s);
                if (Array.isArray(parsed)) return parsed;
                if (parsed != null) return [parsed];
            } catch { }
        }
        return s.split(",").map((x) => x.trim()).filter(Boolean);
    }
    return [v];
}

/** Ambil judul tipe project dari ProjectType berdasarkan project.project_type */
async function getProjectTypeTitles(project) {
    try {
        const raw = toArray(project?.project_type);
        const ids = raw
            .map((v) => (Number.isFinite(Number(v)) ? Number(v) : null))
            .filter((v) => v != null);
        if (!ids.length) return [];
        const rows = await ProjectType.findAll({
            where: { pt_id: { [Op.in]: ids }, deleted: null },
            attributes: ["pt_id", "title"],
            order: [["pt_id", "ASC"]],
        });
        return rows.map((r) => ({ pt_id: r.pt_id, title: r.title }));
    } catch {
        return [];
    }
}

/* ============================ GET ============================ */
export const GET = withActive(async function GET_HANDLER(req, { params }) {
    try {
        const projectId = parseProjectId(req, params);
        if (!projectId) {
            return NextResponse.json({ status: "error", message: "Project not found" }, { status: 404 });
        }

        const project = await Project.findOne({
            where: { project_id: projectId },
            include: [
                {
                    model: Client,
                    as: "Client",
                    attributes: [
                        "client_id",
                        "client_name",
                        "type",
                        "address",
                        "brand",
                        "pic_name",
                        "pic_email",
                        "pic_phone",
                        "finance_name",
                        "finance_email",
                        "finance_phone",
                    ],
                },
            ],
        });

        if (!project) {
            return NextResponse.json({ status: "error", message: "Project not found" }, { status: 404 });
        }

        const typeTitles = await getProjectTypeTitles(project);

        // === Team members untuk project ini ===
        let members = [];
        try {
            const pts = await ProjectTeam.findAll({
                where: { project_id: projectId, deleted: null },
                attributes: ["project_id", "user_id"],
                include: [{ model: User, as: "User", attributes: ["user_id", "fullname", "profile_pic"] }],
                order: [["project_id", "ASC"], ["user_id", "ASC"]],
            });
            const dedup = new Map();
            for (const pt of pts) {
                const u = pt?.User;
                if (!u) continue;
                if (!dedup.has(u.user_id)) {
                    dedup.set(u.user_id, {
                        user_id: u.user_id,
                        fullname: u.fullname || "",
                        profile_pic: u.profile_pic || null,
                    });
                }
            }
            members = Array.from(dedup.values());
        } catch {
            members = [];
        }

        return NextResponse.json(
            { status: "success", data: { ...project.get(), project_type_titles: typeTitles, members } },
            { status: 200 },
        );
    } catch (error) {
        console.error("GET /api/project/[projectId] error:", error);
        return NextResponse.json({ status: "error", message: error.message }, { status: 500 });
    }
});

/* ============================ PUT ============================ */
export const PUT = withActive(async function PUT_HANDLER(req, { params }, currentUser) {
    try {
        const projectId = parseProjectId(req, params);
        if (!projectId) {
            return NextResponse.json({ status: "error", message: "Project not found" }, { status: 404 });
        }
        const nowUnix = dayjs().unix();
        const project = await Project.findOne({ where: { project_id: projectId } });
        if (!project) {
            return NextResponse.json({ status: "error", message: "Project not found" }, { status: 404 });
        }

        const payload = await req.json().catch(() => ({}));
        if (!payload || typeof payload !== "object") {
            return NextResponse.json({ status: "error", message: "Invalid payload" }, { status: 400 });
        }

        // Update minimal: terima semua key yang ada di model, update timestamp/by jika tersedia
        const current = project.get();
        const updates = {};
        for (const [k, v] of Object.entries(payload)) {
            if (Object.prototype.hasOwnProperty.call(current, k)) updates[k] = v;
        }
        if ("updated" in current) updates.updated = nowUnix;
        if ("updated_by" in current) updates.updated_by = currentUser?.user_id ?? null;

        await project.update(updates);

        // fetch ulang untuk balikan yang konsisten
        const fresh = await Project.findOne({
            where: { project_id: projectId },
            include: [
                {
                    model: Client,
                    as: "Client",
                    attributes: [
                        "client_id",
                        "client_name",
                        "type",
                        "address",
                        "brand",
                        "pic_name",
                        "pic_email",
                        "pic_phone",
                        "finance_name",
                        "finance_email",
                        "finance_phone",
                    ],
                },
            ],
        });

        const typeTitles = await getProjectTypeTitles(fresh);

        // === Team members (fresh) ===
        let members = [];
        try {
            const pts = await ProjectTeam.findAll({
                where: { project_id: projectId, deleted: null },
                attributes: ["project_id", "user_id"],
                include: [{ model: User, as: "User", attributes: ["user_id", "fullname", "profile_pic"] }],
                order: [["project_id", "ASC"], ["user_id", "ASC"]],
            });
            const dedup = new Map();
            for (const pt of pts) {
                const u = pt?.User;
                if (!u) continue;
                if (!dedup.has(u.user_id)) {
                    dedup.set(u.user_id, {
                        user_id: u.user_id,
                        fullname: u.fullname || "",
                        profile_pic: u.profile_pic || null,
                    });
                }
            }
            members = Array.from(dedup.values());
        } catch {
            members = [];
        }

        return NextResponse.json(
            { status: "success", message: "Project updated", data: { ...fresh.get(), project_type_titles: typeTitles, members } },
            { status: 200 },
        );
    } catch (error) {
        console.error("PUT /api/project/[projectId] error:", error);
        return NextResponse.json({ status: "error", message: error.message }, { status: 500 });
    }
});

/* ============================ DELETE (Soft delete) ============================ */
export const DELETE = withActive(async function DELETE_HANDLER(req, { params }, currentUser) {
    try {
        const projectId = parseProjectId(req, params);
        if (!projectId) {
            return NextResponse.json({ status: "error", message: "Project not found" }, { status: 404 });
        }

        const project = await Project.findOne({ where: { project_id: projectId } });
        if (!project) {
            return NextResponse.json({ status: "error", message: "Project not found" }, { status: 404 });
        }

        const attrs = project.get();
        const payload = {};
        if ("deleted" in attrs) payload.deleted = dayjs().format("YYYY-MM-DD HH:mm:ss");
        if ("deleted_by" in attrs) payload.deleted_by = currentUser?.user_id ?? null;
        if ("updated" in attrs) payload.updated = dayjs().format("YYYY-MM-DD HH:mm:ss");
        if ("updated_by" in attrs) payload.updated_by = currentUser?.user_id ?? null;
        if ("status" in attrs) payload.status = "archived";

        await project.update(payload);

        return NextResponse.json(
            { status: "success", message: "Project soft-deleted", project_id: projectId },
            { status: 200 },
        );
    } catch (error) {
        console.error("DELETE /api/project/[projectId] error:", error);
        return NextResponse.json({ status: "error", message: error.message }, { status: 500 });
    }
});
