// src/app/api/profile/[userId]/route.js
import { NextResponse } from "next/server";
import { User } from "@/database/models";
import { withAuth } from "@/utils/session";
import { uploadFile, getFilename } from "@/utils/imageHelpers";

// izin: diri sendiri / superadmin / hrd
function canAccess(currentUser, targetUserId) {
  if (!currentUser) return false;
  const role = currentUser.user_role || currentUser.role;
  const self = String(currentUser.user_id ?? currentUser.id ?? "") === String(targetUserId);
  return self || role === "superadmin" || role === "hrd";
}

// field yang boleh diupdate
const ALLOWED_FIELDS = [
  "job_position", "email", "phone",
  "fullname", "birthdate", "marital_status", "nationality", "status",
  "address", "address_on_identity",
  "identity_number", "identity_type", "npwp_number",
  "tax_start_date",
  "bank_code", "bank_account_number", "beneficiary_name", "currency",
  "bpjs_tk_number", "bpjs_tk_reg_date", "bpjs_tk_term_date",
  "bpjs_kes_number", "bpjs_kes_reg_date", "bpjs_kes_term_date",
  "pension_number",
  "emergency_fullname", "emergency_relationship",
  "emergency_contact", "emergency_address",
];

// subset publik saat viewer bukan pemilik/superadmin/hrd
const PUBLIC_FIELDS = [
  "user_id", "uuid", "profile_pic",
  "fullname",
  "job_position", "email", "phone",
  "birthdate", "marital_status", "nationality",
  "address", "address_on_identity",
  "join_date"
];
const pick = (obj, keys) => keys.reduce((acc, k) => {
  if (Object.prototype.hasOwnProperty.call(obj, k)) acc[k] = obj[k];
  return acc;
}, {});

export const GET = withAuth(async function GET_HANDLER(req, { params }, currentUser) {
  try {
    const param = params?.userId;
    if (!param) return NextResponse.json({ error: "Missing userId/uuid" }, { status: 400 });

    let user = null;
    if (/^\d+$/.test(param)) user = await User.findByPk(Number(param));
    else user = await User.findOne({ where: { uuid: param } });

    if (!user) return NextResponse.json({ error: "User not found" }, { status: 404 });

    // Biarkan logika aksesmu yang sekarang (full vs public) tetap berjalan.
    // INTI PERMINTAAN: profile_pic dikirim apa adanya (filename), FE yang bentuk path.
    return NextResponse.json({ user: user.toJSON() }, { status: 200 });
  } catch (err) {
    console.error("GET /profile/[userId] error:", err);
    return NextResponse.json({ error: "Failed to fetch user profile." }, { status: 500 });
  }
});


// PUT: wajib numeric user_id (tetap by ID)
export const PUT = withAuth(async function PUT_HANDLER(req, { params }, currentUser) {
  try {
    const param = params?.userId;
    if (!param) return NextResponse.json({ error: "Missing userId" }, { status: 400 });
    if (!/^\d+$/.test(param)) {
      return NextResponse.json({ error: "PUT requires numeric user_id in path" }, { status: 400 });
    }
    const userId = Number(param);
    if (!canAccess(currentUser, userId)) return NextResponse.json({ error: "Forbidden" }, { status: 403 });

    const body = await req.json();
    const user = await User.findByPk(userId);
    if (!user) return NextResponse.json({ error: "User not found" }, { status: 404 });

    if (user.status == "new") {
      body.status = "waiting";
    } else {
      // kalau bukan "new", jangan izinkan ubah status dari endpoint profile
      delete body.status;
    }

    await user.update(body, { fields: ALLOWED_FIELDS });
    return NextResponse.json({ message: "Profile updated", user: user.toJSON() }, { status: 200 });
  } catch (err) {
    console.error("PUT /profile/[userId] error:", err);
    return NextResponse.json({ error: "Failed to update user profile." }, { status: 500 });
  }
});

// POST: upload avatar via imageHelpers; wajib numeric user_id
export const POST = withAuth(async function POST_HANDLER(req, { params }, currentUser) {
  try {
    const param = params?.userId;
    if (!param) return NextResponse.json({ error: "Missing userId" }, { status: 400 });
    if (!/^\d+$/.test(param)) {
      return NextResponse.json({ error: "POST requires numeric user_id in path" }, { status: 400 });
    }
    const userId = Number(param);
    if (!canAccess(currentUser, userId)) return NextResponse.json({ error: "Forbidden" }, { status: 403 });

    const formData = await req.formData();
    const file = formData.get("file");
    if (!file) return NextResponse.json({ error: "No file uploaded" }, { status: 400 });

    const result = await uploadFile(file, "profile");
    const imageUrl = result?.resized;
    const filename = getFilename(imageUrl);

    const user = await User.findByPk(userId);
    if (!user) return NextResponse.json({ error: "User not found" }, { status: 404 });

    await user.update({ profile_pic: filename }, { fields: ["profile_pic"] });
    return NextResponse.json({ message: "Upload successful!", url: imageUrl }, { status: 200 });
  } catch (err) {
    console.error("POST /profile/[userId] upload error:", err);
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
});
