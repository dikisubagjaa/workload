import { User } from "@/database/models";
import { notify as notifyUser } from "@/utils/notifier";

export async function POST(req) {
    try {
        const body = await req.json();
        console.log(body)

        if (body.type == "select") {
            if (body.type === "select") {
                body.users.map((user_id) => {
                    try {
                        notifyUser({
                            userId: user_id,
                            sender: 'General',
                            description: body.message,
                            email: false,
                            url: "",
                            payload: "",
                        })
                    } catch (e) {
                        console.warn("Failed to send status change notification:", e?.message || e);
                    }
                });
            }
        } else if (body.type == "all") {
            const users = await User.findAll({ where: { status: "active" } });
            users.map((value) => {
                try {
                    notifyUser({
                        userId: value.user_id,
                        sender: 'General',
                        description: body.message,
                        email: false,
                        url: "",
                        payload: "",
                    })
                } catch (e) {
                    console.warn("Failed to send status change notification:", e?.message || e);
                }
            });
        }

        return Response.json(
            {
                message: "Blast Berhasil!",
                received: body,
            },
            { status: 201 }
        );
    } catch (error) {
        console.error("❌ Error in POST /api/blast:", error);
        return Response.json(
            { message: "Gagal memproses data", error: error.message },
            { status: 500 }
        );
    }
}



