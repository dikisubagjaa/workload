// src/app/api/user/export/route.js
export const dynamic = "force-dynamic";
export const revalidate = 0;

import { NextResponse } from "next/server";
import { withAuth } from "@/utils/session";
import { User } from "@/database/models";
import { Op } from "sequelize";

// hanya superadmin/hrd yg boleh export (ubah kalau perlu)
function canExport(currentUser) {
  if (!currentUser) return false;
  const role = currentUser.user_role || currentUser.role;
  return role === "superadmin" || role === "hrd";
}

// map sortBy FE -> kolom DB
const SORT_MAP = {
  fullname: "fullname",
  user_role: "user_role",
  department_id: "department_id",
  status: "status",
  is_hod: "is_hod",
  join_date: "join_date",
};

export const GET = withAuth(
  async function EXPORT_HANDLER(req, _ctx, currentUser) {
    try {
      if (!canExport(currentUser)) {
        return NextResponse.json({ error: "Forbidden" }, { status: 403 });
      }

      // 🔥 PENTING: jangan langsung new URL(req.url),
      // gunakan nextUrl kalau tersedia, baru fallback.
      const urlObj = "nextUrl" in req ? req.nextUrl : new URL(req.url);
      const searchParams = urlObj.searchParams;

      const page = Number(searchParams.get("page") || 1);
      const limit = Number(searchParams.get("limit") || 10000); // cap

      const q = (searchParams.get("q") || "").trim();
      const role = searchParams.get("role") || "";
      const departmentId = searchParams.get("department_id") || "";
      const status = searchParams.get("status") || "";
      const isHod = searchParams.get("is_hod") || ""; // "true" | "false" | ""

      const sortBy = SORT_MAP[searchParams.get("sortBy")] || "fullname";
      const sortDir =
        (searchParams.get("sortDir") || "asc").toUpperCase() === "DESC"
          ? "DESC"
          : "ASC";

      const where = {};

      if (q) {
        where[Op.or] = [
          { fullname: { [Op.like]: `%${q}%` } },
          { email: { [Op.like]: `%${q}%` } },
          { phone: { [Op.like]: `%${q}%` } },
        ];
      }

      if (role) where.user_role = role;
      if (departmentId) where.department_id = Number(departmentId);
      if (status) where.status = status;
      if (isHod) where.is_hod = isHod; // ENUM 'true'/'false'

      const rows = await User.findAll({
        where,
        order: [[sortBy, sortDir]],
        limit,
        offset: (page - 1) * limit,
        attributes: [
          "user_id",
          "fullname",
          "email",
          "phone",
          "user_role",
          "department_id",
          "status",
          "is_hod",
          "is_hrd",
          "is_operational_director",
          "join_date",
        ],
        raw: true,
      });

      // build CSV
      const headers = [
        "User ID",
        "Fullname",
        "Email",
        "Phone",
        "Role",
        "Department ID",
        "Status",
        "HOD",
        "HRD",
        "Operational Director",
        "Join Date",
      ];

      const escape = (v) => {
        if (v === null || v === undefined) return "";
        const s = String(v);
        return s.includes(",") || s.includes("\n") || s.includes('"')
          ? `"${s.replace(/"/g, '""')}"`
          : s;
      };

      const lines = [headers.join(",")];

      for (const r of rows) {
        lines.push(
          [
            r.user_id,
            r.fullname,
            r.email,
            r.phone,
            r.user_role,
            r.department_id,
            r.status,
            r.is_hod,
            r.is_hrd ? "true" : "false",
            r.is_operational_director ? "true" : "false",
            r.join_date ?? "",
          ]
            .map(escape)
            .join(",")
        );
      }

      const csv = lines.join("\n");

      return new NextResponse(csv, {
        status: 200,
        headers: {
          "Content-Type": "text/csv; charset=utf-8",
          "Content-Disposition": `attachment; filename="users_export.csv"`,
          "Cache-Control": "no-store",
        },
      });
    } catch (err) {
      console.error("GET /api/user/export error:", err);
      return NextResponse.json(
        { error: "Failed to export users." },
        { status: 500 }
      );
    }
  }
);
