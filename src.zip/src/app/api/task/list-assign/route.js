// src/app/api/task/list-assign/route.js
export const dynamic = "force-dynamic";
export const revalidate = 0;

import { NextResponse } from "next/server";
import db from "@/database/models";
import dayjs from "dayjs";
import utc from "dayjs/plugin/utc";
import { withAuth } from "@/utils/session";

dayjs.extend(utc);

const { Task, TaskAssignment, User, Project, Sequelize } = db;
const { Op } = Sequelize || {};

// === Status (baru + legacy utk kompatibilitas)
const DEFAULT_TODO_SET = [
  "new", "in_progress", "revision",
  "need_review_hod", "revise_hod",
  "need_review_ae", "revise_account", "approved_ae",
  "completed",
  "pending", "cancel", "todo", "review", "done",
];

export const GET = withAuth(async function GET_HANDLER(req, _ctx, currentUser) {
  try {
    const { searchParams } = new URL(req.url);

    // ======= QUERY PARAMS (dipertahankan lengkap) =======
    const scope = (searchParams.get("scope") || "me").toLowerCase(); // "me" | "teams" | "all"
    const statusesParam = searchParams.get("statuses");              // CSV of todo values
    const projectId = Number(searchParams.get("projectId"));
    const assigneesParam = searchParams.get("assignees");            // CSV user_id
    const q = (searchParams.get("q") || "").trim();                  // keyword search (judul)
    const category = (searchParams.get("category") || "").toLowerCase();
    const orderBy = (searchParams.get("orderBy") || "end_date").toLowerCase(); // end_date|created|updated
    const orderDir = (searchParams.get("orderDir") || "ASC").toUpperCase();    // ASC|DESC

    // ======= WHERE TASK =======
    const whereTask = {};
    const andFilters = [];

    // Filter status/todo (pakai set baru; tetap bisa override via ?statuses=a,b,c)
    let todoList = DEFAULT_TODO_SET;
    if (statusesParam) {
      todoList = statusesParam
        .split(",")
        .map((s) => s.trim().toLowerCase())
        .filter(Boolean);
    }
    andFilters.push({ todo: { [Op.in]: todoList } });

    // Filter project
    if (Number.isFinite(projectId)) {
      andFilters.push({ project_id: projectId });
    }

    // Pencarian judul (ringan)
    if (q) {
      andFilters.push({ title: { [Op.substring]: q } });
    }

    // ======= (Opsional) Kategori umum yang sering dipakai =======
    // NB: Kalau kamu sudah punya kategori lain, tinggal tambahkan di switch ini.
    const now = dayjs();
    const todayStart = now.startOf("day").unix();
    const todayEnd = now.endOf("day").unix();
    const thisWeekEnd = now.endOf("week").unix();

    switch (category) {
      case "due_today":
        andFilters.push({ end_date: { [Op.gte]: todayStart, [Op.lte]: todayEnd } });
        break;
      case "overdue":
        andFilters.push({ end_date: { [Op.lt]: todayStart } });
        break;
      case "this_week":
        andFilters.push({ end_date: { [Op.gte]: todayStart, [Op.lte]: thisWeekEnd } });
        break;
      case "completed":
        andFilters.push({ todo: "completed" });
        break;
      case "need_review_hod":
        andFilters.push({ todo: "need_review_hod" });
        break;
      case "need_review_ae":
        andFilters.push({ todo: "need_review_ae" });
        break;
      // tambahkan kategori lain kalau memang ada di FE kamu
      case "total_task":
      default:
        // no-op
        break;
    }

    if (andFilters.length) {
      whereTask[Op.and] = andFilters;
    }

    // ======= INCLUDE / ASSIGNMENT (scope) =======
    let assignedInclude = {
      model: User,
      as: "AssignedUser",
      attributes: ["user_id", "fullname", "email"],
      through: { attributes: [] },
    };
    let includeRequired = false;

    if (scope === "me") {
      includeRequired = true;
      assignedInclude = {
        ...assignedInclude,
        where: { user_id: currentUser.user_id },
        required: true,
      };
    } else if (scope === "teams") {
      includeRequired = true; // tampilkan semua task yang punya assignee
      assignedInclude = { ...assignedInclude, required: true };
    } else {
      // "all" → biarkan include tanpa filter
      includeRequired = false;
    }

    // Filter assignees (?assignees=1,2,3) saat scope bukan "me"
    if (scope !== "me" && assigneesParam) {
      const ids = assigneesParam
        .split(",")
        .map((s) => Number(s.trim()))
        .filter((n) => Number.isFinite(n));
      if (ids.length) {
        includeRequired = true;
        assignedInclude = {
          ...assignedInclude,
          where: { user_id: { [Op.in]: ids } },
          required: true,
        };
      }
    }

    // ======= QUERY =======
    const tasks = await Task.findAll({
      where: whereTask,
      include: [
        assignedInclude,
        { model: Project, as: "Project", attributes: ["project_id", "title"] },
      ],
      order: (() => {
        if (orderBy === "created") return [["created", orderDir]];
        if (orderBy === "updated") return [["updated", orderDir]];
        return [["end_date", orderDir], ["created", "ASC"]];
      })(),
      subQuery: false,
    });

    // ======= NORMALISASI OUTPUT (pertahankan alias status) =======
    // ======= NORMALISASI OUTPUT (pertahankan alias status) =======
    const normalized = tasks.map((t) => {
      const todo = (t.todo || "").toLowerCase();

      // total child & completed child dari kolom di Task
      const totalChildRaw =
        typeof t.count_task_child === "number"
          ? t.count_task_child
          : Number(t.count_task_child || 0);

      const completedChildRaw =
        typeof t.count_task_child_completed === "number"
          ? t.count_task_child_completed
          : Number(t.count_task_child_completed || 0);

      const totalChild = Number.isNaN(totalChildRaw) ? 0 : totalChildRaw;
      const completedChild = Number.isNaN(completedChildRaw) ? 0 : completedChildRaw;

      // progress dari subtask: completed / total * 100
      let progressFromChild = null;
      if (totalChild > 0) {
        const ratio = (completedChild / totalChild) * 100;
        const clamped = Math.max(0, Math.min(100, Math.round(ratio)));
        progressFromChild = clamped;
      }

      // fallback kalau belum ada data child progress
      const progress =
        progressFromChild !== null
          ? progressFromChild
          : typeof t.progress === "number"
            ? t.progress
            : todo === "done" || todo === "completed"
              ? 100
              : 0;

      return {
        task_id: t.task_id,
        title: t.title,
        description: t.description,

        // 🔹 info parent & child count ikut diexpose
        parent_id: t.parent_id ?? null,
        count_task_child: totalChild,
        count_task_child_completed: completedChild,

        todo,
        status: todo, // kompatibel dengan FE lama
        progress,
        start_date: t.start_date ?? null,
        end_date: t.end_date ?? null,
        project_id: t.project_id ?? null,
        project_title: t.Project?.title || null,
        created: t.created ?? null,
        updated: t.updated ?? null,
        assignedIds: (t.AssignedUser || []).map((u) => u.user_id),
        assignedName:
          (t.AssignedUser || []).map((u) => u.fullname).join(", ") || "-",
        client_review: t.client_review ?? 0,
      };
    });

    return NextResponse.json({ tasks: normalized }, { status: 200 });
  } catch (err) {
    console.error("Error list-assign:", err);
    return NextResponse.json(
      { error: "Gagal mengambil data task (assigned)" },
      { status: 500 }
    );
  }
});
