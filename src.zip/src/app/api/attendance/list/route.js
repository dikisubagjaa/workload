// src/app/api/attendance/list/route.js
export const dynamic = "force-dynamic";
export const revalidate = 0;

import { NextResponse } from "next/server";
import db from "@/database/models";
import dayjs from "dayjs";
import utc from "dayjs/plugin/utc";
import timezone from "dayjs/plugin/timezone";
import { withActive } from "@/utils/session";

dayjs.extend(utc);
dayjs.extend(timezone);
dayjs.tz.setDefault(process.env.NEXT_PUBLIC_APP_TIMEZONE || "Asia/Jakarta");

const { Attendance, User, Sequelize } = db;
const { Op } = Sequelize;

/** Helper: normalisasi YYYY-MM-DD (return null jika invalid) */
function toYMD(s) {
  const d = dayjs(String(s || "").trim(), "YYYY-MM-DD", true);
  return d.isValid() ? d.format("YYYY-MM-DD") : null;
}

/** Helper: range hari ini */
function rangeToday() {
  const d = dayjs().tz();
  const ymd = d.format("YYYY-MM-DD");
  return { from: ymd, to: ymd };
}

/** Helper: range kemarin */
function rangeYesterday() {
  const d = dayjs().tz().subtract(1, "day");
  const ymd = d.format("YYYY-MM-DD");
  return { from: ymd, to: ymd };
}

/** Helper: Senin..Minggu dari minggu tertentu (ISO-like) */
function rangeWeek(base, offsetWeeks = 0) {
  const d = base.add(offsetWeeks, "week");
  // dayjs: Minggu=0, Senin=1. Hitung mundur ke Senin.
  const dow = d.day(); // 0..6
  const toMonday = (dow + 6) % 7; // jarak ke Senin
  const monday = d.subtract(toMonday, "day").startOf("day");
  const sunday = monday.add(6, "day").startOf("day");
  return {
    from: monday.format("YYYY-MM-DD"),
    to: sunday.format("YYYY-MM-DD"),
  };
}

/** Mapping sortBy → real kolom */
function buildOrder(sortBy, sortDir) {
  const dir =
    String(sortDir || "desc").toLowerCase() === "asc" ? "ASC" : "DESC";
  const key = String(sortBy || "date").toLowerCase();

  if (key === "fullname") {
    // urutkan berdasarkan fullname
    return [[{ model: User, as: "User" }, "fullname", dir]];
  }
  if (key === "clock_in") return [["clock_in", dir]];
  if (key === "clock_out") return [["clock_out", dir]];
  if (key === "status") return [["status", dir]];

  // default: date DESC, fullname ASC
  return [
    ["date", dir],
    [{ model: User, as: "User" }, "fullname", "ASC"],
  ];
}

export const GET = withActive(async function GET_HANDLER(req, ctx, currentUser) {
    try {
      const { searchParams } = new URL(req.url);

      // (opsional) currentUser tersedia di sini kalau mau dipakai
      // const userId = currentUser?.user_id ?? currentUser?.id ?? null;

      // Pagination
      const page = Math.max(
        1,
        parseInt(searchParams.get("page") || "1", 10)
      );
      const limit = Math.min(
        50,
        Math.max(1, parseInt(searchParams.get("limit") || "10", 10))
      );
      const offset = (page - 1) * limit;

      // Period / range tanggal
      const period = (searchParams.get("period") || "today").toLowerCase();
      let from = toYMD(searchParams.get("from"));
      let to = toYMD(searchParams.get("to"));

      if (period === "today") {
        ({ from, to } = rangeToday());
      } else if (period === "yesterday") {
        ({ from, to } = rangeYesterday());
      } else if (period === "thisweek") {
        ({ from, to } = rangeWeek(dayjs().tz(), 0));
      } else if (period === "lastweek") {
        ({ from, to } = rangeWeek(dayjs().tz(), -1));
      } else if (period === "period") {
        // gunakan from & to dari query
        if (!from || !to) {
          return NextResponse.json(
            {
              error:
                "from/to wajib diisi pada period=period (YYYY-MM-DD)",
            },
            { status: 400 }
          );
        }
      } else {
        // fallback aman → today
        ({ from, to } = rangeToday());
      }

      // Validasi range
      const dFrom = dayjs(from, "YYYY-MM-DD", true);
      const dTo = dayjs(to, "YYYY-MM-DD", true);
      if (!dFrom.isValid() || !dTo.isValid() || dFrom.isAfter(dTo)) {
        return NextResponse.json(
          {
            error:
              "Range tanggal tidak valid (from <= to, format YYYY-MM-DD)",
          },
          { status: 400 }
        );
      }

      // Filter status & pencarian
      const status = (searchParams.get("status") || "").trim();
      const q = (searchParams.get("q") || "").trim();

      // Sorting
      const sortBy = (searchParams.get("sortBy") || "date").trim();
      const sortDir = (searchParams.get("sortDir") || "desc").trim();
      const order = buildOrder(sortBy, sortDir);

      // WHERE untuk Attendance
      const whereAttendance = {
        deleted: null,
        date: { [Op.between]: [from, to] },
      };
      if (status) {
        whereAttendance.status = status;
      }

      // WHERE untuk User saat ada query 'q'
      let includeUserWhere = undefined;
      let includeRequired = false;
      if (q) {
        includeUserWhere = {
          [Op.or]: [
            { fullname: { [Op.like]: `%${q}%` } },
            { email: { [Op.like]: `%${q}%` } },
            { phone: { [Op.like]: `%${q}%` } },
          ],
        };
        includeRequired = true;
      }

      // Query utama
      const { rows, count } = await Attendance.findAndCountAll({
        where: whereAttendance,
        include: [
          {
            model: User,
            as: "User",
            required: includeRequired,
            where: includeUserWhere,
            attributes: [
              "user_id",
              "fullname",
              "email",
              "phone",
              "job_position",
            ],
          },
        ],
        order,
        limit,
        offset,
        distinct: true, // supaya count akurat saat include
        attributes: [
          "attendance_id",
          "user_id",
          "date",
          "clock_in",
          "clock_out",
          "status",
          "late_reason",
          "minutes_late",
          "notes",
        ],
      });

      // Bentuk output
      const data = rows.map((r) => {
        const a = r.toJSON();
        const u = a.User || {};
        return {
          attendance_id: a.attendance_id,
          user_id: a.user_id,
          date: a.date, // YYYY-MM-DD
          clock_in: a.clock_in ?? null, // unix seconds
          clock_out: a.clock_out ?? null, // unix seconds
          status: a.status,
          late_reason: a.late_reason ?? null,
          minutes_late: Number(a.minutes_late ?? 0),
          notes: a.notes ?? null,
          user: {
            user_id: u.user_id ?? null,
            fullname: u.fullname ?? null,
            email: u.email ?? null,
            phone: u.phone ?? null,
            job_position: u.job_position ?? null,
          },
        };
      });

      return NextResponse.json(
        { ok: true, data, meta: { page, limit, total: count } },
        { status: 200 }
      );
    } catch (err) {
      console.error("GET /api/attendance/list error:", err);
      return NextResponse.json(
        {
          error: err?.message || "Failed to fetch attendance list",
        },
        { status: 500 }
      );
    }
  }
);
