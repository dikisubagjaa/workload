// src/app/api/leave/annual-quota/route.js
export const dynamic = "force-dynamic";
export const revalidate = 0;

import { NextResponse } from "next/server";
import db from "@/database/models";
import dayjs from "dayjs";
import utc from "dayjs/plugin/utc";
import timezone from "dayjs/plugin/timezone";
import { withActive } from "@/utils/session";
import { getLeaveYearRange } from "@/utils/leaveYear";

dayjs.extend(utc);
dayjs.extend(timezone);
dayjs.tz.setDefault(process.env.NEXT_PUBLIC_APP_TIMEZONE || "Asia/Jakarta");

const { LeaveRequest, LeaveConfig, Holiday, Sequelize } = db;
const { Op } = Sequelize;

function getUserId(u) {
  return u?.user_id ?? u?.id ?? u?.userId ?? null;
}

function isWeekendYMD(ymd) {
  const d = dayjs(ymd, "YYYY-MM-DD", true);
  if (!d.isValid()) return false;
  const dow = d.day();
  return dow === 0 || dow === 6;
}

function isAnnualLeaveReason(reason) {
  if (!reason) return false;
  return String(reason).toLowerCase().trim().startsWith("cuti tahunan");
}

function countAnnualChargeDays(startYmd, endYmd, publicHolidaySet) {
  let d = dayjs(startYmd, "YYYY-MM-DD", true);
  const end = dayjs(endYmd, "YYYY-MM-DD", true);
  if (!d.isValid() || !end.isValid()) return 0;

  let count = 0;

  // ✅ ganti isSameOrBefore -> !isAfter
  while (!d.isAfter(end, "day")) {
    const ymd = d.format("YYYY-MM-DD");
    if (!isWeekendYMD(ymd) && !publicHolidaySet.has(ymd)) count += 1;
    d = d.add(1, "day");
  }

  return count;
}


async function getAnnualQuota() {
  let annualQuota = 12;
  const cfg = await LeaveConfig.findOne({
    where: { title: { [Op.like]: "Cuti Tahunan%" } },
    raw: true,
  });
  if (cfg && cfg.total != null) annualQuota = Number(cfg.total) || annualQuota;
  return annualQuota;
}

async function getPublicHolidaySet(yearStart, yearEnd) {
  const rows = await Holiday.findAll({
    where: {
      date: { [Op.between]: [yearStart, yearEnd] },
      type: "holiday",
    },
    attributes: ["date"],
    raw: true,
  });
  return new Set(rows.map((r) => r.date));
}

async function getJointLeaveCount(yearStart, yearEnd) {
  const rows = await Holiday.findAll({
    where: {
      date: { [Op.between]: [yearStart, yearEnd] },
      type: "leave",
    },
    attributes: ["date"],
    raw: true,
  });

  let cnt = 0;
  for (const r of rows) {
    if (!isWeekendYMD(r.date)) cnt += 1;
  }
  return cnt;
}

async function getUsedAnnualDays(uid, yearStart, yearEnd, publicHolidaySet) {
  const rows = await LeaveRequest.findAll({
    where: {
      user_id: uid,
      deleted: null,
      status: "approved",
      start_date: { [Op.lte]: yearEnd },
      end_date: { [Op.gte]: yearStart },
    },
    attributes: ["start_date", "end_date", "reason"],
    raw: true,
  });

  let used = 0;

  for (const r of rows) {
    if (!isAnnualLeaveReason(r.reason)) continue;

    const s = dayjs(r.start_date, "YYYY-MM-DD", true);
    const e = dayjs(r.end_date, "YYYY-MM-DD", true);
    if (!s.isValid() || !e.isValid()) continue;

    const effStart = s.isBefore(yearStart, "day") ? yearStart : s.format("YYYY-MM-DD");
    const effEnd = e.isAfter(yearEnd, "day") ? yearEnd : e.format("YYYY-MM-DD");

    used += countAnnualChargeDays(effStart, effEnd, publicHolidaySet);
  }

  return used;
}

export const GET = withActive(async function GET_HANDLER(req, _ctx, currentUser) {
  try {
    const uid = getUserId(currentUser);
    if (!uid) return NextResponse.json({ error: "Unauthenticated" }, { status: 401 });

    const { searchParams } = new URL(req.url);
    const anchor = (searchParams.get("anchor") || "").trim(); // optional YYYY-MM-DD
    const anchorYmd = anchor || dayjs().tz().format("YYYY-MM-DD");

    const { yearStart, yearEnd } = getLeaveYearRange(anchorYmd, 4, 1);

    const annualQuota = await getAnnualQuota();
    const publicHolidaySet = await getPublicHolidaySet(yearStart, yearEnd);
    const usedAnnual = await getUsedAnnualDays(uid, yearStart, yearEnd, publicHolidaySet);
    const jointLeaveCount = await getJointLeaveCount(yearStart, yearEnd);

    const remaining = annualQuota - (usedAnnual + jointLeaveCount);

    return NextResponse.json(
      {
        ok: true,
        annualQuota,
        usedAnnual,
        jointLeaveCount,
        remaining,
        leaveYear: { yearStart, yearEnd },
      },
      { status: 200 }
    );
  } catch (e) {
    console.error("GET /api/leave/annual-quota error:", e);
    return NextResponse.json({ error: e?.message || "Failed" }, { status: 500 });
  }
});
