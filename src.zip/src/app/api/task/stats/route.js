// src/app/api/task/stats/route.js
export const dynamic = "force-dynamic";
export const revalidate = 0;

import { NextResponse } from "next/server";
import db from "@/database/models";
import { Op } from "sequelize";
import dayjs from "dayjs";
import { withAuth } from "@/utils/session";

const { Task, Project, TaskAssignment, User } = db;

function isTruthy(v) {
  return v === true || v === "true" || v === 1 || v === "1";
}

export const GET = withAuth(async function GET_HANDLER(req, { params }, currentUser) {
  try {
    const url = new URL(req.url);
    const staffIdParam = url.searchParams.get("staffId");

    const isSuperadmin = isTruthy(currentUser?.is_superadmin);

    let effectiveUserId = currentUser.user_id;

    // Superadmin boleh pilih staff
    if (isSuperadmin && staffIdParam) {
      const parsed = parseInt(staffIdParam, 10);
      if (!Number.isNaN(parsed) && parsed > 0) {
        const targetUser = await User.findOne({
          where: { user_id: parsed },
          attributes: ["user_id"],
        });

        if (!targetUser) {
          return NextResponse.json({ error: "Staff tidak ditemukan" }, { status: 404 });
        }

        effectiveUserId = targetUser.user_id;
      }
    }

    const nowStart = dayjs().startOf("day").unix();
    const todayEnd = dayjs().endOf("day").unix();
    const hPlus3 = dayjs().add(3, "day").endOf("day").unix();
    const hPlus7 = dayjs().add(7, "day").endOf("day").unix();

    const assignedInclude = [
      {
        model: TaskAssignment,
        as: "Assignments",
        where: { user_id: effectiveUserId },
        required: true,
      },
      { model: Project, as: "Project" },
    ];

    const dueToday = await Task.count({
      distinct: true,
      include: assignedInclude,
      where: { end_date: { [Op.gte]: nowStart, [Op.lte]: todayEnd } },
      subQuery: false,
    });

    // overdue: end_date < todayStart AND todo != completed (atau todo null)
    const overdue = await Task.count({
      distinct: true,
      include: assignedInclude,
      where: {
        end_date: { [Op.lt]: nowStart },
        [Op.or]: [
          { todo: { [Op.notIn]: ["completed"] } },
          { todo: null },
        ],
      },
      subQuery: false,
    });

    const critical = await Task.count({
      distinct: true,
      include: assignedInclude,
      where: { end_date: { [Op.gte]: nowStart, [Op.lte]: hPlus3 } },
      subQuery: false,
    });

    const dueThisWeek = await Task.count({
      distinct: true,
      include: assignedInclude,
      where: { end_date: { [Op.gte]: nowStart, [Op.lte]: hPlus7 } },
      subQuery: false,
    });

    const totalTask = await Task.count({
      distinct: true,
      include: assignedInclude,
      subQuery: false,
    });

    const needReview = await Task.count({
      distinct: true,
      include: assignedInclude,
      where: { todo: "need_review" },
      subQuery: false,
    });

    // Category harus match FE StatsBar
    const overview = [
      { title: "Due Today", category: "due_date", value: dueToday, cardBorder: "!border-l-4 border-[#00939F]" },
      { title: "Overdue Task", category: "overdue", value: overdue, cardBorder: "!border-l-4 border-[#EC221F]" },
      { title: "Critical Deadlines", category: "critical", value: critical, cardBorder: "!border-l-4 border-[#E8B931]" },
      { title: "Due This Week", category: "due_this_week", value: dueThisWeek, cardBorder: "!border-l-4 border-[#00939F]" },
      { title: "New task assigned", category: "new_task_assigned", value: 0, cardBorder: "!border-l-4 border-[#E8B931]" },
      { title: "Total Task", category: "total_task", value: totalTask, cardBorder: "!border-l-4 border-[#00939F]" },
      { title: "Need Review", category: "need_review", value: needReview, cardBorder: "!border-l-4 border-[#00939F]" },
    ];

    return NextResponse.json({ overview }, { status: 200 });
  } catch (error) {
    console.error("Error fetching task stats:", error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
});
