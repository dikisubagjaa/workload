import { NextResponse } from "next/server";
import { User } from "@/database/models"; // Pastikan path sesuai dengan lokasi model

// Ambil semua profil dari database
export async function GET() {
    try {
        const users = await User.findAll();
        return NextResponse.json(users);
    } catch (error) {
        console.error("Error fetching users:", error);
        return NextResponse.json({ error: "Gagal mengambil data" }, { status: 500 });
    }
}


export async function POST(req) {
    try {
        const body = await req.json();
        
        // Simpan data ke database
        const newUser = await User.create(body);

        return NextResponse.json({ message: "Profil berhasil ditambahkan", data: newUser });
    } catch (error) {
        console.error("Error adding user:", error);
        return NextResponse.json({ error: "Gagal menambah profil" }, { status: 500 });
    }
}

