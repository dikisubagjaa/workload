export const dynamic = 'force-dynamic';
export const revalidate = 0;

import { NextResponse } from "next/server";
import dayjs from "dayjs";
import db from "@/database/models";
import { withActive } from "@/utils/session";

const { Project } = db;

// helpers kecil
const toInt = (v, def = null) => {
  const n = Number(v);
  return Number.isFinite(n) ? n : def;
};
const toYMD = (v) => {
  if (!v) return null;
  try { return dayjs(v).format("YYYY-MM-DD"); } catch { return null; }
};

export const POST = withActive(async (req, ctx, currentUser) => {
  try {
    const body = await req.json();
    const userId = currentUser.user_id;
    const now = dayjs().unix();

    const {
      title,
      client_id,
      start_date,
      due_date,
      currency,
      currency_value,
      duration,
      terms_of_payment,
      max_hours,
      maintenance,
      project_type,
      teams, // ← array user_id dari form pitching
      status = "remaining",
      published = "published",
    } = body || {};

    // --- CREATE PROJECT (tetap seperti sebelumnya) ---
    const created = await Project.create({
      title,
      client_id: toInt(client_id),
      start_date: toYMD(start_date),
      due_date: toYMD(due_date),
      currency,
      currency_value: toInt(currency_value),
      duration: toInt(duration),
      terms_of_payment,
      max_hours: toInt(max_hours),
      maintenance,
      project_type: Array.isArray(project_type) ? project_type : [],
      teams: Array.isArray(teams) ? teams : [], // biarkan untuk backward compat
      type: "pitching",
      status,
      published,
      created: now,
      created_by: userId,
      updated: now,
      updated_by: userId,
    });

    // --- NEW: tulis ke project_team (tanpa butuh model ProjectTeam) ---
    // asumsikan tabel project_team sudah dibuat dengan SQL yang kita bahas sebelumnya
    const teamIds = Array.isArray(teams)
      ? teams.map((uid) => Number(uid)).filter(Number.isInteger)
      : [];

    if (teamIds.length) {
      // bulk insert (VALUES (...), (...), ...)
      const placeholders = teamIds.map(() => "(?,?,?,?,?,?,?,?)").join(",");
      const params = [];
      for (const uid of teamIds) {
        params.push(
          created.project_id,   // project_id
          null,                 // task_id (NULL untuk pitching)
          uid,                  // user_id
          "pitching",           // source
          now,                  // created
          userId,               // created_by
          now,                  // updated
          userId                // updated_by
        );
      }

      await db.sequelize.query(
        `INSERT INTO project_team
         (project_id, task_id, user_id, source, created, created_by, updated, updated_by)
         VALUES ${placeholders}`,
        { replacements: params }
      );
    }

    return NextResponse.json({ ok: true, data: created }, { status: 201 });
  } catch (err) {
    console.error("POST /api/pitching error:", err);
    return NextResponse.json({ error: err?.message || "Create pitching failed" }, { status: 500 });
  }
});
