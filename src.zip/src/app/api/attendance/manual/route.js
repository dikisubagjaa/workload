// src/app/api/attendance/manual/route.js
export const dynamic = "force-dynamic";
export const revalidate = 0;

import { NextResponse } from "next/server";
import db from "@/database/models";
import dayjs from "dayjs";
import utc from "dayjs/plugin/utc";
import timezone from "dayjs/plugin/timezone";
import { withActive } from "@/utils/session";
import { TZ } from "../_rules";

dayjs.extend(utc);
dayjs.extend(timezone);

const { Attendance, User } = db;

/**
 * POST /api/attendance/manual
 *
 * Body (camelCase):
 * {
 *   staffId: number;        // required (user_id target)
 *   date: string;           // required, "YYYY-MM-DD"
 *   status?: string;        // present|late|absent|leave|holiday|sick|permission (default "present")
 *   reason?: string;        // keterangan, kalau late → late_reason, lainnya → notes
 *   clockInUnix?: number;   // optional, detik unix
 *   clockOutUnix?: number;  // optional, detik unix
 *   minutesLate?: number;   // optional, kalau status = "late"
 * }
 */
export const POST = withActive(async function POST_MANUAL(req, _ctx, currentUser) {
  try {
    const operatorId =
      currentUser?.user_id || currentUser?.id || currentUser?.userId;
    if (!operatorId) {
      return NextResponse.json({ error: "Unauthenticated" }, { status: 401 });
    }

    // --- parse body ---
    let body = {};
    try {
      body = await req.json();
    } catch {
      body = {};
    }

    // staffId / user target
    const staffIdRaw =
      body.staffId ?? body.staff ?? body.userId ?? body.targetUserId;
    const staffId = Number(staffIdRaw);

    if (!staffId || Number.isNaN(staffId)) {
      return NextResponse.json(
        { error: "staffId is required" },
        { status: 400 }
      );
    }

    // tanggal
    const rawDate = body.date ?? body.presenceDate ?? body.presence_date;
    if (!rawDate) {
      return NextResponse.json(
        { error: "date is required" },
        { status: 400 }
      );
    }

    const d = dayjs(rawDate);
    if (!d.isValid()) {
      return NextResponse.json(
        { error: "date is invalid" },
        { status: 400 }
      );
    }
    const date = d.tz(TZ).format("YYYY-MM-DD");

    // status
    const allowedStatuses = [
      "present",
      "late",
      "absent",
      "leave",
      "holiday",
      "sick",
      "permission",
    ];

    let status = (body.status || "").toString().trim().toLowerCase();
    if (!status) status = "present";

    if (!allowedStatuses.includes(status)) {
      return NextResponse.json(
        { error: "Invalid status value" },
        { status: 400 }
      );
    }

    // pastikan user target ada
    const staff = await User.findOne({
      where: { user_id: staffId },
      attributes: ["user_id"],
    });

    if (!staff) {
      return NextResponse.json(
        { error: "Target user not found" },
        { status: 404 }
      );
    }

    const now = dayjs().tz(TZ);

    // parse jam (unix detik)
    const clockInUnix =
      body.clockInUnix != null && body.clockInUnix !== ""
        ? Number(body.clockInUnix)
        : null;
    const clockOutUnix =
      body.clockOutUnix != null && body.clockOutUnix !== ""
        ? Number(body.clockOutUnix)
        : null;

    if (
      (clockInUnix != null && Number.isNaN(clockInUnix)) ||
      (clockOutUnix != null && Number.isNaN(clockOutUnix))
    ) {
      return NextResponse.json(
        { error: "clockInUnix / clockOutUnix must be number (unix seconds)" },
        { status: 400 }
      );
    }

    // reason / notes
    const reason =
      (body.reason ||
        body.lateReason ||
        body.notes ||
        body.manualReason ||
        "")?.toString().trim() || null;

    // menit telat (optional)
    const minutesLateRaw = body.minutesLate;
    const minutesLate =
      typeof minutesLateRaw === "number"
        ? minutesLateRaw
        : minutesLateRaw != null && minutesLateRaw !== ""
        ? Number(minutesLateRaw)
        : 0;

    // cek apakah sudah ada attendance di tanggal itu
    let row = await Attendance.findOne({
      where: { user_id: staffId, date },
    });

    let durationMinutes = row?.duration_minutes ?? 0;

    // payload update/create
    const payload = {
      status,
      updated: now.unix(),
      updated_by: operatorId,
    };

    if (status === "late") {
      payload.late_reason = reason;
      if (!Number.isNaN(minutesLate) && minutesLate > 0) {
        payload.minutes_late = minutesLate;
      }
    } else {
      payload.late_reason = null;
      payload.minutes_late = 0;
      payload.notes = reason;
    }

    if (clockInUnix != null) {
      payload.clock_in = clockInUnix;
    }

    if (clockOutUnix != null) {
      payload.clock_out = clockOutUnix;

      const baseIn =
        clockInUnix != null
          ? clockInUnix
          : row?.clock_in != null
          ? row.clock_in
          : null;

      if (baseIn != null) {
        durationMinutes = Math.max(
          0,
          Math.floor((clockOutUnix - baseIn) / 60)
        );
        payload.duration_minutes = durationMinutes;
      }
    }

    // create / update
    let created = false;

    if (!row) {
      row = await Attendance.create({
        user_id: staffId,
        date,
        clock_in: payload.clock_in ?? null,
        clock_out: payload.clock_out ?? null,
        status: payload.status,
        late_reason: payload.late_reason ?? null,
        minutes_late:
          typeof payload.minutes_late === "number"
            ? payload.minutes_late
            : 0,
        duration_minutes:
          typeof payload.duration_minutes === "number"
            ? payload.duration_minutes
            : 0,
        notes: payload.notes ?? null,
        location_latitude: null,
        location_longitude: null,
        ip_address: null,
        device_info: `manual by user_id=${operatorId}`,
        created: now.unix(),
        updated: now.unix(),
        created_by: operatorId,
        updated_by: operatorId,
      });
      created = true;
    } else {
      await row.update(payload);
    }

    const json = row.toJSON ? row.toJSON() : row;

    return NextResponse.json(
      {
        ok: true,
        created,
        attendance: json,
      },
      { status: created ? 201 : 200 }
    );
  } catch (err) {
    console.error("POST /api/attendance/manual error:", err);
    return NextResponse.json(
      { error: err?.message || "Failed" },
      { status: 500 }
    );
  }
});
