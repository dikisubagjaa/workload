export const dynamic = "force-dynamic";
export const revalidate = 0;

import { NextResponse } from "next/server";
import db from "@/database/models";
import { withActive } from "@/utils/session";

const { Department, Sequelize } = db;
const { Op } = Sequelize;

function toInt(v, def) {
  const n = parseInt(String(v ?? ""), 10);
  return Number.isFinite(n) ? n : def;
}
function toStr(v) {
  return String(v ?? "").trim();
}

const SORT_WHITELIST = new Set([
  "department_id",
  "title",
  "description",
  "created",
  "updated",
]);

export const GET = withActive(async function GET_HANDLER(req) {
  try {
    const url = new URL(req.url);

    const q = toStr(url.searchParams.get("q"));
    const page = Math.max(1, toInt(url.searchParams.get("page"), 1));
    const limit = Math.min(200, Math.max(1, toInt(url.searchParams.get("limit"), 10)));
    const offset = (page - 1) * limit;

    const sortFieldRaw = toStr(url.searchParams.get("sortField")) || "department_id";
    const sortField = SORT_WHITELIST.has(sortFieldRaw) ? sortFieldRaw : "department_id";

    const sortOrderRaw = toStr(url.searchParams.get("sortOrder")).toUpperCase();
    const sortOrder = sortOrderRaw === "ASC" ? "ASC" : "DESC";

    const where = {
      deleted: null, // default: hide deleted
    };

    if (q) {
      where[Op.or] = [
        { title: { [Op.like]: `%${q}%` } },
        { description: { [Op.like]: `%${q}%` } },
      ];
    }

    const { rows, count } = await Department.findAndCountAll({
      where,
      limit,
      offset,
      order: [[sortField, sortOrder]],
    });

    return NextResponse.json(
      {
        data: rows,
        pagination: {
          page,
          limit,
          total: count,
          totalPages: Math.max(1, Math.ceil(count / limit)),
          sortField,
          sortOrder,
          q,
        },
      },
      { status: 200 }
    );
  } catch (error) {
    console.error("Error fetching department list:", error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
});
