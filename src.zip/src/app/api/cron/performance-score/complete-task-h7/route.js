// src/app/api/cron/performance-score/complete-task-h7/route.js
import 'server-only';
import db from '@/database/models';
import dayjs from 'dayjs';
import tz from 'dayjs/plugin/timezone';
import { withCronLock } from '@/utils/cronLock';
dayjs.extend(tz);

export const dynamic = 'force-dynamic';
export const revalidate = 0;

const TZ = process.env.NEXT_PUBLIC_APP_TIMEZONE || 'Asia/Jakarta';
const PERF_CONFIG_ID = 8;   // Complete Task H-7
const SCORE_VALUE = 3;

export async function GET(req) {
    const t0 = Date.now();
    const { Op } = db.Sequelize;

    try {
        const { searchParams } = new URL(req.url);
        const dateParam = searchParams.get('date');
        const dryRun = String(searchParams.get('dryRun') || '').toLowerCase() === 'true';

        const eventDate = (dateParam && /^\d{4}-\d{2}-\d{2}$/.test(dateParam))
            ? dateParam
            : dayjs().tz(TZ).format('YYYY-MM-DD');

        // Selesai H-7: completed = eventDate, deadline = eventDate + 7
        const targetDeadline = dayjs(eventDate).add(7, 'day').format('YYYY-MM-DD');
        const startUnix = dayjs.tz(`${eventDate} 00:00:00`, TZ).unix();
        const endUnix = dayjs.tz(`${eventDate} 23:59:59`, TZ).unix();

        const periodYear = Number(dayjs(eventDate).year());
        const periodMonth = Number(dayjs(eventDate).month() + 1);
        const periodStart = dayjs(eventDate).startOf('month').format('YYYY-MM-DD');

        const res = await withCronLock(`perf-complete-h7-${eventDate}`, async () => {
            const tasks = await db.Task.findAll({
                where: { end_date: targetDeadline, todo: 'complete', updated: { [Op.between]: [startUnix, endUnix] } },
                attributes: ['task_id', 'title', 'end_date', 'todo', 'updated'],
                raw: true,
            });
            if (!tasks.length) return { inserted: 0, scanned: 0, skipped: 0 };

            const taskIds = tasks.map(t => t.task_id);
            const assigns = await db.TaskAssignment.findAll({
                where: { task_id: { [Op.in]: taskIds } },
                attributes: ['task_id', 'user_id'],
                raw: true,
            });
            if (!assigns.length) return { inserted: 0, scanned: tasks.length, skipped: 0, note: 'no assignees' };

            const usersByTask = new Map();
            for (const a of assigns) {
                if (!usersByTask.has(a.task_id)) usersByTask.set(a.task_id, []);
                usersByTask.get(a.task_id).push(a.user_id);
            }

            const pairs = [];
            for (const t of tasks) for (const u of (usersByTask.get(t.task_id) || [])) pairs.push({ user_id: u, ref_id: t.task_id });

            const refIds = [...new Set(pairs.map(p => p.ref_id))];
            const existing = await db.PerformanceEventLog.findAll({
                where: { perf_config_id: PERF_CONFIG_ID, event_date: eventDate, ref_id: { [Op.in]: refIds } },
                attributes: ['ref_id', 'user_id'],
                raw: true,
            });
            const existed = new Set(existing.map(e => `${e.user_id}:${e.ref_id}`));

            const titleById = new Map(tasks.map(t => [t.task_id, t.title]));
            const nowUnix = Math.floor(Date.now() / 1000);
            const rows = [];
            let skipped = 0;

            for (const { user_id, ref_id } of pairs) {
                const key = `${user_id}:${ref_id}`;
                if (existed.has(key)) { skipped++; continue; }
                rows.push({
                    user_id,
                    event_date: eventDate,
                    period_year: periodYear,
                    period_month: periodMonth,
                    period_start_date: periodStart,
                    perf_config_id: PERF_CONFIG_ID,
                    score_value: SCORE_VALUE,
                    source: 'task',
                    ref_id,
                    note: `Complete Task H-7: [#${ref_id}] ${titleById.get(ref_id) || '(no title)'} — deadline ${targetDeadline}`,
                    meta: JSON.stringify({
                        task_id: ref_id,
                        title: titleById.get(ref_id) || null,
                        deadline: targetDeadline,
                        status: 'completed_early',
                        days_early: 7,
                        bucket: 'early',
                    }),
                    created: nowUnix,
                    updated: nowUnix,
                });
            }

            if (dryRun) {
                return { inserted: 0, scanned: tasks.length, skipped, willInsert: rows.length, sample: rows.slice(0, 5), dryRun: true };
            }

            let inserted = 0;
            if (rows.length) {
                const result = await db.PerformanceEventLog.bulkCreate(rows, { ignoreDuplicates: true });
                inserted = Array.isArray(result) ? result.length : 0;
            }
            return { inserted, scanned: tasks.length, skipped };
        }, { ttlSec: 60 });

        if (res?.locked) {
            return new Response(JSON.stringify({ ok: false, rule: 'complete-h7', date: eventDate, busy: true }), { status: 423 });
        }

        return Response.json({ ok: true, rule: 'complete-h7', date: eventDate, targetDeadline, ...res, ms: Date.now() - t0 });
    } catch (err) {
        console.error('[cron][complete-h7] error:', err);
        return new Response(JSON.stringify({ ok: false, error: String(err?.message || err) }), { status: 500 });
    }
}
