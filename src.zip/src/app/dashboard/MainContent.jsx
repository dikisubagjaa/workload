// src/app/dashboard/MainContent.jsx
"use client";
import "swiper/css";
import "swiper/css/navigation";
import { useRef, useState, useEffect, useCallback, useMemo, useEffectEvent } from "react";
import { useSearchParams } from "next/navigation";
import {
  useMobileQuery,
  useLaptopQuery,
  useDekstopQuery,
  useLargeDekstopQuery,
} from "@/components/libs/UseMediaQuery";
import { HomeOutlined } from "@ant-design/icons";
import { message, Spin, Select } from "antd";
import { useSession } from "next-auth/react";
import DateTime from "@components/utils/DateTime";
import axiosInstance from "@/utils/axios";

// +++ Attendance Button (dipindah ke Dashboard)
import ClockButton from "@/components/attendance/ClockButton";

// Modal create-only (tetap dipakai untuk flow "Add …")
import ModalProject from "@/components/modal/ModalProject";
import ModalTask from "@/components/modal/ModalTask";
import ModalPitching from "@/components/modal/ModalPitching";

// Modal lain yang memang bukan URL-driven
import ModalInfoAttendance from "@/components/modal/ModalInfoAttendance";
import DrawerTracker from "@/components/utils/DrawerTracker";

// Sections
import DashboardOverview from "@/components/dashboard/OverviewSection";
import DashboardTaskStats from "@/components/common/StatsBar";
import DashboardPerformanceWeeklyAttendance from "@/components/dashboard/PerformanceWeeklyAttendance";
import DashboardOngoingProjects from "@/components/dashboard/OngoingProject";
import DashboardTaskListSection from "@/components/dashboard/TaskListSection";
import DashboardTaskListHodSection from "@/components/dashboard/TaskListHodSection";
import DashboardClientReviewSection from "@/components/dashboard/ClientReviewSection";
import DashboardTeamPerformanceSection from "@/components/dashboard/TeamPerformanceSection";

export default function MainContent() {
  const [modalProject, setModalProject] = useState(false);
  const [modalTask, setModalTask] = useState(false);
  const [modalPitching, setModalPitching] = useState(false);
  const [modalInfoAttendance, setModalInfoAttendance] = useState(false);
  const [drawerTracker, setDrawerTracker] = useState(false);
  const { data: session } = useSession();

  const [dataTask, setDataTask] = useState([]);
  const [dataTaskHod, setDataTaskHod] = useState([]);
  const [dataTaskReview, setDataTaskReview] = useState([]);
  const [projectOnGoing, setProjectOnGoing] = useState([]);
  const [overviewData, setOverviewData] = useState([
    { title: "Due Today", value: 0, cardBorder: "!border-l-4 border-[#00939F]" },
    { title: "Overdue Task", value: 0, cardBorder: "!border-l-4 border-[#EC221F]" },
    { title: "Critical Deadlines", value: 0, cardBorder: "!border-l-4 border-[#E8B931]" },
    { title: "Due This Week", value: 0, cardBorder: "!border-l-4 border-[#00939F]" },
    { title: "New task assigned", value: 0, cardBorder: "!border-l-4 border-[#E8B931]" },
    { title: "Total Task", value: 0, cardBorder: "!border-l-4 border-[#00939F]" },
    { title: "Need Review", value: 0, cardBorder: "!border-l-4 border-[#00939F]" },
  ]);

  const [attendanceList, setAttendanceList] = useState([]);
  const [stepCount, setStepsCount] = useState("6");
  const [loadingDash, setLoadingDash] = useState(false); 
  const [updatingTask, setUpdatingTask] = useState(false); 
  const [isHidden, setIsHidden] = useState(false);

  const swiperRef = useRef();
  const isMobile = useMobileQuery();
  const isLaptop = useLaptopQuery();
  const isDekstop = useLargeDekstopQuery();

  const date = new Date().toLocaleDateString("id-ID", {
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric",
  });

  // Warna progress donut (sesuai file asli)
  const conicColors = useMemo(
    () => ({ "0%": "#9747FF", "50%": "#00939F", "100%": "#00939F" }),
    []
  );

  // ====== ROLE FLAGS ======
  const isHod =  session?.user?.is_hod === "true";
  const isHrd =  session?.user?.is_hrd === "true";
  const isAccount = session?.user?.is_ae === "true";
  const isSuperadmin =  session?.user?.is_superadmin === "true";

  // ====== STAFF FILTER (SUPERADMIN ONLY) ======
  const [selectedStaffId, setSelectedStaffId] = useState(null);
  const [staffOptions, setStaffOptions] = useState([]);
  const [staffLoading, setStaffLoading] = useState(false);
  const staffSearchTimerRef = useRef(null);

  useEffect(() => {
    if (isSuperadmin && !selectedStaffId) {
      setIsHidden(true);
    } else {
      setIsHidden(false);
    }
  }, [isSuperadmin, selectedStaffId]);
  
  const effectiveStaffId = useMemo(() => {
    if (!isSuperadmin) return null;
    return selectedStaffId || null;
  }, [isSuperadmin, selectedStaffId]);

  const fetchStaffOptions = useCallback(
    async (q = "") => {
      if (!isSuperadmin) return;
      setStaffLoading(true);
      try {
        const res = await axiosInstance.get(`/user`, {
          params: {
            q: q || undefined,
            limit: 20,
          },
        });

        // fleksibel: tergantung bentuk payload API kamu
        const arr =
          (Array.isArray(res.data?.data) && res.data.data) ||
          (Array.isArray(res.data?.users) && res.data.users) ||
          (Array.isArray(res.data?.rows) && res.data.rows) ||
          (Array.isArray(res.data) && res.data) ||
          [];

        const opts = arr
          .map((u) => {
            const id = u?.user_id ?? u?.id ?? null;
            if (!id) return null;

            const name = u?.fullname ?? u?.full_name ?? u?.name ?? u?.email ?? `User ${id}`;
            const role = u?.user_role ?? u?.role ?? "";
            const label = role ? `${name} (${role})` : name;

            return { value: String(id), label };
          })
          .filter(Boolean);

        setStaffOptions(opts);
      } catch (err) {
        console.error("Error fetching /user:", err?.response?.data || err?.message || err);
      } finally {
        setStaffLoading(false);
      }
    },
    [isSuperadmin]
  );

  // preload list untuk superadmin (biar dropdown gak kosong)
  useEffect(() => {
    if (!isSuperadmin) return;
    fetchStaffOptions("");
  }, [isSuperadmin, fetchStaffOptions]);

  const handleSearchStaff = useCallback(
    (val) => {
      if (!isSuperadmin) return;

      if (staffSearchTimerRef.current) clearTimeout(staffSearchTimerRef.current);
      staffSearchTimerRef.current = setTimeout(() => {
        fetchStaffOptions(val || "");
      }, 300);
    },
    [isSuperadmin, fetchStaffOptions]
  );

  const handleChangeStaff = useCallback((val) => {
    // val bisa undefined kalau clear
    setIsHidden(false);
    setSelectedStaffId(val ? String(val) : null);
  }, []);

  // ====== REFETCH DASHBOARD (bisa dipakai ulang) ======
  const fetchDashboard = useCallback(async () => {
    setLoadingDash(true);
    try {
      const res = await axiosInstance.get(`/dashboard`, {
        params: {
          staffId: effectiveStaffId || undefined,
        },
      });

      if (res.status === 200 || res.status === 201) {
        const taskArr = Array.isArray(res.data?.task) ? res.data.task : [];
        setDataTask(
          taskArr.map((item, index) => ({
            key: index,
            task_id: item?.task_id,
            todo: item?.todo,
            last_version: item?.last_version,
            parent_id: item?.parent_id,
            title: item.title ?? "-",
            version: "",
            projectClient: item?.Project?.title ?? "-",
            progress: typeof item.progress === "number" ? item.progress : 0,
            start_date: item.start_date ?? "",
            end_date: item.end_date ?? "",
            btnCheck: false,
          }))
        );

        const taskArrHod = Array.isArray(res.data?.taskHod) ? res.data.taskHod : [];
        setDataTaskHod(
          taskArrHod.map((item, index) => ({
            key: index,
            task_id: item?.task_id,
            todo: item?.todo,
            last_version: item?.last_version,
            parent_id: item?.parent_id,
            title: item?.title ?? "-",
            version: "",
            projectClient: item?.Project?.title ?? "-",
            assignedName:
              (item?.AssignedUser || []).map((u) => u.fullname).join(", ") || "-",
            progress: typeof item.progress === "number" ? item.progress : 0,
            start_date: item.start_date ?? "",
            end_date: item.end_date ?? "",
            btnCheck: false,
          }))
        );

        const reviewArr = Array.isArray(res.data?.taskDataReview) ? res.data.taskDataReview : [];
        setDataTaskReview(
          reviewArr.map((item, index) => ({
            key: index,
            task_id: item?.task_id,
            todo: item?.todo,
            status: item?.todo,
            last_version: item?.last_version,
            parent_id: item?.parent_id,
            title: item.title ?? "-",
            version: "",
            projectClient: item?.Project?.title ?? "-",
            progress: typeof item.progress === "number" ? item.progress : 0,
            start_date: item.start_date ?? "",
            end_date: item.end_date ?? "",
            btnCheck: false,
          }))
        );

        const projArr = Array.isArray(res.data?.project) ? res.data.project : [];
        setProjectOnGoing(
          projArr.map((item, index) => ({
            key: index,
            name: item.title ?? "-",
            type: item.type ?? "",
            priority: "#E8B931",
            progress: typeof item.progress === "number" ? item.progress : 0,
            members: Array.isArray(item.team) ? item.team : [],
            dueDate: item.dueDate ?? "—",
            brand: item.brand?.title ?? item.brand ?? "",
            projectType: Array.isArray(item.projectType) ? item.projectType : [],
          }))
        );
      }
    } catch (err) {
      console.error("Error fetching /dashboard:", err?.response?.data || err?.message || err);
      message.error("Gagal memuat dashboard");
    } finally {
      setLoadingDash(false);
    }
  }, [effectiveStaffId]);

  // ====== KEEP: handleStatusUpdate tetap ada ======
  const handleStatusUpdate = useCallback(
    async (record, newStatus) => {
      if (!record?.task_id) return;
      const key = "updateTaskStatus";
      setUpdatingTask(true);
      try {
        message.loading({ key, content: "Updating…", duration: 0 });
        await axiosInstance.put(`/task/${record.task_id}`, { type: "todo", value: newStatus });

        // Refetch supaya semua widget sinkron (overview, list, HOD, review, project)
        await fetchDashboard();

        message.success({ key, content: `Status "${record.name || record.title}" diperbarui` });
      } catch (err) {
        console.error(err);
        message.error({ key, content: "Gagal update status" });
      } finally {
        setUpdatingTask(false);
      }
    },
    [fetchDashboard]
  );

  // ====== REFETCH WEEKLY ATTENDANCE (dipakai ulang + untuk onSuccess clock) ======
  const fetchWeeklyAttendance = useCallback(async () => {
    try {
      const res = await axiosInstance.get(`/attendance/weekly`, {
        params: {
          staffId: effectiveStaffId || undefined,
        },
      });
      if (res.status === 200) {
        setAttendanceList(Array.isArray(res.data?.weekly) ? res.data.weekly : []);
      }
    } catch (err) {
      console.error(
        "Error fetching /attendance/weekly:",
        err?.response?.data || err?.message || err
      );
    }
  }, [effectiveStaffId]);

  // ====== FETCH (mount / selection changes) ======
  useEffect(() => {
    fetchDashboard();
    fetchWeeklyAttendance();
  }, [fetchDashboard, fetchWeeklyAttendance]);

  // ====== Akses: DINAMIS dari session.user.menu.dashboardKeys (tanpa hardcode angka) ======
  const normalizeAlias = useCallback((raw) => {
    const s = String(raw ?? "").trim();
    if (!s) return "";
    const last = s.startsWith("/") ? s.split("/").filter(Boolean).pop() || "" : s;
    return last.replace(/-/g, "_").toLowerCase(); // contoh: /team-performance → team_performance
  }, []);

  const allowed = useMemo(() => {
    const keys = Array.isArray(session?.user?.menu?.dashboardKeys)
      ? session.user.menu.dashboardKeys
      : [];
    return new Set(keys.map(normalizeAlias).filter(Boolean));
  }, [session, normalizeAlias]);

  // flags per widget (berdasar alias PATH yang kamu set di DB)
  const canOverview = allowed.has("overview");
  const canWeeklyAttendance = allowed.has("weekly_attendance");
  const canOngoingProject = allowed.has("ongoing_project");
  const canTaskList = allowed.has("task_list");
  const canClientReview = allowed.has("client_review");
  const canTeamPerformance = allowed.has("team_performance");

  const StaffSelect = (
    <Select
      showSearch
      allowClear
      placeholder="Select Staff"
      loading={staffLoading}
      options={staffOptions}
      value={selectedStaffId ? String(selectedStaffId) : undefined}
      onChange={handleChangeStaff}
      onSearch={handleSearchStaff}
      filterOption={false}
      className="min-w-64 w-full select-staff"
    />
  );

  return (
    <>
      {/* Overlay spinner ketika fetch dashboard atau updating task */}
      <Spin spinning={loadingDash || updatingTask} size="large">
        <div className="container pt-5 mb-5 sm:pt-10">
          {/* Header: responsif (mobile stack, desktop sejajar) */}
          <div className="flex justify-center border-b pb-3 sm:hidden mb-3">
            <DateTime />
          </div>

          {/* Mobile: Staff Filter */}
          {isSuperadmin && (
            <div className="sm:hidden mb-3">
              {StaffSelect}
            </div>
          )}

          <div className="flex items-center justify-between gap-3 mb-2">
            <h1 className="text-lg sm:text-2xl nunito-reg text-[#383F50]">
              <HomeOutlined /> Dashboard
            </h1>

            {/* Desktop: DateTime + Staff Filter */}
            <div className="hidden sm:flex flex-col items-end gap-3">
              <DateTime />
              {isSuperadmin && (
                <div className="mb-2">{StaffSelect}</div>
              )}
            </div>

            {/* Mobile: clock button tetap */}
            <div className="sm:hidden">
              <ClockButton fetchWeeklyAttendance={fetchWeeklyAttendance} />
            </div>
          </div>

          {!isSuperadmin && (
              <DashboardOverview
                isMobile={isMobile}
                isLaptop={isLaptop}
                isDekstop={isDekstop}
                onAddPitch={() => setModalPitching(true)}
                onAddProject={() => setModalProject(true)}
                onAddTask={() => setModalTask(true)}
                session={session}
              />
          )}
         
          {!isHidden && (
            <>
              

              {canOverview  &&  (
                <DashboardTaskStats
                  isMobile={isMobile}
                  isLaptop={isLaptop}
                  isDekstop={isDekstop}
                  staffId={effectiveStaffId} // <-- next step: kita bikin StatsBar pakai ini
                />
              )}
              
              {canWeeklyAttendance && (
              <DashboardPerformanceWeeklyAttendance
                conicColors={conicColors}
                stepCount={stepCount}
                setStepsCount={setStepsCount}
                onInfoAttendance={() => setModalInfoAttendance(true)}
                listAttendanceTimesheet={attendanceList}
                staffId={effectiveStaffId} // <-- next step: kita bikin widget ini pakai staffId
              />
            )}
              {isAccount && canOngoingProject && (
              <DashboardOngoingProjects projectOnGoing={projectOnGoing} />
            )}

            {canTaskList && (
              <>
                <DashboardTaskListSection dataTask={dataTask} onChangeStatus={handleStatusUpdate} />
                {/* HOD list: sesuai prop yang kamu pakai di versi ini */}
                <DashboardTaskListHodSection dataTask={dataTaskHod} onChangeStatus={handleStatusUpdate} />
              </>
            )}

            {canClientReview && (
              <DashboardClientReviewSection
                dataTaskReview={dataTaskReview}
                fetchDashboard={fetchDashboard}
              />
            )}

          {canTeamPerformance && (isHod || (isSuperadmin && selectedStaffId)) && (
            <DashboardTeamPerformanceSection
              isMobile={isMobile}
              isLaptop={isLaptop}
              date={date}
              staffId={isSuperadmin ? selectedStaffId : undefined}
            />
          )}

            {canTeamPerformance && (isHod || (isSuperadmin && selectedStaffId)) && (
                <DashboardTeamPerformanceSection
                  isMobile={isMobile}
                  isLaptop={isLaptop}
                  date={date}
                  staffId={isSuperadmin ? selectedStaffId : undefined}
                />
              )}
            </>
          )}
        </div>
      </Spin>

      {/* Modals & Drawer */}
      <ModalProject modalProject={modalProject} onCancel={() => setModalProject(false)} />
      <ModalTask modalTask={modalTask} onCancel={() => setModalTask(false)} />
      <ModalPitching modalPitching={modalPitching} onCancel={() => setModalPitching(false)} />
      <ModalInfoAttendance
        modalInfoAttendance={modalInfoAttendance}
        onCancel={() => setModalInfoAttendance(false)}
      />

      <DrawerTracker open={drawerTracker} onClose={() => setDrawerTracker(false)} />
    </>
  );
}
