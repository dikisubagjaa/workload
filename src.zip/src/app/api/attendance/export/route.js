// src/app/api/attendance/export/route.js
export const dynamic = "force-dynamic";
export const revalidate = 0;

import db from "@/database/models";
import dayjs from "dayjs";
import utc from "dayjs/plugin/utc";
import timezone from "dayjs/plugin/timezone";
import isSameOrBefore from "dayjs/plugin/isSameOrBefore";
import { withActive } from "@/utils/session";

// ---------- Dayjs setup ----------
dayjs.extend(utc);
dayjs.extend(timezone);
dayjs.extend(isSameOrBefore);

const APP_TZ = process.env.NEXT_PUBLIC_APP_TIMEZONE || "Asia/Jakarta";
dayjs.tz.setDefault(APP_TZ);

const {
  User,
  Department,
  Attendance,
  Holiday,
  LeaveRequest,
  LeaveConfig,
  Sequelize,
} = db || {};

const { Op } = Sequelize || {};

// ---------- Helpers tanggal ----------
function toYMD(input) {
  if (!input) return null;
  const s = String(input).trim();
  if (!s) return null;

  const d = dayjs(s, "YYYY-MM-DD", true);
  return d.isValid() ? d.format("YYYY-MM-DD") : null;
}

/**
 * Normalisasi periode berdasarkan query param:
 * - period = "period" + from/to → pakai range itu
 * - selain itu → pakai hari ini
 */
function normalizeRange(searchParams) {
  const period = (searchParams.get("period") || "").toLowerCase();
  const fromParam = searchParams.get("from");
  const toParam = searchParams.get("to");

  if (period === "period" && fromParam && toParam) {
    const from = toYMD(fromParam);
    const to = toYMD(toParam);

    if (from && to) {
      const fromD = dayjs(from);
      const toD = dayjs(to);

      if (fromD.isValid() && toD.isValid() && !toD.isBefore(fromD)) {
        return { from, to };
      }
    }
  }

  const today = dayjs().tz(APP_TZ);
  const ymd = today.format("YYYY-MM-DD");
  return { from: ymd, to: ymd };
}

/**
 * Bangun list hari kerja (bukan weekend & bukan holiday)
 * di antara from..to (YYYY-MM-DD).
 *
 * NOTE:
 * holidayDatesSet di sini harus mencakup semua tanggal non-working (holiday + cuti bersama),
 * supaya hari itu tidak dihitung sebagai hari kerja.
 */
function buildWorkingDays(from, to, holidayDatesSet) {
  const out = [];
  let d = dayjs.tz(from, APP_TZ);
  const end = dayjs.tz(to, APP_TZ);

  while (d.isSameOrBefore(end, "day")) {
    const dow = d.day(); // 0=Sun..6=Sat
    const ymd = d.format("YYYY-MM-DD");
    const isWeekend = dow === 0 || dow === 6;
    const isHoliday = holidayDatesSet.has(ymd);

    if (!isWeekend && !isHoliday) {
      out.push(ymd);
    }

    d = d.add(1, "day");
  }

  return out;
}

/**
 * Mapping permit/reason -> key kolom cuti
 */
function mapReasonToKey(reasonRaw) {
  if (!reasonRaw) return null;
  const r = reasonRaw.toLowerCase().trim();

  if (r.startsWith("cuti tahunan")) return "cutiTahunan";
  if (r.startsWith("menikahkan")) return "menikahkan";
  if (r.startsWith("menikah")) return "menikah";
  if (r.startsWith("melahirkan (suami")) return "melahirkanSuami";
  if (r.startsWith("melahirkan")) return "melahirkan";
  if (r.startsWith("mengkhitankan")) return "mengkhitankan";
  if (r.startsWith("baptis")) return "baptis";
  if (r.startsWith("unpaid")) return "unpaidLeave";
  if (r.startsWith("sakit")) return "sakit";
  if (r.startsWith("berduka")) return "berduka";
  if (r.startsWith("menstruasi")) return "menstruasi";
  if (r.startsWith("umrah")) return "umrah";

  return null;
}

// Header mengikuti contoh CSV yang kamu kirim
const HEADER_ROW = [
  "DIVISI",                        // 0  (dipakai juga sebagai No di data staff)
  "NAMA LENGKAP",                  // 1
  "JABATAN",                       // 2
  "TELP",                          // 3
  "EMAIL",                         // 4
  "TOTAL KERJA",                   // 5
  "NO-TIMESHEET",                  // 6
  "TANPA KETERANGN",               // 7
  "TERLAMBAT",                     // 8
  "Cuti Tahunan",                  // 9
  "Menikah",                       // 10
  "Menikahkan",                    // 11
  "Melahirkan",                    // 12
  "Mengkhitankan",                 // 13
  "Baptis",                        // 14
  "Unpaid Leave",                  // 15
  "Sakit",                         // 16
  "Berduka Cita (Keluarga Utama)", // 17
  "Menstruasi",                    // 18
  "Melahirkan (Suami)",            // 19
  "Umrah",                         // 20
  "SISA CUTI",                     // 21
  "TANGGAL CUTI",                  // 22
];

// ---------- Main handler ----------
export const GET = withActive(
  async function ATTENDANCE_EXPORT_HANDLER(req, _ctx, currentUser) {
    try {
      if (
        !db ||
        !User ||
        !Attendance ||
        !Holiday ||
        !LeaveRequest ||
        !LeaveConfig
      ) {
        throw new Error("Database models not available");
      }

      // dynamic import SheetJS (xlsx) supaya aman di Next.js
      const xlsxModule = await import("xlsx");
      const XLSX = xlsxModule.default || xlsxModule;

      const { searchParams } = new URL(req.url);
      const { from, to } = normalizeRange(searchParams);

      const fromLabel = dayjs.tz(from, APP_TZ).format("DD/MM/YYYY");
      const toLabel = dayjs.tz(to, APP_TZ).format("DD/MM/YYYY");

      const baseYear = dayjs.tz(from, APP_TZ).year();
      const yearStart = `${baseYear}-01-01`;
      const yearEnd = `${baseYear}-12-31`;

      // ---------- Master: User & Department ----------
      const [users, departments] = await Promise.all([
        User.findAll({
          attributes: [
            "user_id",
            "fullname",
            "job_position",
            "phone",
            "email",
            "department_id",
          ],
          raw: true,
        }),
        Department.findAll({
          attributes: ["department_id", "title"],
          raw: true,
        }),
      ]);

      const deptMap = new Map();
      for (const d of departments) {
        deptMap.set(d.department_id, d.title);
      }

      // ---------- Holiday periode (untuk working days) ----------
      // IMPORTANT: di periode ini, baik type=holiday maupun type=leave sama-sama libur (non-working day)
      const holidayRows = await Holiday.findAll({
        where: {
          date: {
            [Op.between]: [from, to],
          },
        },
        attributes: ["date"],
        raw: true,
      });

      const holidaySetPeriod = new Set(holidayRows.map((h) => h.date));
      const workingDays = buildWorkingDays(from, to, holidaySetPeriod);
      const workingDaySet = new Set(workingDays);

      // ---------- Holiday setahun (untuk cuti tahunan) ----------
      // - type="holiday" => tanggal merah => TIDAK motong cuti tahunan (dianggap holiday untuk cuti tahunan)
      // - type="leave"   => cuti bersama  => MOTONG cuti tahunan (JANGAN dianggap holiday untuk cuti tahunan)
      const holidayYearRows = await Holiday.findAll({
        where: {
          date: {
            [Op.between]: [yearStart, yearEnd],
          },
        },
        attributes: ["date", "type"],
        raw: true,
      });

      const publicHolidaySetYear = new Set(); // type=holiday
      const jointLeaveSetYear = new Set();    // type=leave (cuti bersama)

      for (const h of holidayYearRows) {
        const t = String(h.type || "holiday").toLowerCase();
        if (t === "leave") jointLeaveSetYear.add(h.date);
        else publicHolidaySetYear.add(h.date);
      }

      // joint leave yang jatuh di weekday saja (yang masuk hitungan potong cuti tahunan)
      const jointLeaveAnnualArr = [];
      for (const ymd of jointLeaveSetYear) {
        const d = dayjs.tz(ymd, APP_TZ);
        const dow = d.day();
        const isWeekend = dow === 0 || dow === 6;
        if (!isWeekend) jointLeaveAnnualArr.push(ymd);
      }
      jointLeaveAnnualArr.sort();

      // ---------- Attendance di periode ----------
      const attendanceRows = await Attendance.findAll({
        where: {
          date: { [Op.between]: [from, to] },
        },
        attributes: ["user_id", "date", "status", "timesheet", "minutes_late"],
        raw: true,
      });

      const attendanceMap = new Map(); // key: `${userId}#${date}`
      for (const row of attendanceRows) {
        const key = `${row.user_id}#${row.date}`;
        attendanceMap.set(key, row);
      }

      // ---------- Leave approved setahun ----------
      const allApprovedLeaves = await LeaveRequest.findAll({
        where: {
          status: "approved",
          start_date: { [Op.lte]: yearEnd },
          end_date: { [Op.gte]: yearStart },
        },
        attributes: [
          "leave_id",
          "user_id",
          "start_date",
          "end_date",
          "days",
          "permit",
          "reason",
        ],
        raw: true,
      });

      // Harian leave pada periode export (untuk kolom cuti)
      const leaveDailyMap = new Map(); // key: `${userId}#YYYY-MM-DD` -> reasonKey

      // Tanggal cuti tahunan setahun (untuk SISA CUTI & TANGGAL CUTI)
      // NOTE:
      // - Kita hitung dari LeaveRequest "Cuti Tahunan" (hari kerja, exclude weekend & tanggal merah)
      // - Lalu kita tambahkan cuti bersama (Holiday.type="leave") sebagai pengurang otomatis untuk semua user
      const annualCutiDatesByUser = new Map(); // userId -> Set(YYYY-MM-DD)

      const yearStartDayjs = dayjs.tz(yearStart, APP_TZ);
      const yearEndDayjs = dayjs.tz(yearEnd, APP_TZ);

      for (const lv of allApprovedLeaves) {
        const userId = lv.user_id;
        const reasonKey = mapReasonToKey(lv.reason || lv.permit || "");
        if (!reasonKey) continue;

        const leaveStart = dayjs.tz(lv.start_date, APP_TZ);
        const leaveEnd = dayjs.tz(lv.end_date, APP_TZ);

        // --- 1) Hari kerja di dalam periode (untuk kolom cuti per jenis) ---
        const effStart = leaveStart.isAfter(from)
          ? leaveStart
          : dayjs.tz(from, APP_TZ);

        const effEnd = leaveEnd.isBefore(to)
          ? leaveEnd
          : dayjs.tz(to, APP_TZ);

        let d = effStart;
        while (d.isSameOrBefore(effEnd, "day")) {
          const ymd = d.format("YYYY-MM-DD");

          if (workingDaySet.has(ymd)) {
            const key = `${userId}#${ymd}`;
            if (!leaveDailyMap.has(key)) {
              leaveDailyMap.set(key, reasonKey);
            }
          }

          d = d.add(1, "day");
        }

        // --- 2) Khusus Cuti Tahunan: semua hari kerja dalam 1 tahun (SISA CUTI & TANGGAL CUTI) ---
        if (reasonKey === "cutiTahunan") {
          const effYearStart = leaveStart.isAfter(yearStartDayjs)
            ? leaveStart
            : yearStartDayjs;

          const effYearEnd = leaveEnd.isBefore(yearEndDayjs)
            ? leaveEnd
            : yearEndDayjs;

          let d2 = effYearStart;
          while (d2.isSameOrBefore(effYearEnd, "day")) {
            const ymd2 = d2.format("YYYY-MM-DD");
            const dow = d2.day();
            const isWeekend = dow === 0 || dow === 6;

            // IMPORTANT:
            // exclude hanya tanggal merah (Holiday.type="holiday")
            // cuti bersama (Holiday.type="leave") tidak di-exclude karena harus motong cuti tahunan
            const isPublicHoliday = publicHolidaySetYear.has(ymd2);

            if (!isWeekend && !isPublicHoliday) {
              let set = annualCutiDatesByUser.get(userId);
              if (!set) {
                set = new Set();
                annualCutiDatesByUser.set(userId, set);
              }
              set.add(ymd2);
            }

            d2 = d2.add(1, "day");
          }
        }
      }

      // ---------- Quota cuti tahunan ----------
      let annualQuota = 12;

      if (LeaveConfig) {
        const cutiCfg = await LeaveConfig.findOne({
          where: {
            title: { [Op.like]: "Cuti Tahunan%" },
          },
          raw: true,
        });

        if (cutiCfg && cutiCfg.total != null) {
          annualQuota = Number(cutiCfg.total) || annualQuota;
        }
      }

      // ---------- Hitung per user ----------
      const userSummaries = [];

      for (const u of users) {
        const userId = u.user_id;

        const counters = {
          totalKerja: 0,
          noTimesheet: 0,
          tanpaKeterangan: 0,
          terlambat: 0,
          cutiTahunan: 0,
          menikah: 0,
          menikahkan: 0,
          melahirkan: 0,
          mengkhitankan: 0,
          baptis: 0,
          unpaidLeave: 0,
          sakit: 0,
          berduka: 0,
          menstruasi: 0,
          melahirkanSuami: 0,
          umrah: 0,
        };

        for (const ymd of workingDays) {
          const key = `${userId}#${ymd}`;

          // 1) cek leave dulu
          const leaveKey = leaveDailyMap.get(key);
          if (leaveKey) {
            if (leaveKey === "cutiTahunan") counters.cutiTahunan += 1;
            else if (leaveKey === "menikah") counters.menikah += 1;
            else if (leaveKey === "menikahkan") counters.menikahkan += 1;
            else if (leaveKey === "melahirkan") counters.melahirkan += 1;
            else if (leaveKey === "mengkhitankan") counters.mengkhitankan += 1;
            else if (leaveKey === "baptis") counters.baptis += 1;
            else if (leaveKey === "unpaidLeave") counters.unpaidLeave += 1;
            else if (leaveKey === "sakit") counters.sakit += 1;
            else if (leaveKey === "berduka") counters.berduka += 1;
            else if (leaveKey === "menstruasi") counters.menstruasi += 1;
            else if (leaveKey === "melahirkanSuami") counters.melahirkanSuami += 1;
            else if (leaveKey === "umrah") counters.umrah += 1;

            continue;
          }

          // 2) kalau tidak ada leave, cek attendance
          const att = attendanceMap.get(key);
          if (!att) {
            counters.tanpaKeterangan += 1;
            continue;
          }

          const status = att.status;
          const hasTimesheet = att.timesheet === "true";
          const minutesLate =
            typeof att.minutes_late === "number" ? att.minutes_late : 0;

          if (status === "sick") {
            counters.sakit += 1;
          } else if (status === "leave") {
            // fallback: leave tanpa detail -> Unpaid
            counters.unpaidLeave += 1;
          } else if (status === "holiday") {
            // libur, skip
          } else if (status === "absent") {
            counters.tanpaKeterangan += 1;
          } else if (
            status === "present" ||
            status === "late" ||
            status === "permission"
          ) {
            if (hasTimesheet) counters.totalKerja += 1;
            else counters.noTimesheet += 1;
          }

          if (status === "late" || minutesLate > 0) {
            counters.terlambat += 1;
          }
        }

        // ---------- SISA CUTI & TANGGAL CUTI ----------
        // 1) ambil tanggal cuti tahunan dari leave request
        let cutiDatesSet = annualCutiDatesByUser.get(userId);

        // 2) tambahkan cuti bersama (Holiday.type="leave") sebagai pengurang otomatis untuk semua user
        if (jointLeaveAnnualArr.length > 0) {
          if (!cutiDatesSet) {
            cutiDatesSet = new Set();
            annualCutiDatesByUser.set(userId, cutiDatesSet);
          }
          for (const ymdJL of jointLeaveAnnualArr) {
            cutiDatesSet.add(ymdJL);
          }
        }

        let tanggalCutiStr = "";
        let usedAnnual = 0;

        if (cutiDatesSet && cutiDatesSet.size > 0) {
          const arr = Array.from(cutiDatesSet);
          arr.sort();
          tanggalCutiStr = arr.join("|");
          usedAnnual = arr.length;
        }

        const sisaCuti = annualQuota != null ? annualQuota - usedAnnual : "";

        userSummaries.push({
          userId,
          deptId: u.department_id,
          fullname: u.fullname || "",
          job_position: u.job_position || "",
          phone: u.phone || "",
          email: u.email || "",
          counters,
          sisaCuti,
          tanggalCutiStr,
        });
      }

      // ---------- Group by Department ----------
      const groupedByDept = new Map(); // deptTitle -> summaries[]

      for (const row of userSummaries) {
        const deptTitle = deptMap.get(row.deptId) || "Tanpa Departemen";

        if (!groupedByDept.has(deptTitle)) {
          groupedByDept.set(deptTitle, []);
        }

        groupedByDept.get(deptTitle).push(row);
      }

      const sortedDeptTitles = Array.from(groupedByDept.keys()).sort((a, b) =>
        a.localeCompare(b)
      );

      for (const deptTitle of sortedDeptTitles) {
        const list = groupedByDept.get(deptTitle);
        list.sort((a, b) => a.fullname.localeCompare(b.fullname));
      }

      // ---------- Build AoA untuk SheetJS ----------
      const rowsAoA = [];

      // Info periode
      rowsAoA.push(["MULAI", fromLabel]);
      rowsAoA.push(["SAMPAI", toLabel]);
      rowsAoA.push([]); // baris kosong

      // Header (DIVISI, NAMA LENGKAP, ...)
      rowsAoA.push(HEADER_ROW);

      for (const deptTitle of sortedDeptTitles) {
        const staffList = groupedByDept.get(deptTitle) || [];
        if (!staffList.length) continue;

        // baris DIVISI (kolom 0 = nama departemen)
        const deptRow = new Array(HEADER_ROW.length).fill("");
        deptRow[0] = deptTitle;
        rowsAoA.push(deptRow);

        let no = 1;
        for (const row of staffList) {
          const c = row.counters;
          const cols = new Array(HEADER_ROW.length).fill("");

          // NOTE:
          // Header kolom 0 = "DIVISI", tapi data dipakai sebagai "No"
          cols[0] = no;
          cols[1] = row.fullname;
          cols[2] = row.job_position;
          cols[3] = row.phone;
          cols[4] = row.email;
          cols[5] = c.totalKerja || 0;
          cols[6] = c.noTimesheet || 0;
          cols[7] = c.tanpaKeterangan || 0;
          cols[8] = c.terlambat || 0;
          cols[9] = c.cutiTahunan || 0;
          cols[10] = c.menikah || 0;
          cols[11] = c.menikahkan || 0;
          cols[12] = c.melahirkan || 0;
          cols[13] = c.mengkhitankan || 0;
          cols[14] = c.baptis || 0;
          cols[15] = c.unpaidLeave || 0;
          cols[16] = c.sakit || 0;
          cols[17] = c.berduka || 0;
          cols[18] = c.menstruasi || 0;
          cols[19] = c.melahirkanSuami || 0;
          cols[20] = c.umrah || 0;
          cols[21] = row.sisaCuti;
          cols[22] = row.tanggalCutiStr;

          rowsAoA.push(cols);
          no += 1;
        }
      }

      // ---------- SheetJS: AoA -> workbook ----------
      const wb = XLSX.utils.book_new();
      const ws = XLSX.utils.aoa_to_sheet(rowsAoA);
      XLSX.utils.book_append_sheet(wb, ws, "Attendance");

      const buffer = XLSX.write(wb, {
        bookType: "xlsx",
        type: "buffer",
      });

      const filename = `Attendance_${from}_${to}.xlsx`;

      return new Response(buffer, {
        status: 200,
        headers: {
          "Content-Type":
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
          "Content-Disposition": `attachment; filename="${filename}"`,
          "Cache-Control": "no-store",
        },
      });
    } catch (err) {
      console.error("GET /api/attendance/export error:", err);
      return new Response(
        JSON.stringify({
          error: err?.message || "Failed to export attendance report",
        }),
        { status: 500 }
      );
    }
  }
);
