// src/app/api/timesheet/enforcement/route.js
export const dynamic = "force-dynamic";
export const revalidate = 0;

import { NextResponse } from "next/server";
import { withActive } from "@/utils/session";
import db from "@/database/models";
import { Op } from "sequelize";
import dayjs from "dayjs";
import utc from "dayjs/plugin/utc";
import tz from "dayjs/plugin/timezone";

dayjs.extend(utc);
dayjs.extend(tz);

const APP_TZ = process.env.NEXT_PUBLIC_APP_TIMEZONE || "Asia/Jakarta";
const { Timesheet, Holiday, TaskAssignment } = db;

// waktu lokal
const JKT_NOW = () => dayjs().tz(APP_TZ);

// ====== cache libur nasional (TTL 6 jam) ======
let HOLI_SET = new Set(); // berisi 'YYYY-MM-DD'
let HOLI_LOADED_AT = 0;   // epoch ms
const HOLI_TTL_MS = 6 * 60 * 60 * 1000;

async function ensureHolidayCache() {
  const now = Date.now();
  // kalau masih fresh pakai yang ada
  if (HOLI_SET.size && now - HOLI_LOADED_AT < HOLI_TTL_MS) return;

  const y = JKT_NOW().year();
  const from = `${y - 1}-01-01`;
  const to = `${y + 1}-12-31`;

  // kalau model Holiday gak ada, kosongin aja
  if (!Holiday) {
    HOLI_SET = new Set();
    HOLI_LOADED_AT = now;
    return;
  }

  const rows = await Holiday.findAll({
    where: {
      date: { [Op.between]: [from, to] },
      is_day_off: { [Op.in]: ["true"] },
    },
    attributes: ["date"],
    raw: true,
  });

  HOLI_SET = new Set(rows.map((r) => dayjs(r.date).format("YYYY-MM-DD")));
  HOLI_LOADED_AT = now;
}

const isWeekend = (d) => {
  const wd = dayjs(d).day(); // 0=Min, 6=Sab
  return wd === 0 || wd === 6;
};

async function isHoliday(ymd) {
  await ensureHolidayCache();
  return HOLI_SET.has(ymd);
}

/**
 * Ambil hari kerja sebelumnya:
 * - mundur 1 hari dari hari ini (timezone app)
 * - skip Sabtu/Minggu
 * - skip tanggal merah dari tabel Holiday
 */
async function previousWorkingDay() {
  let d = JKT_NOW().subtract(1, "day");
  while (true) {
    const ymd = d.format("YYYY-MM-DD");
    if (!isWeekend(d) && !(await isHoliday(ymd))) {
      return ymd;
    }
    d = d.subtract(1, "day");
  }
}

/**
 * GET /api/timesheet/enforcement
 * return:
 *   { required: false }
 *   { required: true, date: "YYYY-MM-DD", redirect: "/timesheet?force=1&date=YYYY-MM-DD" }
 */
export const GET = withActive(async function handler(req, ctx, currentUser) {
  try {
    // 1) kalau user belum pernah di-assign task → jangan dipaksa
    if (TaskAssignment) {
      const assignCount = await TaskAssignment.count({
        where: {
          user_id: currentUser.user_id,
          deleted: { [Op.or]: [null, 0] },
        },
      });

      if (assignCount === 0) {
        return NextResponse.json(
          { required: false, reason: "no-assignment" },
          { status: 200 }
        );
      }
    }

    // 2) hitung hari kerja sebelumnya (bukan hari ini)
    const targetDate = await previousWorkingDay();

    // 3) cek timesheet di tanggal itu
    //    kamu tadi minta “wajib ada confirmation button”, dan di /api/timesheet/confirm
    //    semua timesheet di-tanggal itu di-set ke status "approved".
    //    jadi di sini kita anggap “udah beres” = sudah ada yang approved.
    const count = await Timesheet.count({
      where: {
        user_id: currentUser.user_id,
        date: targetDate,
        status: { [Op.eq]: "approved" },
        deleted: null,
      },
    });

    // kalau sudah ada yang approved → gak usah enforce
    if (count > 0) {
      return NextResponse.json({ required: false }, { status: 200 });
    }

    // 4) belum ada / belum approve → WAJIB
    // sekalian kita kirimkan URL yang “mode paksa” biar nanti middleware/frontend bisa pakai
    const redirect = `/timesheet?force=1&date=${targetDate}`;

    return NextResponse.json(
      {
        required: true,
        date: targetDate,
        redirect,
        enforce: true,
      },
      { status: 200 }
    );
  } catch (err) {
    console.error("Timesheet enforcement error:", err);
    return NextResponse.json(
      { error: err?.message || "Server error" },
      { status: 500 }
    );
  }
});
