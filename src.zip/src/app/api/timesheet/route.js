// src/app/api/timesheet/route.js
export const dynamic = 'force-dynamic';
export const revalidate = 0;

import { NextResponse } from 'next/server';
import db from "@/database/models";
import { withActive } from "@/utils/session";
import dayjs from 'dayjs';
import timezone from 'dayjs/plugin/timezone';

dayjs.extend(timezone);
const APP_TZ = process.env.NEXT_PUBLIC_APP_TIMEZONE || "Asia/Jakarta";
dayjs.tz.setDefault(APP_TZ);

const { Timesheet, Project, Task, Attendance } = db;

// Helpers
function hhmmToMinutes(hhmm) {
  if (!hhmm || typeof hhmm !== 'string') return null;
  const [h, m] = hhmm.split(':').map(Number);
  if (Number.isNaN(h) || Number.isNaN(m)) return null;
  return h * 60 + m;
}

// GET /api/timesheet
export const GET = withActive(async function GET_HANDLER(req, context, currentUser) {
  try {
    const { searchParams } = new URL(req.url);
    const userId = currentUser.user_id;

    const whereClause = { user_id: userId, deleted: null };

    // Filter by month (YYYY-MM)
    const month = searchParams.get('month');
    if (month && dayjs(month, 'YYYY-MM').isValid()) {
      const startDate = dayjs(month).startOf('month').format('YYYY-MM-DD');
      const endDate = dayjs(month).endOf('month').format('YYYY-MM-DD');
      whereClause.date = {
        [db.Sequelize.Op.between]: [startDate, endDate]
      };
    }

    const timesheetData = await Timesheet.findAll({
      where: whereClause,
      include: [
        { model: Project, as: 'Project', attributes: ['title'] },
        { model: Task, as: 'Task', attributes: ['title'] },
      ],
      order: [['date', 'DESC'], ['start_time', 'DESC']]
    });

    return NextResponse.json({ data: timesheetData });
  } catch (error) {
    console.error("Error fetching timesheets:", error);
    return NextResponse.json({ error: "Failed to fetch timesheets." }, {
      status: 500,
    });
  }
});

// POST /api/timesheet
export const POST = withActive(async function POST_HANDLER(req, context, currentUser) {
  const body = await req.json();

  // ===== Validasi minimum =====
  if (!body.projectId || !body.taskId || !body.date) {
    return NextResponse.json({ error: "Project, Task, and Date are required." }, { status: 400 });
  }

  // ===== Validasi best-effort keberadaan project & task =====
  try {
    const [proj, task] = await Promise.all([
      Project.findOne({ where: { project_id: body.projectId } }),
      Task.findOne({ where: { task_id: body.taskId } }),
    ]);
    if (!proj) return NextResponse.json({ error: "Project not found." }, { status: 404 });
    if (!task) return NextResponse.json({ error: "Task not found." }, { status: 404 });

    // ===== Hitung start_time, end_time, duration_minutes =====
    let start_time = null;
    let end_time = null;
    let duration_minutes = 0;

    // Mode durasi: hanya duration_minutes (tanpa start/end dari FE)
    const isDurationMode = body.durationMinutes > 0 && (!body.startTime || !body.endTime);
    const isStartFinishMode = !isDurationMode;

    if (isDurationMode) {
      duration_minutes = Math.floor(body.durationMinutes);
      if (!Number.isFinite(duration_minutes) || duration_minutes <= 0) {
        return NextResponse.json({ error: "Duration must be greater than 0 minutes." }, { status: 400 });
      }

      // Jika start/end tidak dikirim (ambil schedule / durasi saja),
      // isi start_time & end_time berbasis "now" agar tidak kosong.
      const nowTz = dayjs().tz(APP_TZ);
      let baseDateTime;
      if (body.date && dayjs(body.date, "YYYY-MM-DD", true).isValid()) {
        // tanggal dari payload, jam-menit dari "now"
        baseDateTime = dayjs.tz(
          `${body.date} ${nowTz.format("HH:mm")}`,
          "YYYY-MM-DD HH:mm",
          APP_TZ
        );
      } else {
        baseDateTime = nowTz;
      }

      const endDateTime = baseDateTime.add(duration_minutes, "minute");

      start_time = baseDateTime.format("HH:mm");
      end_time = endDateTime.format("HH:mm");
    } else {
      if (!body.startTime || !body.endTime) {
        return NextResponse.json({ error: "Start time and End time are required." }, { status: 400 });
      }
      const s = hhmmToMinutes(body.startTime);
      const e = hhmmToMinutes(body.endTime);
      if (s === null || e === null) {
        return NextResponse.json({ error: "Invalid time format. Expected HH:mm." }, { status: 400 });
      }
      if (e < s) {
        return NextResponse.json({ error: "End time cannot be before start time." }, { status: 400 });
      }
      start_time = body.startTime;
      end_time = body.endTime;
      duration_minutes = e - s;
    }

    // Hitung clock-in (UNIX) dari kombinasi date + start_time
    let clockInUnixForAttendance = null;
    if (start_time && body.date && dayjs(body.date, "YYYY-MM-DD", true).isValid()) {
      const startDateTime = dayjs.tz(
        `${body.date} ${start_time}`,
        "YYYY-MM-DD HH:mm",
        APP_TZ
      );
      if (startDateTime.isValid()) {
        clockInUnixForAttendance = startDateTime.unix();
      }
    }

    const nowUnix = dayjs().unix();

    // ===== Create Timesheet =====
    const newTimesheet = await Timesheet.create({
      user_id: currentUser.user_id,
      project_id: body.projectId,
      task_id: body.taskId,
      date: body.date,
      start_time,           // jam mulai (auto-isi utk mode durasi jika perlu)
      end_time,             // jam selesai (auto-isi utk mode durasi jika perlu)
      duration_minutes,     // total menit
      status: "submitted",
      created: nowUnix,
      created_by: currentUser.user_id,
      updated: nowUnix,
      updated_by: currentUser.user_id,
    });

    // ===== AUTO-ATTENDANCE =====
    // - jika user belum absen di tanggal tsb, isi otomatis dari timesheet
    // - clock_in diambil dari kombinasi date + start_time (kalau ada)
    if (clockInUnixForAttendance && Attendance) {
      try {
        const existing = await Attendance.findOne({
          where: { user_id: currentUser.user_id, date: body.date }
        });

        if (!existing) {
          const latVal = body.latitude ?? body.lat;
          const lonVal = body.longitude ?? body.lng ?? body.long; // longAlt → body.long
          const latNum = (latVal !== undefined && latVal !== null) ? Number(latVal) : null;
          const lonNum = (lonVal !== undefined && lonVal !== null) ? Number(lonVal) : null;

          await Attendance.create({
            user_id: currentUser.user_id,
            date: body.date,
            clock_in: clockInUnixForAttendance,
            clock_out: null,
            location_latitude: Number.isFinite(latNum) ? latNum : null,
            location_longitude: Number.isFinite(lonNum) ? lonNum : null,
            status: 'present',
            source: 'timesheet',
            note: 'Auto created from timesheet',
            timesheet: "true",
            duration_minutes: 0,
            minutes_late: 0,
            late_reason: null,
            created: nowUnix,
            created_by: currentUser.user_id,
            updated: nowUnix,
            updated_by: currentUser.user_id,
          });
        } else {
          // Sudah absen → tandai bahwa ada timesheet untuk tanggal tsb
          await existing.update({
            timesheet: "true",
            updated: nowUnix,
            updated_by: currentUser.user_id,
          });
        }
      } catch (attErr) {
        // Jangan gagalkan timesheet kalau attendance gagal
        console.warn('Auto-attendance failed:', attErr?.message || attErr);
      }
    }

    return NextResponse.json({ message: "Timesheet submitted!", data: newTimesheet }, { status: 201 });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Failed to submit timesheet." }, { status: 500 });
  }
});

// PUT /api/timesheet/[id]
export const PUT = withActive(async function PUT_HANDLER(req, context, currentUser) {
  const { params } = context;
  const { id } = params;
  const body = await req.json();

  try {
    const timesheet = await Timesheet.findOne({
      where: { timesheet_id: id, user_id: currentUser.user_id, deleted: null },
    });

    if (!timesheet) {
      return NextResponse.json({ error: "Timesheet not found." }, { status: 404 });
    }

    let { startTime, endTime, durationMinutes, description, status } = body;

    let updates = {};
    if (description !== undefined) updates.description = description;
    if (status !== undefined) updates.status = status;

    if (durationMinutes !== undefined && (startTime === undefined && endTime === undefined)) {
      // Mode durasi
      const mins = Math.floor(durationMinutes);
      if (!Number.isFinite(mins) || mins <= 0) {
        return NextResponse.json({ error: "Duration must be greater than 0 minutes." }, { status: 400 });
      }
      updates.duration_minutes = mins;
      updates.start_time = null;
      updates.end_time = null;
    } else if (startTime !== undefined && endTime !== undefined) {
      const s = hhmmToMinutes(startTime);
      const e = hhmmToMinutes(endTime);
      if (s === null || e === null) {
        return NextResponse.json({ error: "Invalid time format. Expected HH:mm." }, { status: 400 });
      }
      if (e < s) {
        return NextResponse.json({ error: "End time cannot be before start time." }, { status: 400 });
      }
      updates.start_time = startTime;
      updates.end_time = endTime;
      updates.duration_minutes = e - s;
    }

    updates.updated = dayjs().unix();
    updates.updated_by = currentUser.user_id;

    await timesheet.update(updates);

    return NextResponse.json({ message: "Timesheet updated successfully.", data: timesheet });
  } catch (error) {
    console.error("Error updating timesheet:", error);
    return NextResponse.json({ error: "Failed to update timesheet." }, { status: 500 });
  }
});

// DELETE /api/timesheet/[id]
export const DELETE = withActive(async function DELETE_HANDLER(req, context, currentUser) {
  const { params } = context;
  const { id } = params;

  try {
    const timesheet = await Timesheet.findOne({
      where: { timesheet_id: id, user_id: currentUser.user_id, deleted: null },
    });

    if (!timesheet) {
      return NextResponse.json({ error: "Timesheet not found." }, { status: 404 });
    }

    await timesheet.update({
      deleted: dayjs().unix(),
      deleted_by: currentUser.user_id,
    });

    return NextResponse.json({ message: "Timesheet deleted successfully." });
  } catch (error) {
    console.error("Error deleting timesheet:", error);
    return NextResponse.json({ error: "Failed to delete timesheet." }, { status: 500 });
  }
});
