// src/app/api/menu/route.js
export const dynamic = "force-dynamic";
export const revalidate = 0;

import { NextResponse } from "next/server";
import db from "@/database/models";
import dayjs from "dayjs";
import utc from "dayjs/plugin/utc";
import { withAuth } from "@/utils/session";

dayjs.extend(utc);

const { Menu } = db;
const nowUnix = () => dayjs().utc().unix();

/**
 * Normalisasi value boolean ke enum string "true"/"false"
 * Accept:
 *  - "true" / "false"
 *  - true / false
 *  - 1 / 0
 *  - "1" / "0"
 */
function normalizeBoolEnum(value, defaultValue = "true") {
  if (value === undefined || value === null) return defaultValue;

  if (value === true || value === "true" || value === 1 || value === "1") {
    return "true";
  }
  if (value === false || value === "false" || value === 0 || value === "0") {
    return "false";
  }
  return defaultValue;
}

// ============================ GET ============================
export const GET = withAuth(async function GET_HANDLER(req, context, currentUser) {
  try {
    const menus = await Menu.findAll({
      order: [
        ["ordered", "ASC"],
        ["title", "ASC"],
      ],
    });

    return NextResponse.json(
      { menus: menus.map((m) => m.toJSON()) },
      { status: 200 }
    );
  } catch (error) {
    console.error("Error fetching menus:", error);
    return NextResponse.json(
      { error: error.message || "Failed to fetch menus." },
      { status: 500 }
    );
  }
});

// ============================ POST ============================
export const POST = withAuth(async function POST_HANDLER(req, context, currentUser) {
  try {
    const body = await req.json().catch(() => ({}));

    const title = String(body?.title ?? "").trim();
    const path =
      body?.path != null && String(body.path).trim() !== ""
        ? String(body.path).trim()
        : null;
    const icon =
      body?.icon != null && String(body.icon).trim() !== ""
        ? String(body.icon).trim()
        : null;

    const orderedRaw = body?.ordered;
    const ordered = Number.isFinite(+orderedRaw) ? +orderedRaw : 0;

    const isActive = normalizeBoolEnum(body?.is_active, "true");
    const isShow = normalizeBoolEnum(body?.is_show, "true");

    const typeRaw = body?.type;
    const type = typeRaw === "dashboard" ? "dashboard" : "page";

    const parentIdRaw = body?.parent_id;
    const parent_id =
      parentIdRaw === null || parentIdRaw === undefined || parentIdRaw === ""
        ? null
        : Number(parentIdRaw);

    if (!title) {
      return NextResponse.json(
        { error: "Title is required." },
        { status: 400 }
      );
    }

    const now = nowUnix();
    const userId = currentUser?.user_id ?? currentUser?.id ?? null;

    if (!userId) {
      // created_by / updated_by wajib NOT NULL di model
      return NextResponse.json(
        { error: "Invalid current user (missing user_id)." },
        { status: 500 }
      );
    }

    const newMenu = await Menu.create({
      title,
      path,
      icon,
      ordered,
      is_active: isActive,
      is_show: isShow,
      type,
      parent_id,
      created: now,
      created_by: userId,
      updated: now,
      updated_by: userId,
    });

    return NextResponse.json(
      {
        message: "Menu created successfully!",
        menu: newMenu.toJSON(),
      },
      { status: 201 }
    );
  } catch (error) {
    console.error("Error creating menu:", error);

    let status = 500;
    let errMsg = error.message || "Failed to create menu.";

    // title UNIQUE
    if (error.name === "SequelizeUniqueConstraintError") {
      status = 400;
      errMsg = "Menu title must be unique.";
    }

    return NextResponse.json({ error: errMsg }, { status });
  }
});
