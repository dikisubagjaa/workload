export const dynamic = 'force-dynamic';
export const revalidate = 0;

import { NextResponse } from "next/server";
import db from "@/database/models";
import dayjs from "dayjs";
import utc from "dayjs/plugin/utc";
import timezone from "dayjs/plugin/timezone";
import { withActive } from "@/utils/session";

import {
  TZ,
  isTimeableUser,
  getStartAttendanceHHmm,
  getDeadlineAttendanceHHmm,
} from "./_rules";
import { validateClockIn, validateClockOut } from "./_guard";

// --- ADD: getClientPublicIp util ---
function getClientPublicIp(headers) {
  const xff = headers.get?.("x-forwarded-for") || headers["x-forwarded-for"];
  if (xff) {
    const parts = xff.split(",").map(s => s.trim()).filter(Boolean);
    if (parts.length > 0) return parts[0];
  }
  const rip = headers.get?.("x-real-ip") || headers["x-real-ip"];
  if (rip) return rip;
  const cip = headers.get?.("cf-connecting-ip") || headers["cf-connecting-ip"];
  if (cip) return cip;
  return null;
}

dayjs.extend(utc);
dayjs.extend(timezone);
dayjs.tz.setDefault(TZ);

const { Attendance, AttendanceConfig, Holiday, Setting, User, Sequelize } = db;
const { Op } = Sequelize;

// ===== Non-working day gate (Weekend + Holiday)
// Berlaku untuk user "timeable/strict". Clock-out tetap diperbolehkan kalau sudah clock-in.
async function getNonWorkingInfo({ strict, now, HolidayModel }) {
  if (!strict) return null;

  // dayjs().day(): 0=Sunday, 6=Saturday
  const dow = now.day();
  if (dow === 0 || dow === 6) {
    return {
      type: "weekend",
      message: "Attendance is not available on weekends.",
    };
  }

  const ymd = now.format("YYYY-MM-DD");
  if (HolidayModel?.findOne) {
    const holiday = await HolidayModel.findOne({
      where: { date: ymd },
      attributes: ["holiday_id", "date", "description"],
      raw: true,
    });
    if (holiday) {
      return {
        type: "holiday",
        message: `Attendance is not available on holidays (${holiday.description}).`,
        holiday,
      };
    }
  }

  return null;
}

/**
 * GET /api/attendance
 * Ambil status clock-in/out hari ini untuk current user
 */
export const GET = withActive(async function GET_HANDLER(req, _ctx, currentUser) {
  try {
    const userId = currentUser?.user_id || currentUser?.id || currentUser?.userId;
    if (!userId) {
      return NextResponse.json({ error: "Unauthenticated" }, { status: 401 });
    }

    const now = dayjs().tz(TZ);
    const today = now.format("YYYY-MM-DD");

    // Cek strict/timeable dari DB agar konsisten dengan POST
    const dbUser = await User.findOne({
      where: { user_id: userId },
      attributes: ["absent_type"],
      raw: true,
    });
    const strict = isTimeableUser(currentUser, dbUser?.absent_type);

    // Non-working day info (weekend/holiday) for strict users
    const nonWorking = await getNonWorkingInfo({
      strict,
      now,
      HolidayModel: Holiday,
    });

    const row = await Attendance.findOne({
      where: { user_id: userId, date: today },
    });

    if (!row) {
      return NextResponse.json(
        {
          in_unix: null,
          out_unix: null,
          status: null,
          blocked: Boolean(nonWorking),
          blocked_reason: nonWorking?.message || null,
        },
        { status: 200 }
      );
    }

    const j = row.toJSON();
    return NextResponse.json(
      {
        in_unix: j.clock_in ?? j.in_unix ?? null,
        out_unix: j.clock_out ?? j.out_unix ?? null,
        status: j.status ?? null,
        minutes_late: j.minutes_late ?? 0,
        blocked: Boolean(nonWorking && !(j.clock_in ?? j.in_unix)),
        blocked_reason:
          nonWorking && !(j.clock_in ?? j.in_unix) ? nonWorking.message : null,
      },
      { status: 200 }
    );
  } catch (err) {
    return NextResponse.json(
      { error: err?.message || "Failed" },
      { status: 500 }
    );
  }
});

/**
 * POST /api/attendance?action=clock-in|clock-out
 * Body (opsional saat telat): { late_reason: string, latitude, longitude, accuracy? }
 */
export const POST = withActive(async function POST_HANDLER(req, _ctx, currentUser) {
  try {
    const userId = currentUser?.user_id || currentUser?.id || currentUser?.userId;
    if (!userId) {
      return NextResponse.json({ error: "Unauthenticated" }, { status: 401 });
    }

    const url = new URL(req.url);
    let body = {};
    try {
      body = await req.json();
    } catch {
      body = {};
    }

    const action = url.searchParams.get("action") || body?.action;
    if (!action || !["clock-in", "clock-out"].includes(action)) {
      return NextResponse.json(
        { error: "action must be 'clock-in' or 'clock-out'" },
        { status: 400 }
      );
    }

    // --- GEO HANDLING (wajib untuk clock-in non-manual) ---
    const geo = {};
    const hasGeo =
      typeof body?.latitude === "number" &&
      typeof body?.longitude === "number";

    if (hasGeo) {
      geo.latitude = body.latitude;
      geo.longitude = body.longitude;
      if (typeof body?.accuracy === "number") {
        geo.accuracy = body.accuracy;
      }
    }

    // Location is mandatory for clock-in (non-manual)
    if (action === "clock-in" && !hasGeo) {
      return NextResponse.json(
        {
          error: "Location is required for attendance",
          need_location: true,
        },
        { status: 400 }
      );
    }

    const now = dayjs().tz(TZ);
    const today = now.format("YYYY-MM-DD");
    let row = await Attendance.findOne({
      where: { user_id: userId, date: today },
    });

    // SELALU ambil absent_type dari DB agar guard akurat
    const dbUser = await User.findOne({
      where: { user_id: userId },
      attributes: ["absent_type"],
      raw: true,
    });
    const strict = isTimeableUser(currentUser, dbUser?.absent_type);

    // Non-working day info (weekend/holiday) for strict users (clock-in only)
    const nonWorking = await getNonWorkingInfo({
      strict,
      now,
      HolidayModel: Holiday,
    });

    // --- Office-only gate berdasarkan IP whitelist ---
    const attendanceType = String(currentUser?.attendance_type || "").toLowerCase();
    if (attendanceType === "office") {
      const clientIp = getClientPublicIp(req.headers) || "0.0.0.0";
      const ok = await AttendanceConfig.findOne({
        where: { ip: clientIp, active: 1 },
      });
      if (!ok) {
        return NextResponse.json(
          {
            error: "Clock-in/out hanya bisa dari IP kantor yang di-whitelist.",
            client_ip: clientIp,
          },
          { status: 403 }
        );
      }
    }

    // ===== CLOCK-IN =====
    if (action === "clock-in") {
      if (nonWorking && !row?.clock_in) {
        return NextResponse.json(
          {
            error: nonWorking.message,
            blocked: true,
            blocked_reason: nonWorking.message,
            holiday: nonWorking.holiday || null,
          },
          { status: 403 }
        );
      }

      const openHHmm = strict ? await getStartAttendanceHHmm(Setting) : "00:00";
      const deadlineHHmm = strict ? await getDeadlineAttendanceHHmm(Setting) : "23:59";

      const guard = validateClockIn({
        strict,
        now,
        openHHmm,
        deadlineHHmm,
        late_reason: body?.late_reason,
      });

      if (!guard.ok) {
        if (guard.need_reason) {
          return NextResponse.json(
            {
              error: "Late clock-in requires reason",
              need_reason: true,
              deadline: guard.deadline,
            },
            { status: 400 }
          );
        }
        return NextResponse.json(
          { error: guard.error || "Clock-in blocked" },
          { status: 403 }
        );
      }

      if (row?.clock_in) {
        return NextResponse.json(
          { error: "Already clocked in today" },
          { status: 409 }
        );
      }

      const clockInUnix = now.unix();

      // create new attendance row
      if (!row) {
        row = await Attendance.create({
          user_id: userId,
          date: today,
          clock_in: clockInUnix,
          clock_out: null,
          status: guard.status || "present", // "present" | "late"
          duration_minutes: 0,
          late_reason: body?.late_reason || null,
          minutes_late: guard.minutesLate || 0,
          location_latitude: geo.latitude,
          location_longitude: geo.longitude,
          created: now.unix(),
          updated: now.unix(),
          created_by: userId,
          updated_by: userId,
        });
      } else {
        // update existing row (fallback isi lokasi kalau sebelumnya null)
        const updatePayload = {
          clock_in: clockInUnix,
          status: guard.status || "present",
          late_reason: body?.late_reason || null,
          minutes_late: guard.minutesLate || 0,
          updated: now.unix(),
          updated_by: userId,
        };

        if (
          row.location_latitude == null &&
          row.location_longitude == null &&
          hasGeo
        ) {
          updatePayload.location_latitude = geo.latitude;
          updatePayload.location_longitude = geo.longitude;
        }

        await row.update(updatePayload);
      }

      // ENUM('true','false') → simpan string
      if (User?.update) {
        await User.update(
          { is_clocked_in: "true", updated: now.unix(), updated_by: userId },
          { where: { user_id: userId } }
        );
      }

      return NextResponse.json(
        { in_unix: clockInUnix, late: guard.status === "late" },
        { status: 200 }
      );
    }

    // ===== CLOCK-OUT =====
    if (!row || !row.clock_in) {
      return NextResponse.json(
        { error: "You haven't clocked in today" },
        { status: 400 }
      );
    }
    if (row.clock_out) {
      return NextResponse.json(
        { error: "Already clocked out today" },
        { status: 409 }
      );
    }

    const guardOut = validateClockOut({
      strict,
      now,
      clock_in_unix: row.clock_in,
    });

    if (!guardOut.ok) {
      if (guardOut.need_seconds) {
        return NextResponse.json(
          {
            error: guardOut.error || "Clock-out too soon",
            need_seconds: guardOut.need_seconds,
          },
          { status: 403 }
        );
      }
      return NextResponse.json(
        { error: guardOut.error || "Clock-out blocked" },
        { status: 403 }
      );
    }

    const clockOutUnix = now.unix();
    const durationMinutes = Math.floor((clockOutUnix - row.clock_in) / 60);

    const updatePayloadOut = {
      clock_out: clockOutUnix,
      duration_minutes: durationMinutes,
      updated: now.unix(),
      updated_by: userId,
    };

    // fallback isi lokasi kalau sebelumnya null & FE kirim geo saat clock-out
    if (
      row.location_latitude == null &&
      row.location_longitude == null &&
      hasGeo
    ) {
      updatePayloadOut.location_latitude = geo.latitude;
      updatePayloadOut.location_longitude = geo.longitude;
    }

    await row.update(updatePayloadOut);

    if (User?.update) {
      await User.update(
        { is_clocked_in: "false", updated: now.unix(), updated_by: userId },
        { where: { user_id: userId } }
      );
    }

    return NextResponse.json(
      { out_unix: clockOutUnix, duration_minutes: durationMinutes },
      { status: 200 }
    );
  } catch (err) {
    return NextResponse.json(
      { error: err.message || "Failed" },
      { status: 500 }
    );
  }
});
