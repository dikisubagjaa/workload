// src/utils/dataFetchHelpers.js
// Ini adalah file utilitas untuk mengambil data opsi Select/Dropdown dari API.

import axiosInstance from "@/utils/axios"; // Pastikan axiosInstance diimpor

/**
 * Mengambil daftar Project dari API dan memformatnya untuk Select/Dropdown.
 * Asumsi API endpoint: GET /api/project
 * Asumsi response.data: { project: [{ uuid: string, title: string }] }
 * @returns {Promise<Array<{value: string, label: string}>>} Array of project options.
 * @throws {Error} Jika panggilan API gagal atau format respons tidak valid.
 */

export async function getProjectsForSelect() {
    try {
        const response = await axiosInstance.get('/project');

        console.log("dataFetchHelpers: Raw API Response for /project:", response.data); // DEBUG LOG 1

        if (!response.data || !Array.isArray(response.data.project)) {
            console.error("dataFetchHelpers: Invalid response format from /project API. Expected an array in 'project' property. Response:", response.data); // DEBUG LOG 2
            throw new Error("Invalid response format from /project API.");
        }

        console.log("dataFetchHelpers: Projects array before mapping:", response.data.project); // DEBUG LOG 3

        const formattedProjects = response.data.project.map(p => {
            const mappedItem = {
                value: p.uuid,
                label: p.title
            };
            console.log("dataFetchHelpers: Mapped Project Item:", mappedItem); // DEBUG LOG 4
            return mappedItem;
        });

        console.log("dataFetchHelpers: Final formatted projects for select:", formattedProjects); // DEBUG LOG 5
        return formattedProjects;
    } catch (error) {
        console.error("dataFetchHelpers: Error fetching projects for select:", error);
        throw error;
    }
}


/**
 * Mengambil daftar Department dari API dan memformatnya untuk Select/Dropdown.
 * Asumsi API endpoint: GET /api/department
 * Asumsi response.data: { department: [{ department_id: number, title: string }] }
 * @returns {Promise<Array<{value: number, label: string}>>} Array of department options.
 * @throws {Error} Jika panggilan API gagal atau format respons tidak valid.
 */
export async function getDepartmentsForSelect() {
    try {
        const response = await axiosInstance.get('/department');
        if (!response.data || !Array.isArray(response.data.department)) {
            throw new Error("Invalid response format from /department API. Expected an array in 'department' property.");
        }
        return response.data.department.map(d => ({
            value: d.department_id,
            label: d.title
        }));
    } catch (error) {
        console.error("Error fetching departments for select:", error);
        throw error;
    }
}

/**
 * Mengambil daftar User dari API dan memformatnya untuk Select/Dropdown.
 * Asumsi API endpoint: GET /api/users
  * @returns {Promise<Array<{value: number, label: string}>>} Array of user options.
 * @throws {Error} Jika panggilan API gagal atau format respons tidak valid.
 */
export async function getUsersForSelect() {
    try {
        const response = await axiosInstance.get('/users');
        if (!response.data || !Array.isArray(response.data.data)) {
            throw new Error("Invalid response format from /users API. Expected an array in 'users' property.");
        }
        return response.data.data.map(u => ({
            value: u.user_id,
            label: u.fullname.trim()
        }));
    } catch (error) {
        console.error("Error fetching users for select:", error);
        throw error;
    }
}

/**
 * Mengambil daftar ProjectQuotation berdasarkan Project UUID dari API dan memformatnya.
 * Asumsi API endpoint: GET /api/project/[projectUuid]/quotation
 * Asumsi response.data: { pqData: [{ uuid: string, quotation_number: string }] }
 * @param {string} projectUuid - UUID dari Project.
 * @returns {Promise<Array<{value: string, label: string}>>} Array of quotation options.
 * @throws {Error} Jika panggilan API gagal atau format respons tidak valid.
 */
export async function getQuotationsForSelect(projectUuid) {
    if (!projectUuid) return [];
    try {
        const response = await axiosInstance.get(`/project/${projectUuid}/quotation`);
        if (!response.data || !Array.isArray(response.data.pqData)) {
            throw new Error("Invalid response format from /project/[uuid]/quotation API. Expected an array in 'pqData' property.");
        }
        return response.data.pqData.map(q => ({
            value: q.uuid,
            label: q.quotation_number
        }));
    } catch (error) {
        console.error("Error fetching quotations for select:", error);
        throw error;
    }
}

/**
 * Mengambil daftar PO berdasarkan Project UUID dan Quotation UUID dari API dan memformatnya.
 * Asumsi API endpoint: GET /api/project/[projectUuid]/quotation/[quotationUuid]
 * Asumsi response.data: { poDoc: [{ po_number: string }] }
 * @param {string} projectUuid - UUID dari Project yang terpilih.
 * @param {string} quotationUuid - UUID dari ProjectQuotation yang terpilih.
 * @returns {Promise<Array<{value: string, label: string}>>} Array of PO options.
 * @throws {Error} Jika panggilan API gagal atau format respons tidak valid.
 */
export async function getPoForSelect(projectUuid, quotationUuid) {
    if (!projectUuid || !quotationUuid) return [];
    try {
        // Sesuaikan URL API ini agar sesuai dengan endpoint PO Anda.
        const response = await axiosInstance.get(`/project/${projectUuid}/quotation/${quotationUuid}`);
        if (!response.data || !Array.isArray(response.data.poDoc)) {
            throw new Error("Invalid response format from PO API. Expected an array in 'poDoc' property.");
        }
        // Filter untuk mendapatkan hanya nomor PO yang unik
        const uniquePoNumbers = Array.from(new Set(response.data.poDoc.filter(po => po.po_number).map(po => po.po_number)));
        return uniquePoNumbers.map(poNumber => ({
            value: poNumber,
            label: poNumber
        }));
    } catch (error) {
        console.error("Error fetching POs for select:", error);
        throw error;
    }
}