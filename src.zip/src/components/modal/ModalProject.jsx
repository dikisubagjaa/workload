// /src/components/modal/ModalProject.jsx
"use client";
import Image from "next/image";
import { useRouter, useSearchParams, usePathname } from "next/navigation";
import { Button, Form, Input, Modal, Select, Upload, message } from "antd";
import { useRef, useState, useEffect, useCallback, useMemo } from "react";
import axiosInstance from "@/utils/axios";
import dayjs from "dayjs";

import Step1_ChooseClientType from "./project/Step1_ChooseClientType";
import Step2_SelectExistingClient from "./project/Step2_SelectExistingClient";
import Step3_ProjectForm from "./project/Step3_ProjectForm";
import { asset } from "@/utils/url";

// Helper: pecah nomor telepon
const parsePhoneNumber = (phone, countryCodes = []) => {
  if (!phone) return { code: "+62", number: "" };
  const sorted = [...new Set([...countryCodes, "+62", "+1", "+65"])].sort(
    (a, b) => b.length - a.length
  );
  for (const code of sorted) {
    if (String(phone).startsWith(code)) {
      return { code, number: String(phone).substring(code.length) };
    }
  }
  return { code: "+62", number: String(phone).replace(/^(0|62)/, "") };
};

export default function ModalProject({
  modalProject,
  onCancel,
  onSuccess,
  editingRecord, // opsional: jika parent mau pasang obj project yg sedang diedit
}) {
  const router = useRouter();
  const searchParams = useSearchParams();
  const pathname = usePathname();

  // === DETEKSI EDIT MODE DARI URL ATAU PROPS ===
  const projectIdFromQuery = useMemo(() => {
    const val = searchParams.get("project");
    return val ? Number(val) : null;
  }, [searchParams]);

  const [projectId, setProjectId] = useState(null);
  const isEditing = !!editingRecord || !!projectIdFromQuery;

  // === STATE & FORM ===
  const [form] = Form.useForm();
  const inputRef = useRef(null);
  const [loading, setLoading] = useState(false);

  // langkah-langkah modal (mengikuti struktur asli)
  const [step1, setStep1] = useState(true);
  const [existingClient, setExistingClient] = useState(false);
  const [newClient, setNewClient] = useState(false);
  const [inputProjectName, setInputProjectName] = useState(false);
  const [isClientDisabled, setClientDisabled] = useState(false);

  const [itemsQuotation, setItemsQuotation] = useState([]);
  const [brand, setBrand] = useState([]);
  const [projectType, setProjectType] = useState([]);
  const [countryCode, setCountryCode] = useState([]);
  const [addProjectType, setAddProjectType] = useState("");
  const [addBrand, setAddBrand] = useState("");

  const resetState = useCallback(() => {
    setStep1(true);
    setExistingClient(false);
    setNewClient(false);
    setInputProjectName(false);
    setClientDisabled(false);
    setProjectId(null);
    form.resetFields();
  }, [form]);

  // === MASTER DATA ===
  const getBrand = useCallback(async () => {
    try {
      const res = await axiosInstance.get(`/brand`);
      if (res.status === 200) setBrand(res.data.brand || []);
    } catch {
      message.error("Failed to load brands.");
    }
  }, []);
  const getProjectType = useCallback(async () => {
    try {
      const res = await axiosInstance.get(`/project-type`);
      if (res.status === 200) setProjectType(res.data.projectType || []);
    } catch {
      message.error("Failed to load project types.");
    }
  }, []);
  const getCountryCode = useCallback(async () => {
    try {
      const res = await axiosInstance.get(`/countrycode`);
      if (res.status === 200) setCountryCode(res.data.countryCode || []);
    } catch {
      message.error("Failed to load country codes.");
    }
  }, []);

  // === PREFETCH MASTER DATA SETIAP MODAL DIBUKA ===
  useEffect(() => {
    if (!modalProject) return;
    getBrand();
    getProjectType();
    getCountryCode();
  }, [modalProject, getBrand, getProjectType, getCountryCode]);

  // === EDIT MODE: BYPASS STEP1 + PREFILL DETAIL ===
  const prefillForEdit = useCallback(
    async (pid) => {
      try {
        setLoading(true);
        setStep1(false);
        setExistingClient(false);
        setNewClient(true);
        setInputProjectName(true);
        setClientDisabled(true); // di edit, kunci field client agar aman
        setProjectId(pid);

        // Ambil detail project
        const res = await axiosInstance.get(`/project/${pid}`);
        const p = res?.data?.data || res?.data?.project || res?.data;

        // Nilai client & kontak (toleran terhadap berbagai shape)
        const client = p?.Client || p?.client || {};
        const brandList = client?.brand || p?.brand || [];
        const ptList = p?.project_type || [];

        const countryCodes = (countryCode || []).map((c) => c.code);
        const picPhone = parsePhoneNumber(client?.pic_phone, countryCodes);
        const financePhone = parsePhoneNumber(client?.finance_phone, countryCodes);

        form.setFieldsValue({
          // header
          title: p?.title || p?.projectName || "",
          // client
          client_id: p?.client_id || client?.client_id || client?.id,
          type: client?.type || p?.type,
          client_name: client?.client_name || client?.name,
          brand: brandList
            .map((b) => b?.brand_id ?? b?.id)
            .filter((x) => Number.isFinite(Number(x))),
          address: client?.address,
          pic_name: client?.pic_name,
          pic_email: client?.pic_email,
          division: client?.division,
          finance_name: client?.finance_name,
          finance_email: client?.finance_email,
          pic: { phoneCode: picPhone.code, phone: picPhone.number },
          finance: { phoneCode: financePhone.code, phone: financePhone.number },
          start_date: p?.start_date ? dayjs(p.start_date) : null,
          due_date: p?.due_date ? dayjs(p.due_date) : null,
          max_hours: p?.max_hours ?? null,
          project_type: Array.isArray(ptList)
            ? ptList
              .map((t) => {
                if (typeof t === "number" || typeof t === "string") return Number(t);
                const v = t?.pt_id ?? t?.id;
                return Number.isFinite(Number(v)) ? Number(v) : null;
              })
              .filter((v) => v !== null)
            : [],

          maintenance: String(p?.maintenance ?? "false"),
          currency: p?.currency || "IDR",
          currency_value: p?.currency_value ?? null,
          duration: String(p?.duration ?? "1"),
          terms_of_payment: String(p?.terms_of_payment ?? "1"),
        });
      } catch (err) {
        console.error("prefillForEdit error:", err);
        message.error(err?.response?.data?.error || "Failed to load project detail.");
      } finally {
        setLoading(false);
      }
    },
    [form, countryCode]
  );

  useEffect(() => {
    if (!modalProject) return;
    const pid = projectIdFromQuery || editingRecord?.project_id || editingRecord?.id;
    if (pid) prefillForEdit(Number(pid));
  }, [modalProject, projectIdFromQuery, editingRecord, prefillForEdit]);

  // === FLOW NEW / EXISTING (TETAP SESUAI FILE ASLI) ===
  const handleClient = async (type) => {
    setLoading(true);
    try {
      if (type === "newclient") {
        const res = await axiosInstance.post("/project/init");
        setProjectId(res.data.data.project_id);
        setStep1(false);
        setNewClient(true);
        setInputProjectName(true);
      } else {
        setStep1(false);
        setExistingClient(true);
      }
    } catch (error) {
      message.error("Failed to init project.");
    } finally {
      setLoading(false);
    }
  };

  const formSelectClient = async (values) => {
    setLoading(true);
    const selectedClientId = values.existingClientId;
    try {
      const init = await axiosInstance.post("/project/init", { client_id: selectedClientId });
      setProjectId(init.data.data.project_id);

      const clientRes = await axiosInstance.get(`/client/${selectedClientId}`);
      const clientData = clientRes.data.client;

      const countryCodeList = countryCode.map((c) => c.code);
      const picPhone = parsePhoneNumber(clientData.pic_phone, countryCodeList);
      const financePhone = parsePhoneNumber(clientData.finance_phone, countryCodeList);

      form.setFieldsValue({
        client_id: selectedClientId,
        type: clientData.type,
        client_name: clientData.client_name,
        brand: (clientData.brand || []).map((b) => b.brand_id),
        address: clientData.address,
        pic_name: clientData.pic_name,
        pic_email: clientData.pic_email,
        division: clientData.division,
        finance_name: clientData.finance_name,
        finance_email: clientData.finance_email,
        pic: { phoneCode: picPhone.code, phone: picPhone.number },
        finance: { phoneCode: financePhone.code, phone: financePhone.number },
      });

      setExistingClient(false);
      setNewClient(true);
      setInputProjectName(true);
      setClientDisabled(true);
    } catch (error) {
      message.error("Failed to proceed with existing client.");
    } finally {
      setLoading(false);
    }
  };

  const formProject = async (values) => {
    console.log("values", values);
    setLoading(true);
    try {
      const headerTitle = form.getFieldValue("title");
      const title = (values?.title ?? headerTitle ?? "").trim();
      if (!title) {
        message.error("Project name is required");
        setLoading(false);
        return;
      }
      let finalClientId = values.client_id;

      if (!finalClientId) {
        const picPhoneCombined = values.pic ? `${values.pic.phoneCode}${values.pic.phone}` : null;
        const financePhoneCombined =
          values.finance && values.finance.phone ? `${values.finance.phoneCode}${values.finance.phone}` : null;

        const clientPayload = {
          client_name: values.client_name,
          type: values.type,
          brand: values.brand,
          address: values.address,
          pic_name: values.pic_name,
          pic_email: values.pic_email,
          pic_phone: picPhoneCombined,
          division: values.division,
          finance_name: values.finance_name,
          finance_email: values.finance_email,
          finance_phone: financePhoneCombined,
        };
        const clientRes = await axiosInstance.post("/client", clientPayload);
        finalClientId = clientRes.data.client.client_id;
      }

      const projectPayload = {
        title: title,
        client_id: finalClientId,
        start_date: values.start_date?.format("YYYY-MM-DD"),
        due_date: values.due_date?.format("YYYY-MM-DD"),
        max_hours: values.max_hours,
        project_type: values.project_type,
        maintenance: values.maintenance,
        currency: values.currency,
        currency_value: values.currency_value,
        duration: values.duration,
        terms_of_payment: values.terms_of_payment,
        published: "published",
      };
      console.log("payload", projectPayload);

      if (isEditing && projectId) {
        await axiosInstance.put(`/project/${projectId}`, projectPayload);
      } else {
        await axiosInstance.put(`/project/${projectId}`, projectPayload); // sesuai flow init->put yang sudah ada
      }

      message.success(isEditing ? "Project updated successfully!" : "Project saved successfully!");
      onSuccess?.();
      handleCloseModal();
    } catch (error) {
      console.error("Failed to save project:", error?.response?.data || error?.message);
      message.error(error?.response?.data?.error || "Failed to save project.");
    } finally {
      setLoading(false);
    }
  };

  // === BRAND / PROJECT TYPE ADD (tetap sama) ===
  const handleAddBrand = async (e) => {
    e.preventDefault();
    if (!addBrand.trim()) return message.warning("Brand name cannot be empty.");
    try {
      const res = await axiosInstance.post("/brand", { title: addBrand });
      if (res.status === 201) {
        const newBrand = res.data.brand;
        setBrand((prev) => [...prev, newBrand]);
        setAddBrand("");
        message.success(`Brand "${newBrand.title}" added successfully!`);
        setTimeout(() => inputRef.current?.focus(), 0);
      }
    } catch {
      message.error("Failed to add brand.");
    }
  };
  const handleAddProjectType = async (e) => {
    e.preventDefault();
    if (!addProjectType.trim()) return message.warning("Project type name cannot be empty.");
    try {
      const res = await axiosInstance.post("/project-type", { title: addProjectType });
      if (res.status === 201) {
        const newType = res.data.projectType;
        setProjectType((prev) => [...prev, newType]);
        setAddProjectType("");
        message.success(`Project type "${newType.title}" added successfully!`);
      }
    } catch {
      message.error("Failed to add project type.");
    }
  };

  // === UTIL: balik ke step awal (jawaban pasti untuk tombol Cancel di flow create) ===
  const backToStep1 = useCallback(() => {
    setStep1(true);
    setExistingClient(false);
    setNewClient(false);
    setInputProjectName(false);
    setClientDisabled(false);
    setProjectId(null);
    form.resetFields();
  }, [form]);

  // === CANCEL & CLOSE (BERSIHIN QUERY URL) ===
  const handleCancelClick = useCallback(() => {
    if (isEditing) {
      // Flow edit: benar2 tutup modal & keluar dari mode edit
      onCancel?.();
      const params = new URLSearchParams(Array.from(searchParams.entries()));
      params.delete("openmodal");
      params.delete("project");
      router.push(`/project`);
    } else {
      // Flow create: KEMBALI ke step awal "Is it a new client?"
      backToStep1();
    }
  }, [isEditing, onCancel, router, searchParams, backToStep1]);

  const handleCloseModal = useCallback(() => {
    onCancel?.();
    const params = new URLSearchParams(Array.from(searchParams.entries()));
    params.delete("openmodal");
    params.delete("project");
    router.push(`${pathname}?${params.toString()}`);
  }, [onCancel, router, pathname, searchParams]);

  return (
    <Modal
      open={modalProject}
      onCancel={handleCloseModal}
      width={600}
      afterClose={resetState}
      destroyOnClose
      footer={null}
      maskClosable={false}
    >
      <Form form={form} onFinish={formProject} layout="vertical">
        {/* Header */}
        <div className="flex gap-3 border-b pb-3 fc-base mb-6">
          <div className="flex items-center h-[38px]">
            <Image src={asset("static/images/icon/app_registration.png")} width={24} height={24} alt="icon" />
          </div>
          <div className="flex-1">
            {!inputProjectName ? (
              <div className="flex items-center h-[38px]">
                <h4 className="text-lg">{isEditing ? "Edit Project" : "Register New Project"}</h4>
              </div>
            ) : (
              <Form.Item name="title" className="mb-0" rules={[{ required: true, message: "Project name is required" }]}>
                <Input placeholder="Project Name Here.." className="text-lg" variant="borderless" size="large" />
              </Form.Item>
            )}
          </div>
        </div>

        {/* Alur NEW vs EDIT */}
        {step1 && !isEditing && <Step1_ChooseClientType onSelectType={handleClient} />}

        {existingClient && !isEditing && (
          <Step2_SelectExistingClient form={form} onFinish={formSelectClient} onCancel={handleCancelClick} loading={loading} />
        )}

        {newClient && (
          <Step3_ProjectForm
            loading={loading}
            isEditing={isEditing}
            projectId={projectId}
            isClientDisabled={isClientDisabled}
            brand={brand}
            projectType={projectType}
            showCountryCode={countryCode}
            itemsQuotation={itemsQuotation}
            extraTabs={null}
            handleTabChange={() => { }}
            onCancel={handleCancelClick}
            inputRef={inputRef}
            addBrand={addBrand}
            onBrandChange={(e) => setAddBrand(e.target.value)}
            handleAddBrand={handleAddBrand}
            addProjectType={addProjectType}
            onProjectTypeChange={(e) => setAddProjectType(e.target.value)}
            handleAddProjectType={handleAddProjectType}
          />
        )}
      </Form>
    </Modal>
  );
}
