import { Client, sequelize } from "@/database/models/website";
import { getUnixTimestampUTC } from "@/utils/dateHelpers";
import { withAuth } from "@/utils/session";

export async function GET(_, { params }) {
    try {
        await sequelize.sync();
        const client = await Client.findByPk(params.id);
        if (!client) {
            return Response.json({ message: 'Not found' }, { status: 404 });
        }
        return Response.json(client);
    } catch (error) {
        console.error('❌ GET /client/:id error:', error);
        return new Response(
            JSON.stringify({ message: 'Failed to get client', error: error.message }),
            { status: 500 }
        );
    }
}

export const PUT = withAuth(async function PUT_HANDLER(req, { params }, currentUser) {
    try {
        await sequelize.sync();
        const body = await req.json();
        const client = await Client.findByPk(params.id);
        if (!client) {
            return Response.json({ message: 'Not found' }, { status: 404 });
        }
        
        const nowUnix = getUnixTimestampUTC();
        await client.update({
            ...body,
            updated: nowUnix,
            updated_by: currentUser.user_id
        });

        return Response.json({ message: 'Updated' });
    } catch (error) {
        console.error('❌ PUT /client/:id error:', error);
        return new Response(
            JSON.stringify({ message: 'Failed to update client', error: error.message }),
            { status: 500 }
        );
    }
});

export const DELETE = withAuth(async function DELETE_HANDLER(req, { params }, currentUser) {
    try {
        await sequelize.sync();

        const client = await Client.findByPk(params.id);
        if (!client) {
            return Response.json({ message: 'Not found' }, { status: 404 });
        }

        const nowUnix = getUnixTimestampUTC();
        await Client.update(
            {
                deleted: nowUnix,
                deleted_by: currentUser.user_id
            },
            { where: { client_id: params.id } }
        );

        return Response.json({ message: 'Soft deleted' });
    } catch (error) {
        console.error('❌ DELETE /client/:id error:', error);
        return new Response(
            JSON.stringify({ message: 'Failed to delete client', error: error.message }),
            { status: 500 }
        );
    }
});

