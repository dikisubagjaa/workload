// src/app/api/appraisal/approve/route.js
export const dynamic = "force-dynamic";
export const revalidate = 0;

import { NextResponse } from "next/server";
import db from "@/database/models";
import { withActive } from "@/utils/session";
import { nowUnix, isTrue } from "../_helper";

const { Appraisal } = db;

function getDeptIdFromRow(row) {
  const d1 = row?.department_id;
  if (d1 != null) return Number(d1);

  const snap = row?.staff_snapshot_json && typeof row.staff_snapshot_json === "object"
    ? row.staff_snapshot_json
    : {};
  const d2 = snap?.department_id;
  return d2 == null ? null : Number(d2);
}

function makeActorSnapshot(currentUser, atUnix) {
  return {
    user_id: Number(currentUser?.user_id),
    fullname: currentUser?.fullname || null,
    email: currentUser?.email || null,
    job_position: currentUser?.job_position || null,
    approved_at: atUnix,
  };
}

export const POST = withActive(async function POST_HANDLER(req, ctx, currentUser) {
  try {
    const body = await req.json().catch(() => ({}));
    const appraisalId = Number(body?.appraisalId);
    const actionRaw = String(body?.action || "approve").toLowerCase(); // approve|reject
    const note = body?.note != null ? String(body.note) : "";

    if (!Number.isFinite(appraisalId)) {
      return NextResponse.json({ error: "Invalid appraisalId" }, { status: 400 });
    }

    if (actionRaw !== "approve" && actionRaw !== "reject") {
      return NextResponse.json({ error: "Invalid action" }, { status: 400 });
    }

    const row = await Appraisal.findOne({
      where: { appraisal_id: appraisalId, deleted: null, deleted_by: null },
    });

    if (!row) return NextResponse.json({ error: "Not found" }, { status: 404 });

    // hanya bisa approve saat submitted
    if (String(row.status) !== "submitted") {
      return NextResponse.json({ error: "Only submitted appraisal can be approved." }, { status: 400 });
    }

    const step = String(row.current_step || "").toLowerCase(); // hod|hrd|director|done
    if (!["hod", "hrd", "director"].includes(step)) {
      return NextResponse.json({ error: "Invalid current_step for approval." }, { status: 400 });
    }

    const superadmin = isTrue(currentUser?.is_superadmin);
    const isHod = isTrue(currentUser?.is_hod);
    const isHrd = isTrue(currentUser?.is_hrd);
    const isDirector = isTrue(currentUser?.is_operational_director);

    // aturan approve:
    // - HOD approve saat step=hod
    // - HRD approve saat step=hrd
    // - Director approve saat step=director
    // - Superadmin boleh override (buat testing / emergency)
    let allowed = false;

    if (step === "hod" && isHod) allowed = true;
    if (step === "hrd" && isHrd) allowed = true;
    if (step === "director" && isDirector) allowed = true;

    // optional: HOD hanya dept sendiri
    if (allowed && step === "hod" && !superadmin) {
      const myDept = currentUser?.department_id == null ? null : Number(currentUser.department_id);
      const rowDept = getDeptIdFromRow(row);
      if (myDept != null && rowDept != null && myDept !== rowDept) {
        return NextResponse.json({ error: "Forbidden (different department)" }, { status: 403 });
      }
    }

    if (!allowed && !superadmin) {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    }

    const now = nowUnix();
    const actorId = Number(currentUser?.user_id);

    const actorSnap = makeActorSnapshot(currentUser, now);

    const prevApprovals =
      row.approvals_json && typeof row.approvals_json === "object" ? row.approvals_json : {};
    const prevHist = Array.isArray(row.approval_history_json) ? row.approval_history_json : [];

    const approvals = {
      ...prevApprovals,
      [step]: actorSnap, // simpan ke key sesuai step: hod/hrd/director
    };

    const history = prevHist.concat([
      {
        step,
        action: actionRaw,
        at: now,
        by: actorSnap,
        note: note || "",
      },
    ]);

    const updates = {
      approvals_json: approvals,
      approval_history_json: history,
      updated: now,
      updated_by: actorId,
    };

    if (actionRaw === "reject") {
      updates.status = "rejected";
      // biarin current_step tetap = step (biar ketauan reject di tahap mana)
      await row.update(updates);
      return NextResponse.json({ ok: true, data: row }, { status: 200 });
    }

    // action approve: maju step
    if (step === "hod") {
      updates.hod_approved_at = now;
      updates.current_step = "hrd";
    } else if (step === "hrd") {
      updates.hrd_approved_at = now;
      updates.current_step = "director";
    } else if (step === "director") {
      updates.director_approved_at = now;
      updates.approved_at = now;
      updates.status = "approved";
      updates.current_step = "done";
    }

    await row.update(updates);

    return NextResponse.json({ ok: true, data: row }, { status: 200 });
  } catch (error) {
    console.error("POST /api/appraisal/approve error:", error);
    return NextResponse.json({ error: error?.message || "Failed." }, { status: 500 });
  }
});
