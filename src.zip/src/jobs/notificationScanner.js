// src/jobs/notificationScanner.js
import db from "@/database/models";
import { notify } from "@/utils/notifier";

const { Op } = db.Sequelize;

// util waktu
function nowUnix() {
  return Math.floor(Date.now() / 1000);
}
function startOfTodayUnix() {
  const d = new Date();
  d.setHours(0, 0, 0, 0);
  return Math.floor(d.getTime() / 1000);
}
function ymd(date = new Date()) {
  const y = date.getFullYear();
  const m = `${date.getMonth() + 1}`.padStart(2, "0");
  const d = `${date.getDate()}`.padStart(2, "0");
  return `${y}-${m}-${d}`;
}

// baca angka dari setting.description; kalau tak ada → defaultNumber
async function getSettingNumber(varName, defaultNumber) {
  const row = await db.Setting.findOne({ where: { var_name: varName } });
  if (!row?.description) return defaultNumber;
  const n = Number(String(row.description).trim());
  return Number.isFinite(n) ? n : defaultNumber;
}

/**
 * A) Task Overdue
 * Task.end_date < now AND todo != 'completed' (dan tidak deleted)
 * Kirim ke semua assignee (TaskAssignment.user_id)
 * Dedupe harian: cek notification untuk (user_id,url) sejak awal hari ini
 */
export async function scanTaskOverdue({ limitTasks = 200 } = {}) {
  const now = nowUnix();
  const startToday = startOfTodayUnix();

  const tasks = await db.Task.findAll({
    where: {
      deleted: { [Op.is]: null },
      end_date: { [Op.lt]: now },
      todo: { [Op.ne]: "completed" },
    },
    order: [["end_date", "ASC"]],
    limit: limitTasks,
  });

  let sent = 0;
  for (const t of tasks) {
    const assignees = await db.TaskAssignment.findAll({
      where: { deleted: { [Op.is]: null }, task_id: t.task_id },
      attributes: ["user_id"],
    });

    for (const a of assignees) {
      const userId = a.user_id;
      const url = `/tasks/${t.task_id}`;

      const already = await db.Notification.count({
        where: {
          user_id: userId,
          url,
          created: { [Op.gte]: startToday },
        },
      });
      if (already) continue;

      const res = await notify({
        userId,
        sender: "system",
        description: `Task overdue: ${t.title || t.task_id}`,
        url,
        payload: { type: "taskOverdue", taskId: t.task_id },
      });
      if (!res?.skipped) sent++;
    }
  }
  return { ok: true, totalTasks: tasks.length, sent };
}

/**
 * B) Member Overdue (kontrak lewat)
 * UserContract.end_date < now (dan tidak deleted)
 * Kirim ke user_id pemilik kontrak
 * Dedupe harian: (user_id, contract_id)
 */
export async function scanMemberOverdue({ limit = 200 } = {}) {
  const now = nowUnix();
  const startToday = startOfTodayUnix();

  const rows = await db.UserContract.findAll({
    where: {
      deleted: { [Op.is]: null },
      end_date: { [Op.lt]: now },
    },
    order: [["end_date", "ASC"]],
    limit,
  });

  let sent = 0;
  for (const r of rows) {
    const userId = r.user_id;
    const url = `/contracts/${r.contract_id}`;

    const already = await db.Notification.count({
      where: {
        user_id: userId,
        url,
        created: { [Op.gte]: startToday },
      },
    });
    if (already) continue;

    const res = await notify({
      userId,
      sender: "system",
      description: "Kontrak kamu sudah melewati masa berlaku.",
      url,
      payload: { type: "memberOverdue", contractId: r.contract_id },
    });
    if (!res?.skipped) sent++;
  }
  return { ok: true, total: rows.length, sent };
}

/**
 * C) Overtime Limit (harian)
 * Sum Timesheet.duration_minutes per user untuk hari ini > batas
 * Batas dari setting (default 120 menit)
 */
export async function scanOvertimeLimitDaily() {
  const day = ymd();
  const startToday = startOfTodayUnix();
  const dailyLimit = await getSettingNumber(
    "overtime_daily_limit_minutes",
    120
  );

  // Ambil data per user (pakai raw query simpel agar portable)
  const [rows] = await db.sequelize.query(
    `
      SELECT user_id, SUM(duration_minutes) AS total_min
      FROM timesheet
      WHERE deleted IS NULL
        AND date = :day
      GROUP BY user_id
      HAVING total_min > :limit
    `,
    { replacements: { day, limit: dailyLimit } }
  );

  let sent = 0;
  for (const r of rows) {
    const userId = r.user_id;
    const url = `/timesheet?date=${day}`;

    const already = await db.Notification.count({
      where: {
        user_id: userId,
        url,
        created: { [Op.gte]: startToday },
      },
    });
    if (already) continue;

    const res = await notify({
      userId,
      sender: "system",
      description: `Lembur harian melebihi ${dailyLimit} menit (hari ${day}).`,
      url,
      payload: { type: "overtimeLimit", date: day, total: r.total_min },
    });
    if (!res?.skipped) sent++;
  }

  return { ok: true, usersFlagged: rows.length, sent, dailyLimit };
}

/**
 * D) Late to Work
 * attendance.date = hari ini AND clock_in IS NULL
 * Hanya dieksekusi bila waktu >= (work_start_hour + grace)
 * work_start_hour & work_grace_minutes dari setting (default 9 & 15)
 */
export async function scanLateToWork() {
  const day = ymd();
  const startToday = startOfTodayUnix();

  const startHour = await getSettingNumber("work_start_hour", 9);
  const graceMin = await getSettingNumber("work_grace_minutes", 15);

  // cutoff time
  const cutoff = new Date();
  cutoff.setHours(startHour, graceMin, 0, 0);
  if (Date.now() < cutoff.getTime()) {
    return {
      ok: true,
      skipped: true,
      reason: `Belum lewat cutoff ${startHour}:${String(graceMin).padStart(
        2,
        "0"
      )}`,
    };
  }

  const rows = await db.Attendance.findAll({
    where: {
      deleted: { [Op.is]: null },
      date: day,
      clock_in: { [Op.is]: null },
    },
    attributes: ["user_id", "date"],
    limit: 500,
  });

  let sent = 0;
  for (const r of rows) {
    const userId = r.user_id;
    const url = `/attendance?date=${day}`;

    const already = await db.Notification.count({
      where: {
        user_id: userId,
        url,
        created: { [Op.gte]: startToday },
      },
    });
    if (already) continue;

    const res = await notify({
      userId,
      sender: "system",
      description: `Kamu belum clock-in sampai ${startHour}:${String(
        graceMin
      ).padStart(2, "0")}.`,
      url,
      payload: { type: "lateToWork", date: day },
    });
    if (!res?.skipped) sent++;
  }

  return { ok: true, total: rows.length, sent, cutoff: cutoff.toISOString() };
}

/** Agregator */
export async function scanAll() {
  const a = await scanTaskOverdue({});
  const b = await scanMemberOverdue({});
  const c = await scanOvertimeLimitDaily();
  const d = await scanLateToWork();
  return { taskOverdue: a, memberOverdue: b, overtimeLimitDaily: c, lateToWork: d };
}
