// src/components/task/subtask/assignment/ItemActionsBar.jsx
"use client";

import Image from "next/image";
import { Upload, Dropdown, Popconfirm, Tooltip, Button } from "antd";
import { asset } from "@/utils/url";

export default function ItemActionsBar({
    item,
    onUpload, // (fileInfo)
    onComment, // () => void
    onDelete, // () => void
}) {
    return (
        <>
            {/* Upload attachment (item-level) */}
            <Tooltip title="Attachment" placement="bottom" className="overlay-sub">
                <Upload
                    className="ms-auto"
                    showUploadList={false}
                    onChange={(fileInfo) => onUpload?.(fileInfo)}
                >
                    <button type="button" className="hover">
                        <Image
                            src={asset("static/images/icon/circle-attachment.png")}
                            width={100}
                            height={100}
                            className="w-7"
                            alt="attachment"
                        />
                    </button>
                </Upload>
            </Tooltip>

            {/* Toolbar item: Comment & Delete */}
            <Dropdown
                menu={{
                    items: [
                        {
                            key: "comment-item",
                            label: (
                                <button type="button" className="border-b text-left w-full" onClick={onComment}>
                                    Comment
                                </button>
                            ),
                        },
                        {
                            key: "delete",
                            label: (
                                <Popconfirm
                                    title="Delete the task item"
                                    description="Are you sure to delete this task item?"
                                    okText="Yes"
                                    cancelText="No"
                                    onConfirm={onDelete}
                                >
                                    <button type="button" className="text-red-500 text-left w-full">
                                        Delete
                                    </button>
                                </Popconfirm>
                            ),
                        },
                    ],
                }}
                trigger={["click"]}
                placement="bottomRight"
            >
                <button type="button" className="hover">
                    <Image
                        src={asset("static/images/icon/dot-3.png")}
                        width={100}
                        height={100}
                        className="w-6"
                        alt="more actions"
                    />
                </button>
            </Dropdown>
        </>
    );
}
