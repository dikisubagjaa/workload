"use client";
import { useState } from "react";
import { CheckOutlined } from "@ant-design/icons";
import { Button, Select, Table } from "antd";
import ModalRevise from "@/components/modal/ModalRevise";
import { useMobileQuery } from "../libs/UseMediaQuery";

import utc from "dayjs/plugin/utc";
import dayjs from "dayjs";
import relativeTime from "dayjs/plugin/relativeTime";

dayjs.extend(utc);
dayjs.extend(relativeTime);

// ===== Helpers =====
const toDayjsDate = (value) => {
  if (value == null) return null;
  if (typeof value === "number") {
    // 10 digit: seconds, 13 digit: milliseconds
    return value < 10_000_000_000 ? dayjs.unix(value) : dayjs(value);
  }
  return dayjs(value);
};

const colorMap = {
  black: "#000000",
  white: "#FFFFFF",
  red: "#EC221F",
  yellow: "#E8B931",
  green: "#14AE5C",
  purple: "#D42DA4",
};

const renderColorTodo = (dueDate) => {
  const d = toDayjsDate(dueDate);
  if (!d || !d.isValid()) return colorMap.black;

  const today = dayjs().startOf("day");
  const diffDays = d.startOf("day").diff(today, "day");

  if (diffDays < 0) return colorMap.red; // Overdue
  if (diffDays <= 3) return colorMap.yellow; // Critical
  return colorMap.green; // Safe
};

const toUnix = (v) => (typeof v === "number" ? v : Number(v));

const fmtDate = (unixSec) =>
  Number.isFinite(unixSec) ? dayjs.unix(unixSec).format("DD MMM YYYY") : "-";

/** Ambil tanggal submit ke client: pakai start_revision kalau ada, fallback ke start_date */
const getSubmittedDate = (record) => {
  const raw = record.start_revision ?? record.start_date;
  if (raw == null) return null;
  const unix = toUnix(raw);
  if (!Number.isFinite(unix)) return null;
  return dayjs.unix(unix);
};

const formatSubmittedDate = (record) => {
  const d = getSubmittedDate(record);
  if (!d) return "-";
  return d.format("DD MMM YYYY");
};

const formatDaysSinceSubmission = (record) => {
  const d = getSubmittedDate(record);
  if (!d) return "-";
  const today = dayjs().startOf("day");
  const diff = today.diff(d.startOf("day"), "day");
  const days = diff < 0 ? 0 : diff;
  return `${days} Days`;
};

// AE status options ↔ todo flags
const AE_STATUS_OPTIONS = [
  { value: "need_review_ae", label: "Under Review" },
  { value: "revise_account", label: "Revision" },
  { value: "completed", label: "Completed" },
];

// ===== Columns (desktop) =====
const columnsUnderReview = (onOpenRevise) => [
  {
    title: "Task Name",
    dataIndex: "name",
    key: "taskName",
    className: "h-full",
    render: (_value, record, index) => {
      const due = record.end_date;
      return (
        <div className="flex items-center gap-5" key={index}>
          <div
            className="w-2 rounded-full min-h-12"
            style={{ backgroundColor: renderColorTodo(due) }}
          />
          <div className="flex flex-col gap-2">
            <h3 className="text-sm font-medium text-[#383F50]">
              {record.title}
            </h3>
          </div>
        </div>
      );
    },
  },
  {
    title: "Version",
    dataIndex: "version",
    key: "version",
    render: (_value, record) => (
      <p className="text-sm text-[#383F50]">
        {record.last_version ?? record.version ?? "-"}
      </p>
    ),
  },
  {
    title: "Project Name",
    dataIndex: "projectClient",
    key: "projectClient",
    render: (_value, record) => (
      <p className="text-sm text-[#383F50]">
        {record.projectClient || record.project_name || "-"}
      </p>
    ),
  },
  {
    title: "Submitted Date",
    dataIndex: "submittedDate",
    key: "submittedDate",
    render: (_value, record) => (
      <p className="text-sm text-[#383F50]">{formatSubmittedDate(record)}</p>
    ),
  },
  {
    title: "Days Since Submission",
    dataIndex: "daysSinceSubmission",
    key: "daysSinceSubmission",
    render: (_value, record) => (
      <p className="text-sm text-[#383F50]">
        {formatDaysSinceSubmission(record)}
      </p>
    ),
  },
  {
    title: "Status",
    dataIndex: "status",
    key: "status",
    width: "15%",
    render: (_value, record) => {
      const currentTodo =
        record.todo || record.status || "need_review_ae"; // fallback

      const handleChange = (val) => {
        // Kalau pilih Revision → langsung buka modal revisi
        if (val === "revise_account") {
          onOpenRevise(record);
        }
        // Untuk sekarang, perubahan flag todo secara resmi
        // tetap ditangani oleh API di dalam ModalRevise / layer lain.
      };

      return (
        <div className="flex items-center gap-5">
          <Select
            className="text-gray-400 w-40"
            value={currentTodo}
            options={AE_STATUS_OPTIONS}
            onChange={handleChange}
          />
          <Button
            disabled={record.btnCheck}
            className="btn-blue px-2"
            size="small"
            onClick={() => onOpenRevise(record)}
          >
            <CheckOutlined />
          </Button>
        </div>
      );
    },
  },
];

// ===== Columns (mobile) – ringkas, detail di ExpandTable =====
const mobileColumnsUnderReview = (onOpenRevise) => [
  {
    title: "Task Name",
    dataIndex: "name",
    key: "taskName",
    className: "h-full",
    colSpan: 2,
    align: "left",
    render: (_value, record, index) => {
      const due = record.end_date;
      return (
        <div className="flex items-center gap-5" key={index}>
          <div
            className="w-2 rounded-full min-h-12"
            style={{ backgroundColor: renderColorTodo(due) }}
          />
          <div className="flex flex-col gap-2">
            <h3 className="text-sm font-medium text-[#383F50]">
              {record.title}
            </h3>
          </div>
        </div>
      );
    },
  },
];

const ExpandTable = ({ record, onOpenRevise }) => {
  const currentTodo =
    record.todo || record.status || "need_review_ae"; // fallback

  const handleChange = (val) => {
    if (val === "revise_account") {
      onOpenRevise(record);
    }
  };

  return (
    <ul className="flex flex-col gap-4">
      <li>
        <h3 className="text-sm font-semibold mb-2">Version</h3>
        <p className="text-sm text-[#383F50]">
          {record.last_version ?? record.version ?? "-"}
        </p>
      </li>
      <li>
        <h3 className="text-sm font-semibold mb-2">Project Name</h3>
        <p className="text-sm text-[#383F50]">
          {record.projectClient || record.project_name || "-"}
        </p>
      </li>
      <li>
        <h3 className="text-sm font-semibold mb-2">Submitted Date</h3>
        <p className="text-sm text-[#383F50]">
          {formatSubmittedDate(record)}
        </p>
      </li>
      <li>
        <h3 className="text-sm font-semibold mb-2">Days Since Submission</h3>
        <p className="text-sm text-[#383F50]">
          {formatDaysSinceSubmission(record)}
        </p>
      </li>
      <li>
        <h3 className="text-sm font-semibold mb-2">Status</h3>
        <div className="flex items-center gap-5">
          <Select
            className="text-gray-400 w-40"
            value={currentTodo}
            options={AE_STATUS_OPTIONS}
            onChange={handleChange}
          />
          <Button
            disabled={!record.btnCheck}
            className="btn-blue px-2"
            size="small"
            onClick={() => onOpenRevise(record)}
          >
            <CheckOutlined />
          </Button>
        </div>
      </li>
    </ul>
  );
};

export default function TableUnderReview({ dataTaskReview = [], fetchDashboard }) {
  const [modalRevise, setModalRevise] = useState(false);
  const [selectedRow, setSelectedRow] = useState(null);
  const isMobile = useMobileQuery();

  const onOpenRevise = (row) => {
    setSelectedRow(row);
    setModalRevise(true);
  };

  return (
    <>
      <Table
        dataSource={dataTaskReview}
        columns={
          isMobile
            ? mobileColumnsUnderReview(onOpenRevise)
            : columnsUnderReview(onOpenRevise)
        }
        scroll={isMobile ? null : { x: "max-content" }}
        pagination={false}
        expandable={
          isMobile
            ? {
              expandedRowRender: (record) => (
                <ExpandTable
                  record={record}
                  onOpenRevise={onOpenRevise}
                />
              ),
            }
            : null
        }
        rowKey={(r) => r.key || `${r.task_id}-${r.revision_id || ""}`}
      />

      <ModalRevise
        modalRevise={modalRevise}
        setModalRevise={setModalRevise}
        revisionTarget={selectedRow}
        fetchDashboard={fetchDashboard}
      />
    </>
  );
}
