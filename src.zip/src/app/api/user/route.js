// src/app/api/user/route.js
export const dynamic = "force-dynamic";
export const revalidate = 0;

import { NextResponse } from "next/server";
import db from "@/database/models";
import { withActive } from "@/utils/session";
import { getUnixTimestampUTC } from "@/utils/dateHelpers";

const { Sequelize, User, UserEmployment } = db;
const { Op } = Sequelize;

const nowUnix = () =>
  typeof getUnixTimestampUTC === "function"
    ? getUnixTimestampUTC()
    : Math.floor(Date.now() / 1000);

// -----------------------------
// Helpers
// -----------------------------
function parseIntParam(v, def) {
  const n = Number(v);
  return Number.isFinite(n) ? n : def;
}

function readParam(searchParams, snakeKey, camelKey) {
  return (
    (snakeKey ? searchParams.get(snakeKey) : null) ??
    (camelKey ? searchParams.get(camelKey) : null) ??
    ""
  );
}

function toEnumTrueFalse(v) {
  if (v === true || v === 1 || String(v) === "true") return "true";
  if (v === false || v === 0 || String(v) === "false") return "false";
  return null; // null = tidak dikirim / jangan overwrite default
}

function normalizeSalaryJson(v) {
  if (v == null) return null;
  if (typeof v === "string") return v;
  try {
    return JSON.stringify(v);
  } catch {
    return String(v);
  }
}

function parseOrder(sortBy, sortDir) {
  const allowed = new Set([
    "created",
    "updated",
    "fullname",
    "email",
    "phone",
    "user_type",
    "status",
    "user_role",
    "department_id",
    "is_hod",
    "join_date",
    "job_position",
  ]);

  const raw = String(sortBy || "").trim();
  const field = allowed.has(raw) ? raw : "created";
  const dir = String(sortDir || "").toLowerCase() === "asc" ? "ASC" : "DESC";
  return [[field, dir]];
}

function pickEmploymentDetails(body, type) {
  const contract_details = body?.contract_details ?? body?.contractDetails ?? null;
  const staff_details = body?.staff_details ?? body?.staffDetails ?? null;
  const probation_details = body?.probation_details ?? body?.probationDetails ?? null;

  const t = String(type || "staff").toLowerCase();
  if (t === "contract") return contract_details || {};
  if (t === "probation") return probation_details || {};
  return staff_details || {};
}

function buildEmploymentCreatePayload({ userId, sessionUserId, type, startDate, details }) {
  const t = String(type || "staff").toLowerCase();
  const base = {
    user_id: userId,
    type: t,
    start_date: startDate,
    end_date: null, // <-- aktif
    notes: details?.notes ?? null,
    created: nowUnix(),
    created_by: sessionUserId || null,
    updated: nowUnix(),
    deleted: null,
  };

  if (t === "contract") {
    return {
      ...base,
      contract_number: details?.contract_number ?? null,
      duration_months:
        details?.contract_duration_months != null
          ? Number(details.contract_duration_months)
          : null,
      salary_json: normalizeSalaryJson(details?.salary_details ?? null),
    };
  }

  if (t === "probation") {
    return {
      ...base,
      evaluation_notes: details?.evaluation_notes ?? null,
      recommended_status: details?.recommended_status ?? null,
    };
  }

  return base;
}

// -----------------------------
// GET /api/user
// -----------------------------
export const GET = withActive(async function GET_HANDLER(req) {
  try {
    const { searchParams } = new URL(req.url);

    const page = Math.max(1, parseIntParam(readParam(searchParams, "page"), 1));
    const limit = Math.min(100, Math.max(1, parseIntParam(readParam(searchParams, "limit"), 10)));
    const offset = (page - 1) * limit;

    const q = String(readParam(searchParams, "q")).trim();
    const status = String(readParam(searchParams, "status")).trim();
    const userType = String(readParam(searchParams, "user_type", "userType")).trim();

    const role = String(readParam(searchParams, "role")).trim(); // -> user_role
    const departmentId = String(readParam(searchParams, "department_id", "departmentId")).trim();
    const isHod = String(readParam(searchParams, "is_hod", "isHod")).trim(); // "true"/"false"

    const sortBy = String(readParam(searchParams, "sortBy")).trim();
    const sortDir = String(readParam(searchParams, "sortDir")).trim();
    const order = parseOrder(sortBy, sortDir);

    const where = {}; // defaultScope User sudah filter deleted/deleted_by

    if (q) {
      where[Op.or] = [
        { fullname: { [Op.like]: `%${q}%` } },
        { email: { [Op.like]: `%${q}%` } },
        { phone: { [Op.like]: `%${q}%` } },
      ];
    }
    if (status) where.status = status;
    if (userType) where.user_type = userType;
    if (role) where.user_role = role;
    if (departmentId) where.department_id = Number(departmentId);
    if (isHod === "true" || isHod === "false") where.is_hod = isHod;

    const { rows, count } = await User.findAndCountAll({
      where,
      limit,
      offset,
      order,
      attributes: { exclude: ["password"] },
    });

    return NextResponse.json(
      { ok: true, data: rows, meta: { page, limit, total: count } },
      { status: 200 }
    );
  } catch (error) {
    console.error("GET /api/user error:", error);
    return NextResponse.json(
      { error: error?.message || "Failed to fetch users." },
      { status: 500 }
    );
  }
});

// -----------------------------
// POST /api/user
// -----------------------------
export const POST = withActive(async function POST_HANDLER(req, { locals }) {
  const t = await db.sequelize.transaction();
  try {
    const sessionUserId = locals?.user?.user_id || null;
    const body = await req.json();

    // required
    const fullname = (body?.fullname || "").trim();
    const email = (body?.email || "").trim();
    const password = body?.password || "";
    const job_position = (body?.job_position ?? body?.jobPosition ?? "").trim();

    // optional
    const phone = (body?.phone ?? "").trim() || null;
    const user_role = body?.user_role ?? body?.userRole ?? null;
    const department_id = body?.department_id ?? body?.departmentId ?? null;
    const user_type = String(body?.user_type ?? body?.userType ?? "staff").toLowerCase();
    const status = String(body?.status ?? "new").toLowerCase();

    // join_date wajib untuk start_date employment (kalau kosong, pakai now)
    const join_date_raw = body?.join_date ?? body?.joinDate ?? null;
    const join_date =
      join_date_raw != null && join_date_raw !== "" ? Number(join_date_raw) : nowUnix();

    // enums/flags tambahan (optional)
    const attendance_type = body?.attendance_type ?? body?.attendanceType ?? null;
    const absent_type = body?.absent_type ?? body?.absentType ?? null;

    const is_timesheet = toEnumTrueFalse(body?.is_timesheet ?? body?.isTimesheet);
    const is_hod = toEnumTrueFalse(body?.is_hod ?? body?.isHod);
    const is_hrd = toEnumTrueFalse(body?.is_hrd ?? body?.isHrd);
    const is_operational_director = toEnumTrueFalse(
      body?.is_operational_director ?? body?.isOperationalDirector
    );
    const is_superadmin = toEnumTrueFalse(body?.is_superadmin ?? body?.isSuperadmin);
    const is_ae = toEnumTrueFalse(body?.is_ae ?? body?.isAe);

    if (!fullname || !email) {
      await t.rollback();
      return NextResponse.json({ error: "fullname and email are required." }, { status: 400 });
    }
    if (!job_position) {
      await t.rollback();
      return NextResponse.json({ error: "job_position is required." }, { status: 400 });
    }
    if (!password || String(password).length < 6) {
      await t.rollback();
      return NextResponse.json(
        { error: "password is required (min 6 characters)." },
        { status: 400 }
      );
    }

    const bcrypt = (await import("bcryptjs")).default;
    const hashed = await bcrypt.hash(String(password), 10);

    const createPayload = {
      fullname,
      email,
      password: hashed,
      phone,
      job_position: job_position || null,
      user_role,
      department_id: department_id != null && department_id !== "" ? Number(department_id) : null,
      user_type: user_type || "staff",
      status: status || "new",
      join_date,

      created: nowUnix(),
      created_by: sessionUserId,
      updated: nowUnix(),
      updated_by: null,
      deleted: null,
      deleted_by: null,
    };

    if (attendance_type) createPayload.attendance_type = attendance_type;
    if (absent_type) createPayload.absent_type = absent_type;

    if (is_timesheet != null) createPayload.is_timesheet = is_timesheet;
    if (is_hod != null) createPayload.is_hod = is_hod;
    if (is_hrd != null) createPayload.is_hrd = is_hrd;
    if (is_operational_director != null)
      createPayload.is_operational_director = is_operational_director;
    if (is_superadmin != null) createPayload.is_superadmin = is_superadmin;
    if (is_ae != null) createPayload.is_ae = is_ae;

    const newUser = await User.create(createPayload, { transaction: t });

    // create first employment phase: start_date = join_date, end_date = null
    const details = pickEmploymentDetails(body, user_type);
    const empPayload = buildEmploymentCreatePayload({
      userId: newUser.user_id,
      sessionUserId,
      type: user_type,
      startDate: join_date,
      details,
    });

    await UserEmployment.create(empPayload, { transaction: t });

    await t.commit();

    const userJson = newUser.toJSON();
    delete userJson.password;

    return NextResponse.json(
      { ok: true, message: "User created successfully!", user: userJson },
      { status: 201 }
    );
  } catch (error) {
    if (t.finished !== "commit") await t.rollback();
    console.error("POST /api/user error:", error);

    if (error?.name === "SequelizeUniqueConstraintError") {
      return NextResponse.json({ error: "User with this email already exists." }, { status: 409 });
    }
    return NextResponse.json({ error: error?.message || "Failed to create user." }, { status: 500 });
  }
});
