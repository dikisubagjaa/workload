import { Project, sequelize } from "@/database/models/website";
import { getUnixTimestampUTC } from "@/utils/dateHelpers";
import { withAuth } from "@/utils/session";

export async function GET(_, { params }) {
    try {
        await sequelize.sync();
        const project = await Project.findByPk(params.id);
        if (!project) {
            return Response.json({ message: 'Not found' }, { status: 404 });
        }
        return Response.json(project);
    } catch (error) {
        console.error('❌ GET /project/:id error:', error);
        return new Response(
            JSON.stringify({ message: 'Failed to get project', error: error.message }),
            { status: 500 }
        );
    }
}

export const PUT = withAuth(async function PUT_HANDLER(req, { params }, currentUser) {
    try {
        await sequelize.sync();
        const body = await req.json();
        const project = await Project.findByPk(params.id);
        if (!project) {
            return Response.json({ message: 'Not found' }, { status: 404 });
        }
        
        const nowUnix = getUnixTimestampUTC();
        await project.update({
            ...body,
            updated: nowUnix,
            updated_by: currentUser.user_id
        });

        return Response.json({ message: 'Updated' });
    } catch (error) {
        console.error('❌ PUT /project/:id error:', error);
        return new Response(
            JSON.stringify({ message: 'Failed to update project', error: error.message }),
            { status: 500 }
        );
    }
});

export const DELETE = withAuth(async function DELETE_HANDLER(req, { params }, currentUser) {
    try {
        await sequelize.sync();

        const project = await Project.findByPk(params.id);
        if (!project) {
            return Response.json({ message: 'Not found' }, { status: 404 });
        }

        const nowUnix = getUnixTimestampUTC();
        await Project.update(
            {
                deleted: nowUnix,
                deleted_by: currentUser.user_id
            },
            { where: { project_id: params.id } }
        );

        return Response.json({ message: 'Soft deleted' });
    } catch (error) {
        console.error('❌ DELETE /project/:id error:', error);
        return new Response(
            JSON.stringify({ message: 'Failed to delete project', error: error.message }),
            { status: 500 }
        );
    }
});

