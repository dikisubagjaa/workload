// src/app/api/file/route.js
export const dynamic = "force-dynamic";
export const revalidate = 0;

import { NextResponse } from "next/server";
import fsMod from "fs";
const fs = fsMod.promises;
import path from "path";
import crypto from "crypto";

/**
 * Konfigurasi dasar storage
 * - STORAGE_DIR bisa dioverride lewat env, default 'storage' di project root
 */
const RAW_STORAGE_DIR = process.env.STORAGE_DIR || "storage";
const STORAGE_DIR = path.isAbsolute(RAW_STORAGE_DIR)
  ? RAW_STORAGE_DIR
  : path.resolve(process.cwd(), RAW_STORAGE_DIR);

/** 1x1 PNG transparan buat fallback */
const EMPTY_PNG_BASE64 =
  "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR4nGNgYAAAAAMAAWgmWQ0AAAAASUVORK5CYII=";

function placeholderResponse() {
  const buf = Buffer.from(EMPTY_PNG_BASE64, "base64");
  const headers = new Headers();
  headers.set("Content-Type", "image/png");
  headers.set("Content-Length", String(buf.length));
  headers.set("Cache-Control", "public, max-age=60");
  return new NextResponse(buf, { status: 200, headers });
}

/** Peta ekstensi → mime-type (cukup untuk image umum) */
function extToMime(ext) {
  switch (ext.toLowerCase()) {
    case ".jpg":
    case ".jpeg":
      return "image/jpeg";
    case ".png":
      return "image/png";
    case ".gif":
      return "image/gif";
    case ".webp":
      return "image/webp";
    case ".svg":
      return "image/svg+xml";
    case ".avif":
      return "image/avif";
    case ".bmp":
      return "image/bmp";
    default:
      return "application/octet-stream";
  }
}

/** Sanitizer sederhana untuk nama file/folder agar tidak bisa path traversal */
function sanitize(p) {
  // hilangkan backslash windows dan normalisasi
  const norm = path.posix.normalize(String(p || "").replace(/\\/g, "/"));
  // larang keluar dari root (..), dan larang absolute
  if (norm.startsWith("..") || path.isAbsolute(norm)) return null;
  // larang segmen berbahaya
  if (norm.includes("\0")) return null;
  return norm;
}

/** Baca file sebagai Buffer + stat; lempar error jika tidak ada */
async function readFileWithStat(absPath) {
  const stat = await fs.stat(absPath);
  if (!stat.isFile()) throw new Error("Not a file");
  const data = await fs.readFile(absPath);
  return { data, stat };
}

/** Bangun ETag dari ukuran + mtime */
function makeETag(stat) {
  const mtime = stat.mtimeMs?.toString() || "";
  const size = stat.size?.toString() || "";
  const hash = crypto
    .createHash("sha1")
    .update(size + ":" + mtime)
    .digest("hex")
    .slice(0, 16);
  return `"w-${hash}"`;
}

/** Core handler GET */
export async function GET(req) {
  try {
    // 🔥 PENTING: jangan langsung akses req.url
    // Gunakan nextUrl kalau tersedia, baru fallback ke new URL(req.url)
    const urlObj = "nextUrl" in req ? req.nextUrl : new URL(req.url);
    const searchParams = urlObj.searchParams;

    const folder = sanitize(searchParams.get("folder") || "");
    const file = sanitize(searchParams.get("file") || "");
    const explicitSize = searchParams.get("size"); // e.g. 'sm'
    const wantResized =
      searchParams.has("resized") || explicitSize === "sm";
    const asDownload = searchParams.get("download") === "1";

    // kalau parameter kurang → sekarang balikin placeholder aja
    if (!folder || !file) {
      return placeholderResponse();
    }

    // Root absolut untuk folder ini, pastikan tetap di bawah STORAGE_DIR
    const folderAbs = path.resolve(STORAGE_DIR, folder);
    if (!folderAbs.startsWith(STORAGE_DIR)) {
      // sebelumnya 400, sekarang tetap placeholder biar <Image> gak error
      return placeholderResponse();
    }

    // Pecah nama file
    const base = path.posix.basename(file); // cegah subpath di "file"
    const origAbsPath = path.resolve(folderAbs, base);

    // Jika minta resized → arahkan ke subfolder "resized" + paksa .webp
    // contoh: storage/<folder>/resized/<nama-ori>.webp
    const resizedName = base.replace(/\.[^.]+$/, ".webp");
    const resizedAbsPath = path.resolve(folderAbs, "resized", resizedName);

    // Kandidat path berurutan:
    // 1) resized (kalau diminta)
    // 2) original
    const candidates = wantResized
      ? [resizedAbsPath, origAbsPath]
      : [origAbsPath];

    let chosen = null;
    let payload = null;
    let stat = null;

    for (const p of candidates) {
      try {
        const res = await readFileWithStat(p);
        chosen = p;
        payload = res.data;
        stat = res.stat;
        break;
      } catch {
        // lanjut ke kandidat berikutnya
      }
    }

    // kalau dua-duanya gak ketemu → jangan error, kirim placeholder
    if (!chosen || !payload || !stat) {
      return placeholderResponse();
    }

    // Tentukan mime dari file terpilih
    const mime = extToMime(path.extname(chosen));

    // ETag & cache headers (cache panjang untuk file statik)
    const etag = makeETag(stat);
    const ifNoneMatch = req.headers.get("if-none-match") || "";
    if (ifNoneMatch.replace(/-gzip$/, "") === etag) {
      const notModified = new NextResponse(null, { status: 304 });
      notModified.headers.set("ETag", etag);
      notModified.headers.set(
        "Cache-Control",
        "public, max-age=31536000, immutable"
      );
      notModified.headers.set("Last-Modified", stat.mtime.toUTCString());
      return notModified;
    }

    const headers = new Headers();
    headers.set("Content-Type", mime);
    headers.set("Content-Length", String(payload.length));
    headers.set("ETag", etag);
    headers.set("Last-Modified", stat.mtime.toUTCString());
    headers.set("Cache-Control", "public, max-age=31536000, immutable"); // 1 tahun

    if (asDownload) {
      headers.set(
        "Content-Disposition",
        `attachment; filename*=UTF-8''${encodeURIComponent(
          path.basename(chosen)
        )}`
      );
    } else {
      headers.set(
        "Content-Disposition",
        `inline; filename*=UTF-8''${encodeURIComponent(
          path.basename(chosen)
        )}`
      );
    }

    return new NextResponse(payload, { status: 200, headers });
  } catch (err) {
    console.error("[api/file] error:", err?.message || err);
    // kalau ada error pun, tetap kirim placeholder biar Next Image gak merah
    return placeholderResponse();
  }
}

// (Opsional) dukung HEAD agar cepat untuk preflight/cek ada tidaknya file
export async function HEAD(req) {
  const res = await GET(req);
  return new NextResponse(null, {
    status: res.status,
    headers: res.headers,
  });
}
