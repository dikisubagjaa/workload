export const dynamic = 'force-dynamic';
export const revalidate = 0;

import { NextResponse } from "next/server";
import db from "@/database/models";
import { withAuth } from "@/utils/session";
import { getUnixTimestampUTC } from "@/utils/dateHelpers";

const { Task } = db;

// DELETE /api/task/:taskId/department/:departmentId
export const DELETE = withAuth(async function DELETE_HANDLER(req, { params }, currentUser) {
  try {
    const { taskId, departmentId } = params;

    const task = await Task.findOne({ where: { task_id: taskId } });
    if (!task) {
      return NextResponse.json({ error: "Task tidak ditemukan" }, { status: 404 });
    }

    const depId = Number(departmentId);
    if (!Number.isInteger(depId)) {
      return NextResponse.json({ error: "Invalid department_id" }, { status: 400 });
    }

    const current = Array.isArray(task.department) ? task.department : [];
    const next = current.filter(d => Number(d?.department_id) !== depId);

    // Kalau tidak ada perubahan, balikin apa adanya (id tidak ditemukan di list)
    if (next.length === current.length) {
      return NextResponse.json({ message: "Tidak ada perubahan", task }, { status: 200 });
    }

    await Task.update(
      {
        department: next,
        updated: getUnixTimestampUTC(),
        updated_by: currentUser.user_id,
      },
      { where: { task_id: taskId } }
    );

    const updatedTask = await Task.findOne({ where: { task_id: taskId } });
    return NextResponse.json(
      { message: "Department dihapus dari task", task: updatedTask },
      { status: 200 }
    );
  } catch (error) {
    console.error("Error deleting department from task:", error);
    return NextResponse.json({ error: error.message || "Internal Server Error" }, { status: 500 });
  }
});
