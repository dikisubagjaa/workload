// src/app/api/holiday/route.js
export const dynamic = "force-dynamic";
export const revalidate = 0;

import { NextResponse } from "next/server";
import db from "@/database/models";
import dayjs from "dayjs";
import utc from "dayjs/plugin/utc";
import { withAuth } from "@/utils/session";

dayjs.extend(utc);

const { Holiday, Sequelize } = db;
const { Op } = Sequelize || {};
const nowUnix = () => dayjs().utc().unix();

const ALLOWED_TYPES = new Set(["holiday", "leave"]);

// optional: FE bisa kirim holidayType (camelCase) biar labelnya enak
const HOLIDAY_TYPE_TO_TYPE = {
  public_holiday: "holiday", // tanggal merah
  joint_leave: "leave",      // cuti bersama
  tanggal_merah: "holiday",
  tgl_merah: "holiday",
  cuti_bersama: "leave",
};

function deriveHolidayTypeFromType(type) {
  return type === "leave" ? "joint_leave" : "public_holiday";
}

function normalizeTypeInput(typeRaw, holidayTypeRaw) {
  const type = typeRaw != null ? String(typeRaw).toLowerCase().trim() : "";
  const holidayType = holidayTypeRaw != null ? String(holidayTypeRaw).toLowerCase().trim() : "";

  // kalau holidayType ada → override type
  if (holidayType) {
    const mapped = HOLIDAY_TYPE_TO_TYPE[holidayType];
    if (!mapped) return { ok: false, error: "Invalid holidayType." };
    return { ok: true, type: mapped, holidayType: holidayType === "leave" ? "joint_leave" : holidayType };
  }

  // fallback type lama
  const finalType = type || "holiday";
  if (!ALLOWED_TYPES.has(finalType)) {
    return { ok: false, error: "Field 'type' must be 'holiday' or 'leave'." };
  }
  return { ok: true, type: finalType, holidayType: deriveHolidayTypeFromType(finalType) };
}

/**
 * GET /api/holiday
 * Optional query:
 *   - ?year=2025
 *   - ?type=holiday|leave
 *   - ?holidayType=public_holiday|joint_leave   (opsional)
 *   - ?holiday_type=public_holiday|joint_leave  (opsional)
 */
export const GET = withAuth(async function GET_HANDLER(req, _ctx, _currentUser) {
  try {
    const { searchParams } = new URL(req.url);
    const yearParam = searchParams.get("year");

    const typeParamRaw = searchParams.get("type");
    const holidayTypeParamRaw =
      searchParams.get("holidayType") || searchParams.get("holiday_type");

    const parsed = normalizeTypeInput(typeParamRaw, holidayTypeParamRaw);

    const where = {};

    if (yearParam) {
      const y = Number(yearParam);
      if (!Number.isNaN(y) && Op?.between) {
        const from = `${y}-01-01`;
        const to = `${y}-12-31`;
        where.date = { [Op.between]: [from, to] };
      }
    }

    // filter type hanya kalau query diberikan
    if (typeParamRaw || holidayTypeParamRaw) {
      if (!parsed.ok) {
        return NextResponse.json({ error: parsed.error }, { status: 400 });
      }
      where.type = parsed.type;
    }

    const rows = await Holiday.findAll({
      where: Object.keys(where).length ? where : undefined,
      order: [
        ["date", "ASC"],
        ["holiday_id", "ASC"],
      ],
    });

    const payload = rows.map((h) => {
      const obj = h.toJSON();
      // tambahin helper untuk UI (tanpa nambah kolom DB)
      obj.holidayType = deriveHolidayTypeFromType(obj.type);
      return obj;
    });

    return NextResponse.json({ holidays: payload }, { status: 200 });
  } catch (error) {
    console.error("Error fetching holidays:", error);
    return NextResponse.json(
      { error: error.message || "Failed to fetch holidays." },
      { status: 500 }
    );
  }
});

/**
 * POST /api/holiday
 * Body (JSON) support:
 *  A) lama:
 *    { "type":"holiday"|"leave", "date":"YYYY-MM-DD", "description":"..." }
 *  B) baru (opsional):
 *    { "holidayType":"public_holiday"|"joint_leave", "date":"YYYY-MM-DD", "description":"..." }
 */
export const POST = withAuth(async function POST_HANDLER(req, _ctx, currentUser) {
  try {
    const body = await req.json().catch(() => ({}));

    const parsed = normalizeTypeInput(body?.type, body?.holidayType || body?.holiday_type);
    if (!parsed.ok) {
      return NextResponse.json({ error: parsed.error }, { status: 400 });
    }

    const rawDate = body?.date;
    const rawDesc = body?.description;

    const date =
      rawDate != null && String(rawDate).trim() !== ""
        ? String(rawDate).trim().slice(0, 10)
        : "";

    const description = rawDesc != null ? String(rawDesc).trim() : "";

    if (!date) {
      return NextResponse.json(
        { error: "Field 'date' is required (YYYY-MM-DD)." },
        { status: 400 }
      );
    }

    if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) {
      return NextResponse.json(
        { error: "Field 'date' must be in format YYYY-MM-DD." },
        { status: 400 }
      );
    }

    if (!description) {
      return NextResponse.json({ error: "Field 'description' is required." }, { status: 400 });
    }

    if (description.length > 120) {
      return NextResponse.json(
        { error: "Field 'description' must not exceed 120 characters." },
        { status: 400 }
      );
    }

    const userId = currentUser?.user_id ?? currentUser?.id ?? null;
    if (!userId) {
      return NextResponse.json(
        { error: "Invalid current user (missing user_id)." },
        { status: 500 }
      );
    }

    // cegah tanggal dobel
    const existing = await Holiday.findOne({ where: { date } });
    if (existing) {
      return NextResponse.json({ error: "Holiday for this date already exists." }, { status: 400 });
    }

    const now = nowUnix();

    const newHoliday = await Holiday.create({
      type: parsed.type, // holiday => tanggal merah, leave => cuti bersama
      date,
      description,
      created: now,
      created_by: userId,
      updated: now,
      updated_by: userId,
    });

    const out = newHoliday.toJSON();
    out.holidayType = deriveHolidayTypeFromType(out.type);

    return NextResponse.json(
      { message: "Holiday created", holiday: out },
      { status: 201 }
    );
  } catch (error) {
    console.error("Error creating holiday:", error);
    return NextResponse.json(
      { error: error.message || "Failed to create holiday." },
      { status: 500 }
    );
  }
});
