export const dynamic = 'force-dynamic';
export const revalidate = 0;

import { NextResponse } from 'next/server';
import db from "@/database/models";
import { withAuth } from "@/utils/session";
import dayjs from 'dayjs';

const { Project } = db;

export const POST = withAuth(async function POST_HANDLER(req, context, currentUser) {
    try {
        const body = await req.json().catch(() => ({}));
        const nowUnix = dayjs().unix();

        const newProject = await Project.create({
            published: 'drafted',
            type: 'project',
            client_id: body.client_id || null,
            created: nowUnix,
            updated: nowUnix,
            created_by: currentUser.user_id,
            updated_by: currentUser.user_id,
        });

        return NextResponse.json({
            message: "Draft project created successfully",
            data: newProject
        }, { status: 201 });

    } catch (error) {
        console.error("Error initializing project:", error);
        return NextResponse.json({ error: "Failed to initialize project." }, { status: 500 });
    }
});