// /src/app/api/timesheet/confirm/route.js
export const dynamic = 'force-dynamic';
export const revalidate = 0;

import { NextResponse } from 'next/server';
import db from "@/database/models";
import { withActive } from "@/utils/session";

const { Timesheet } = db;

export const POST = withActive(async function POST_HANDLER(req, context, currentUser) {
    try {
        const body = await req.json();
        const { date } = body; // 'YYYY-MM-DD'

        if (!date) {
            console.log("date",date);
            // kalau gak ada tanggal, balik lagi aja ke dashboard
            return NextResponse.json({ error: "Date is required." }, { status: 400 });
        }

        // set SEMUA timesheet user di tanggal itu jadi approved
        await Timesheet.update(
            { status: 'approved' },
            {
                where: {
                    user_id: currentUser.user_id,
                    date: date,
                },
            }
        );

        // setelah sukses, langsung redirect ke dashboard
        return NextResponse.json(
        {
            message: "Timesheet confirmed.",
            date,
        },
        { status: 200 }
        );
    } catch (error) {
        console.error("Error confirming timesheet:", error);
        // kalau gagal, tetap arahkan ke dashboard biar user gak ke-lock di halaman kosong
        return NextResponse.redirect(new URL('/dashboard', req.url));
    }
});
