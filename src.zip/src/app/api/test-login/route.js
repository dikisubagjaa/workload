// src/app/api/test-login/route.js
import { NextResponse } from "next/server";
import { encode } from "next-auth/jwt";
import db from "@/database/models";

const { User, Role, Menu } = db;

/* ========= helper yang SAMA dengan di [...nextauth] ========= */

function parseAccessList(src) {
  let arr = [];
  if (Array.isArray(src)) arr = src;
  else if (typeof src === "string") {
    const s = src.trim();
    if (!s || s.toLowerCase() === "null" || s.toLowerCase() === "undefined") arr = [];
    else if (
      (s.startsWith("[") && s.endsWith("]")) ||
      (s.startsWith("{") && s.endsWith("}"))
    ) {
      try {
        const p = JSON.parse(s);
        arr = Array.isArray(p) ? p : [];
      } catch {
        arr = s.split(",");
      }
    } else arr = s.split(",");
  }
  arr = arr
    .map((v) => (typeof v === "string" ? v.trim() : v))
    .filter(Boolean);

  const idSet = new Set(
    arr
      .map((v) =>
        typeof v === "string" && /^[0-9]+$/.test(v) ? Number(v) : v
      )
      .filter((v) => typeof v === "number")
  );
  const pathSet = new Set(
    arr
      .map((v) => (typeof v === "number" ? "" : String(v)))
      .map((s) => s.trim().toLowerCase())
      .filter((s) => !!s && !/^[0-9]+$/.test(s))
  );
  return { idSet, pathSet };
}

function isAllowed(row, idSet, pathSet) {
  const byId = idSet.has(row.menu_id);
  const byPath = row.path && pathSet.has(String(row.path).toLowerCase());
  return byId || byPath;
}

function buildMenuTree(menuRows, allowedFn = () => true) {
  const nodesById = new Map();

  // 1) Normalisasi node
  for (const row of menuRows) {
    nodesById.set(row.menu_id, {
      id: row.menu_id,
      parentId: row.parent_id ?? null,
      order: row.ordered ?? 0,
      key: row.path || String(row.menu_id),
      path: row.path || null,
      label: row.title || "",
      icon: row.icon || null,
      isShow: row.is_show,
      allowed: !!allowedFn(row),
      children: [],
    });
  }

  // 2) Link parent-child
  const roots = [];
  for (const node of nodesById.values()) {
    if (node.parentId && nodesById.has(node.parentId)) {
      nodesById.get(node.parentId).children.push(node);
    } else {
      roots.push(node);
    }
  }

  // 3) Sort
  const sortByOrder = (a, b) => (a.order || 0) - (b.order || 0);
  function sortTree(n, depth = 0) {
    if (depth > 50) return;
    n.children.sort(sortByOrder);
    n.children.forEach((c) => sortTree(c, depth + 1));
  }
  roots.sort(sortByOrder);
  roots.forEach((n) => sortTree(n));

  // 4) Prune
  function prune(n) {
    const keptChildren = n.children.map(prune).filter(Boolean);
    const keepThis = n.allowed || keptChildren.length > 0;
    if (!keepThis) return null;
    const out = {
      key: n.key,
      path: n.path,
      label: n.label,
      icon: n.icon,
      isShow: n.isShow,
    };
    if (keptChildren.length) out.children = keptChildren;
    return out;
  }

  return roots.map(prune).filter(Boolean);
}

/* ================== POST /api/test-login ================== */

export async function POST(request) {
  try {
    const allowTestLogin =
      process.env.NODE_ENV !== "production" ||
      process.env.ENABLE_TEST_LOGIN === "true";

    if (!allowTestLogin) {
      return NextResponse.json(
        { success: false, message: "Test login disabled" },
        { status: 403 }
      );
    }

    const body = await request.json().catch(() => ({}));
    const email = (body.email || "").trim();

    if (!email) {
      return NextResponse.json(
        { success: false, message: "Email is required" },
        { status: 400 }
      );
    }

    // ===== ambil user dari DB persis seperti jwt callback =====
    const dbUser = await User.findOne({ where: { email }, raw: true });
    if (!dbUser) {
      return NextResponse.json(
        { success: false, message: "User not found in DB" },
        { status: 404 }
      );
    }

    // ---- Siapkan whitelist: user.menu_access → (fallback) role.menu_access
    let { idSet, pathSet } = parseAccessList(dbUser.menu_access);
    if (idSet.size === 0 && pathSet.size === 0 && dbUser.user_role) {
      const roleRow = await Role.findOne({
        where: { slug: dbUser.user_role },
        attributes: ["menu_access"],
        raw: true,
      });
      const parsed = parseAccessList(roleRow?.menu_access);
      idSet = parsed.idSet;
      pathSet = parsed.pathSet;
    }

    const allowedFn = (row) => isAllowed(row, idSet, pathSet);

    // ---- Ambil semua menu aktif (sama kayak jwt callback)
    const allMenuRows = await Menu.findAll({
      where: { is_active: "true" },
      attributes: [
        "menu_id",
        "title",
        "path",
        "icon",
        "ordered",
        "is_show",
        "type",
        "parent_id",
      ],
      order: [["ordered", "ASC"]],
      raw: true,
    });

    const pageRows = allMenuRows.filter((r) => r.type === "page");
    const dashboardRows = allMenuRows.filter((r) => r.type === "dashboard");
    const buttonRows = allMenuRows.filter((r) => r.type === "button");

    const pages = buildMenuTree(pageRows, allowedFn);

    const dashboardKeys = dashboardRows
      .filter(allowedFn)
      .sort((a, b) => (a.ordered || 0) - (b.ordered || 0))
      .map((r) => r.path || String(r.menu_id));

    const buttons = buttonRows
      .filter(allowedFn)
      .sort((a, b) => (a.ordered || 0) - (b.ordered || 0))
      .map((r) => ({
        key: r.path || String(r.menu_id),
        path: r.path || null,
        label: r.title || "",
        icon: r.icon || null,
        isShow: r.is_show,
      }));

    const menu = { pages, dashboardKeys, buttons };

    // ===== Bangun token persis seperti di callbacks.jwt (SETELAH diproses) =====
    const token = {
      // base NextAuth fields
      sub: String(dbUser.user_id),
      email: dbUser.email,
      name: dbUser.fullname,
      picture: dbUser.profile_pic || null,

      // field yang diisi di jwt callback
      user_id: dbUser.user_id,
      uuid: dbUser.uuid || null,
      fullname: dbUser.fullname,
      user_role: dbUser.user_role || null,
      profile_pic: dbUser.profile_pic || null,
      department_id: dbUser.department_id || null,
      is_hod: dbUser.is_hod ?? null,
      is_ae: dbUser.is_ae ?? null,
      is_superadmin: dbUser.is_superadmin ?? null,
      is_operational_director: dbUser.is_operational_director ?? null,
      status: dbUser.status ?? null,
      attendance_type: dbUser.attendance_type ?? null,

      menu,
    };

    const secret = process.env.NEXTAUTH_SECRET;
    if (!secret) {
      return NextResponse.json(
        { success: false, message: "Missing NEXTAUTH_SECRET" },
        { status: 500 }
      );
    }

    const jwt = await encode({
      token,
      secret,
    });

    const cookieName =
      process.env.NODE_ENV === "production"
        ? "__Secure-next-auth.session-token"
        : "next-auth.session-token";

    const maxAge = 60 * 60 * 24 * 30; // 30 hari

    const res = NextResponse.json({ success: true });

    res.headers.append(
      "Set-Cookie",
      `${cookieName}=${jwt}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${maxAge}`
    );

    return res;
  } catch (err) {
    console.error("Test login error:", err);
    return NextResponse.json(
      { success: false, message: "Internal server error" },
      { status: 500 }
    );
  }
}
