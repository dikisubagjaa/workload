export const dynamic = 'force-dynamic';
export const revalidate = 0;

import { NextResponse } from 'next/server';
import db from "@/database/models";
import { withAuth } from "@/utils/session";
import dayjs from 'dayjs';
import { writeFile } from 'fs/promises';
import path from 'path';
import fs from 'fs';

const { ProjectPurchaseOrder, ProjectQuotation } = db;

// app/api/project/[projectId]/quotation/[pqId]/po/route.js

export async function GET(req, { params }) {
    try {
        // 1. Ambil parameter 'qtId' dari URL. Nama ini harus cocok dengan nama folder dinamis '[qtId]'.
        const { qtId } = params;

        // 2. Lakukan validasi sederhana untuk memastikan qtId ada.
        if (!qtId || qtId === 'undefined') {
            return NextResponse.json({ error: "Quotation ID is required." }, { status: 400 });
        }

        // 3. Langsung cari semua Purchase Orders berdasarkan 'pq_id' (foreign key).
        const poDocs = await ProjectPurchaseOrder.findAll({
            where: { pq_id: qtId }
        });

        return NextResponse.json({ poDoc: poDocs }, { status: 200 });

    } catch (error) {
        console.error("Error fetching Purchase Orders:", error);
        return NextResponse.json({
            error: error.message || "Failed to fetch PO documents"
        }, { status: 500 });
    }
}

/**
 * Helper function to save an uploaded file.
 * Save to: storage/project/po/<filename>
 * Return: stored filename only (basename), NOT "/uploads/..."
 */
async function saveFile(file) {
    const bytes = await file.arrayBuffer();
    const buffer = Buffer.from(bytes);
    const fileExtension = path.extname(file.name || "");
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    const newFilename = `${uniqueSuffix}${fileExtension}`;

    const uploadDir = path.join(process.cwd(), 'storage', 'project', 'po');
    const filePath = path.join(uploadDir, newFilename);

    if (!fs.existsSync(uploadDir)) {
        fs.mkdirSync(uploadDir, { recursive: true });
    }

    await writeFile(filePath, buffer);
    return newFilename; // ✅ basename only
}

/**
 * POST handler to upload a new PO document for an existing quotation.
 */
export const POST = withAuth(async function POST_HANDLER(req, { params }, currentUser) {
    const { qtId } = params; // Mengambil ID kutipan (pq_id) dari URL

    try {
        const formData = await req.formData();
        const poFile = formData.get('po_file');
        const poNumber = formData.get('po_number');

        if (!poFile || !poNumber) {
            return NextResponse.json({ status: 'error', message: 'PO file and PO number are required.' }, { status: 400 });
        }

        // Simpan file PO (basename only)
        const storedFilename = await saveFile(poFile);

        const nowUnix = dayjs().unix();

        // Buat record baru di tabel project_purchase_order
        const newPO = await ProjectPurchaseOrder.create({
            pq_id: qtId, // Menghubungkan PO ke kutipan yang benar
            po_number: poNumber,
            po_doc: storedFilename, // ✅ basename only
            created: nowUnix,
            created_by: currentUser.user_id,
            updated: nowUnix,
            updated_by: currentUser.user_id,
        });

        return NextResponse.json({
            status: 'success',
            message: 'PO document uploaded and linked successfully!',
            data: newPO
        }, { status: 201 });

    } catch (error) {
        console.error("Error uploading PO document:", error);
        // Menangani error jika qtId tidak valid (foreign key constraint)
        if (error.name === 'SequelizeForeignKeyConstraintError') {
            return NextResponse.json({ status: 'error', message: 'Quotation not found for the provided ID.' }, { status: 404 });
        }
        return NextResponse.json({ status: 'error', message: "Failed to upload PO document." }, { status: 500 });
    }
});
