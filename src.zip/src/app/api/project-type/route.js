export const dynamic = 'force-dynamic';
export const revalidate = 0;

import { NextResponse } from "next/server";
import db from "@/database/models"; // Menggunakan db object utama
import { withActive } from "@/utils/session"; // Mengimpor withActive untuk autentikasi
import dayjs from "dayjs"; // Import dayjs untuk Unix timestamp

const { ProjectType } = db; // Destructuring model dari db

// GET Handler
export const GET = withActive(async function GET_HANDLER(req) {
    try {
        const projectTypes = await ProjectType.findAll({ where: { deleted: null } });
        return NextResponse.json({ projectType: projectTypes }, { status: 200 });
    } catch (error) {
        console.error("Error fetching Project Types:", error);
        return NextResponse.json({ error: "Failed to fetch data" }, { status: 500 });
    }
});

// POST Handler yang Diperbaiki
export const POST = withActive(async function POST_HANDLER(req, context, currentUser) {
    try {
        const body = await req.json();

        // 1. Validasi input
        if (!body.title || body.title.trim() === '') {
            return NextResponse.json({ error: "Title is required." }, { status: 400 });
        }

        const nowUnix = dayjs().unix(); // Dapatkan Unix timestamp saat ini

        // 2. Simpan data ke database menggunakan Unix timestamp
        const newProjectType = await ProjectType.create({
            title: body.title,
            created: nowUnix,
            created_by: currentUser.user_id, // Menggunakan ID dari user yang login
            updated: nowUnix,
            updated_by: currentUser.user_id, // Menggunakan ID dari user yang login
        });

        // 3. Mengembalikan respons dengan status 201 (Created)
        return NextResponse.json({ message: "Project Type added successfully", projectType: newProjectType }, { status: 201 });

    } catch (error) {
        console.error("Error adding Project Type:", error);
        if (error.name === 'SequelizeUniqueConstraintError') {
            return NextResponse.json({ error: "Project type with this title already exists." }, { status: 409 });
        }
        return NextResponse.json({ error: "Failed to add project type" }, { status: 500 });
    }
});
