export const dynamic = 'force-dynamic';
export const revalidate = 0;

import { NextResponse } from 'next/server';
import db from '@/database/models';

export async function PATCH(_req, { params }) {
  const id = Number(params.id);
  if (!id) return NextResponse.json({ ok: false, error: 'Invalid id' }, { status: 400 });

  const { Notification } = db;
  const now = Math.floor(Date.now() / 1000);

  const [aff] = await Notification.update(
    { is_read: 'true', updated: now },
    { where: { notification_id: id } }
  );
  if (!aff) return NextResponse.json({ ok: false, error: 'Not found' }, { status: 404 });

  return NextResponse.json({ ok: true });
}
