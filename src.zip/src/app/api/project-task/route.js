export const dynamic = 'force-dynamic';
export const revalidate = 0;

import { NextResponse } from 'next/server';
import db from "@/database/models";
import { withActive } from "@/utils/session";
const { Op } = require('sequelize');

const { Project, Task, taskAttachment } = db;

export const GET = withActive(async function GET_HANDLER(req, context, currentUser) {
    try {
        const projectData = await Project.findAll({
            include: [{
                where: { parent_id: { [Op.ne]: null } },
                model: Task,
                as: 'Task',
                required: false,

            }],
            where: { published: 'published' } // Hanya ambil proyek yang aktif
        });

        const treeData = projectData.map(project => ({
            title: project.title,
            value: `project-${project.project_id}`,
            disabled: true,
            children: (project.Task || []).map(task => ({
                title: task.title,
                value: `${project.project_id}-${task.task_id}`
            }))
        }));

        return NextResponse.json({ data: treeData });
    } catch (error) {
        console.error("Error fetching project-task:", error);
        return NextResponse.json({ error: "Failed to fetch project & task data." }, { status: 500 });
    }
});