// src/app/api/leave/route.js
export const dynamic = "force-dynamic";
export const revalidate = 0;

import { NextResponse } from "next/server";
import db from "@/database/models";
import dayjs from "dayjs";
import utc from "dayjs/plugin/utc";
import timezone from "dayjs/plugin/timezone";
import { withActive } from "@/utils/session";
import { notify as notifyUser } from "@/utils/notifier";
import { buildModalUrl } from "@/utils/url";

dayjs.extend(utc);
dayjs.extend(timezone);
dayjs.tz.setDefault(process.env.NEXT_PUBLIC_APP_TIMEZONE || "Asia/Jakarta");

const { LeaveRequest, User, LeaveConfig, Holiday, Sequelize } = db;
const { Op } = Sequelize;

// =========================
// GET /api/leave
// =========================
export const GET = withActive(async function GET_HANDLER(req, _ctx, currentUser) {
  try {
    const uid = Number(currentUser?.user_id || 0);
    if (!uid) return NextResponse.json({ error: "Unauthenticated" }, { status: 401 });

    const isHrd = currentUser?.is_hrd === "true";
    const isSuperadmin = currentUser?.is_superadmin === "true";
    const isHod = currentUser?.is_hod === "true";
    const isDirectorOperational = currentUser?.is_director_operational === "true";
    const userRole = currentUser?.user_role || null;

    const isPrivileged =
      isSuperadmin ||
      isHrd ||
      isHod ||
      isDirectorOperational ||
      userRole === "superadmin" ||
      userRole === "hrd";

    const { searchParams } = new URL(req.url);

    const page = Math.max(1, parseInt(searchParams.get("page") || "1", 10));
    const limit = Math.min(50, Math.max(1, parseInt(searchParams.get("limit") || "25", 10)));
    const offset = (page - 1) * limit;

    const period = String(searchParams.get("period") || "all").toLowerCase(); // all|today|period
    const fromParam = String(searchParams.get("from") || "").trim();
    const toParam = String(searchParams.get("to") || "").trim();
    const q = String(searchParams.get("q") || "").trim();

    const and = [];

    // active
    and.push({ deleted: { [Op.or]: [null, 0] } });

    // visibility (tanpa scope)
    if (!isPrivileged) {
      and.push({
        [Op.or]: [
          { user_id: uid },
          { assign_to: uid },
          { hod: uid },
          { hrd: uid },
          { operational_director: uid },
        ],
      });
    }

    // date filter
    if (period === "today") {
      const today = dayjs().tz().format("YYYY-MM-DD");
      and.push({ start_date: { [Op.lte]: today } });
      and.push({ end_date: { [Op.gte]: today } });
    } else if (period === "period") {
      const from = dayjs(fromParam);
      const to = dayjs(toParam);
      if (from.isValid() && to.isValid()) {
        const fromYMD = from.format("YYYY-MM-DD");
        const toYMD = to.format("YYYY-MM-DD");
        // overlap range
        and.push({ start_date: { [Op.lte]: toYMD } });
        and.push({ end_date: { [Op.gte]: fromYMD } });
      }
    }

    // search
    if (q) {
      and.push({
        [Op.or]: [
          { permit: { [Op.like]: `%${q}%` } },
          { reason: { [Op.like]: `%${q}%` } },
          { detail: { [Op.like]: `%${q}%` } },
          { assign_note: { [Op.like]: `%${q}%` } },
        ],
      });
    }

    const where = { [Op.and]: and };

    const { rows, count } = await LeaveRequest.findAndCountAll({
      where,
      distinct: true,
      include: [
        { model: User, as: "User", attributes: ["user_id", "fullname", "email", "phone"], required: false },
        { model: User, as: "AssignedTo", attributes: ["user_id", "fullname", "email", "phone"], required: false },
        { model: User, as: "HOD", attributes: ["user_id", "fullname", "email", "phone"], required: false },
        { model: User, as: "HRD", attributes: ["user_id", "fullname", "email", "phone"], required: false },
        { model: User, as: "OperationalDirector", attributes: ["user_id", "fullname", "email", "phone"], required: false },
      ],
      order: [["start_date", "DESC"], ["leave_id", "DESC"]],
      limit,
      offset,
    });

    let data = rows.map((r) => r.toJSON());

    // ===========================
    // Inject quota_leave (FINAL APPROVED ONLY)
    // ===========================
    try {
      const todayYmd = dayjs().tz().format("YYYY-MM-DD");

      // default leave-year: Apr 1 → Mar 31
      let yearStart = `${dayjs().year()}-04-01`;
      let yearEnd = `${dayjs().year() + 1}-03-31`;

      // if today < Apr 1, yearStart belongs to previous year
      const y = dayjs(todayYmd).year();
      const apr1 = dayjs(`${y}-04-01`, "YYYY-MM-DD", true);
      if (dayjs(todayYmd).isBefore(apr1, "day")) {
        yearStart = `${y - 1}-04-01`;
        yearEnd = `${y}-03-31`;
      }

      // annual quota from LeaveConfig (Cuti Tahunan%)
      let annualQuota = 12;
      const cfg = await LeaveConfig.findOne({
        where: { title: { [Op.like]: "Cuti Tahunan%" } },
        attributes: ["total"],
        raw: true,
      });
      if (cfg && cfg.total != null) annualQuota = Number(cfg.total) || annualQuota;

      // holidays: type=holiday
      const holRows = await Holiday.findAll({
        where: { date: { [Op.between]: [yearStart, yearEnd] }, type: "holiday" },
        attributes: ["date"],
        raw: true,
      });
      const publicHolidaySet = new Set((holRows || []).map((r) => String(r.date)));

      // joint leave count: type=leave, exclude weekend
      const jointRows = await Holiday.findAll({
        where: { date: { [Op.between]: [yearStart, yearEnd] }, type: "leave" },
        attributes: ["date"],
        raw: true,
      });

      let jointLeaveCount = 0;
      for (const r of jointRows || []) {
        const d = dayjs(String(r.date), "YYYY-MM-DD", true);
        if (!d.isValid()) continue;
        const dow = d.day();
        if (dow !== 0 && dow !== 6) jointLeaveCount += 1;
      }

      const userIds = Array.from(new Set(data.map((x) => Number(x.user_id || 0)).filter(Boolean)));

      const usedMap = {}; // user_id -> usedAnnualDays

      if (userIds.length) {
        const lr = await LeaveRequest.findAll({
          where: {
            user_id: { [Op.in]: userIds },
            deleted: { [Op.or]: [null, 0] },
            start_date: { [Op.lte]: yearEnd },
            end_date: { [Op.gte]: yearStart },
          },
          attributes: [
            "leave_id",
            "user_id",
            "start_date",
            "end_date",
            "reason",
            "status",
            "assign_to",
            "hod",
            "hrd",
            "operational_director",
            "approval_assign_to_status",
            "approval_hod_status",
            "approval_hrd_status",
            "approval_operational_director_status",
          ],
          raw: true,
        });

        for (const r of lr || []) {
          const reason = String(r.reason || "").toLowerCase().trim();
          if (!reason.startsWith("cuti tahunan")) continue;

          // FINAL APPROVED:
          // status = approved dan semua approval yg "dipakai" harus approved
          const finalApproved =
            String(r.status || "").toLowerCase() === "approved" &&
            (!Number(r.assign_to || 0) || String(r.approval_assign_to_status || "").toLowerCase() === "approved") &&
            (!Number(r.hod || 0) || String(r.approval_hod_status || "").toLowerCase() === "approved") &&
            (!Number(r.hrd || 0) || String(r.approval_hrd_status || "").toLowerCase() === "approved") &&
            (!Number(r.operational_director || 0) ||
              String(r.approval_operational_director_status || "").toLowerCase() === "approved");

          if (!finalApproved) continue;

          const s = dayjs(String(r.start_date), "YYYY-MM-DD", true);
          const e = dayjs(String(r.end_date), "YYYY-MM-DD", true);
          if (!s.isValid() || !e.isValid()) continue;

          const effStart = s.isBefore(yearStart, "day") ? dayjs(yearStart) : s;
          const effEnd = e.isAfter(yearEnd, "day") ? dayjs(yearEnd) : e;

          let d = effStart.clone();
          let used = 0;

          while (!d.isAfter(effEnd, "day")) {
            const ymd = d.format("YYYY-MM-DD");
            const dow = d.day();
            const isWeekend = dow === 0 || dow === 6;

            if (!isWeekend && !publicHolidaySet.has(ymd)) used += 1;
            d = d.add(1, "day");
          }

          const u = Number(r.user_id || 0);
          usedMap[u] = (usedMap[u] || 0) + used;
        }
      }

      data = data.map((x) => {
        const u = Number(x.user_id || 0);
        const usedAnnual = usedMap[u] || 0;
        const remaining = annualQuota - (usedAnnual + jointLeaveCount);
        return {
          ...x,
          quota_leave: remaining,
          quota_leave_meta: { annualQuota, usedAnnual, jointLeaveCount, leaveYear: { yearStart, yearEnd } },
        };
      });
    } catch (e) {
      console.warn("quota_leave inject failed:", e?.message || e);
      // kalau gagal, biarin FE tampil "-"
    }

    return NextResponse.json({ ok: true, data, meta: { page, limit, total: count } }, { status: 200 });
  } catch (err) {
    console.error("GET /api/leave error:", err);
    return NextResponse.json({ error: err?.message || "Failed" }, { status: 500 });
  }
});

// =========================
// POST /api/leave
// =========================
export const POST = withActive(async function POST_HANDLER(req, _ctx, currentUser) {
  try {
    const uid = Number(currentUser?.user_id || 0);
    if (!uid) return NextResponse.json({ error: "Unauthenticated" }, { status: 401 });

    const body = await req.json();
    const nowUnix = dayjs().unix();

    const start = dayjs(body?.startDate);
    const end = dayjs(body?.endDate);

    if (!start.isValid() || !end.isValid()) {
      return NextResponse.json({ error: "startDate and endDate are required (YYYY-MM-DD)" }, { status: 400 });
    }

    const start_date = start.format("YYYY-MM-DD");
    const end_date = end.format("YYYY-MM-DD");

    if (end.isBefore(start, "day")) {
      return NextResponse.json({ error: "endDate must be the same day or after startDate" }, { status: 400 });
    }

    const days = end.diff(start, "day") + 1;
    if (days <= 0 || days > 60) {
      return NextResponse.json({ error: "Invalid date range" }, { status: 400 });
    }

    const permit = body?.permit ? String(body.permit) : "Leave";

    const mlreasonId = Number(body?.mlreasonId || 0) || null;

    let reason = body?.reason ? String(body.reason).trim() : null;
    const detail = body?.detail ? String(body.detail).trim() : null;
    const assign_note = body?.assignNote ? String(body.assignNote).trim() : null;

    // assignWorkTo bisa array atau number
    const assignWorkTo = body?.assignWorkTo;
    const assign_to = Array.isArray(assignWorkTo)
      ? Number(assignWorkTo?.[0] || 0) || null
      : Number(assignWorkTo || 0) || null;

    const hod = Number(body?.headOfDepartment || 0) || null;
    const hrd = Number(body?.hrd || 0) || null;
    const operational_director = Number(body?.operationalDirector || 0) || null;

    if (mlreasonId) {
      const cfg = await LeaveConfig.findOne({
        where: { lconfig_id: mlreasonId, deleted: { [Op.or]: [null, 0] } },
        attributes: ["title"],
      });
      if (cfg?.title) reason = cfg.title;
    }

    // overlap check (pending/approved)
    const overlap = await LeaveRequest.findOne({
      where: {
        user_id: uid,
        deleted: { [Op.or]: [null, 0] },
        status: { [Op.in]: ["pending", "approved"] },
        start_date: { [Op.lte]: end_date },
        end_date: { [Op.gte]: start_date },
      },
      attributes: ["leave_id"],
    });

    if (overlap) {
      return NextResponse.json({ error: "You already have leave on that date range." }, { status: 400 });
    }

    const created = await LeaveRequest.create({
      user_id: uid,
      start_date,
      end_date,
      days,
      permit,
      reason,
      detail,
      assign_note,

      assign_to,
      hod,
      hrd,
      operational_director,

      status: "pending",

      approval_assign_to_status: "pending",
      approval_assign_to_at: null,

      approval_hod_status: "pending",
      approval_hod_at: null,

      approval_hrd_status: "pending",
      approval_hrd_at: null,

      approval_operational_director_status: "pending",
      approval_operational_director_at: null,

      created: nowUnix,
      created_by: uid,
      updated: nowUnix,
      updated_by: uid,
      deleted: null,
      deleted_by: null,
    });

    const leaveId = created.leave_id;

    // URL notif ikut style subtaskItem
    const url = buildModalUrl({
      module: "leave",
      id: Number(leaveId),
      commentId: null,
      basePath: "/leave",
    });

    const actorName = currentUser?.fullname || currentUser?.email || `User #${uid}`;
    const rangeStr = `${start_date} → ${end_date}`;
    const reasonStr = reason || "-";

    // notif (style subtaskItem): description + url + payload
    // assign_to
    if (assign_to) {
      try {
        await notifyUser({
          userId: Number(assign_to),
          sender: "system",
          description: `${actorName} created leave request (${reasonStr}) for ${rangeStr}. Please approve (Assign To).`,
          url,
          payload: { type: "leave_need_approval_assign", leaveId },
        });
      } catch (e) {
        console.warn("notify assign_to failed:", e?.message || e);
      }
    }

    // hod
    if (hod) {
      try {
        await notifyUser({
          userId: Number(hod),
          sender: "system",
          description: `${actorName} created leave request (${reasonStr}) for ${rangeStr}. Please approve (HOD).`,
          url,
          payload: { type: "leave_need_approval_hod", leaveId },
        });
      } catch (e) {
        console.warn("notify hod failed:", e?.message || e);
      }
    }

    // hrd
    if (hrd) {
      try {
        await notifyUser({
          userId: Number(hrd),
          sender: "system",
          description: `${actorName} created leave request (${reasonStr}) for ${rangeStr}. Please approve (HRD).`,
          url,
          payload: { type: "leave_need_approval_hrd", leaveId },
        });
      } catch (e) {
        console.warn("notify hrd failed:", e?.message || e);
      }
    }

    // director
    if (operational_director) {
      try {
        await notifyUser({
          userId: Number(operational_director),
          sender: "system",
          description: `${actorName} created leave request (${reasonStr}) for ${rangeStr}. Please approve (Director).`,
          url,
          payload: { type: "leave_need_approval_director", leaveId },
        });
      } catch (e) {
        console.warn("notify director failed:", e?.message || e);
      }
    }

    return NextResponse.json({ ok: true, data: created }, { status: 201 });
  } catch (err) {
    console.error("POST /api/leave error:", err);
    return NextResponse.json({ error: err?.message || "Failed" }, { status: 500 });
  }
});
