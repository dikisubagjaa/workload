
export const dynamic = 'force-dynamic';
export const revalidate = 0;

import { NextResponse } from "next/server";
import { Task, Project, Department, SubTask } from "@/database/models"; // Pastikan path sesuai dengan lokasi model
import dayjs from 'dayjs';
import { getUnixTimestampUTC } from "@/utils/dateHelpers";
import { withAuth } from "@/utils/session";

// Ambil semua profil dari database
export async function GET(req, { params }) {
  try {
    const { taskId } = params;
    const detail = await Task.findOne({ where: { task_id: taskId } });
    const projectData = await Project.findAll({ where: { project_id: detail.project_id } });

    return NextResponse.json({ detailTask: detail, project: projectData }, { status: 200 });
  } catch (error) {
    console.error("Error fetching Tasks:", error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}


export async function PUT(req, { params }) {
  try {
    const { taskId } = params;
    const body = await req.json();

    const detail = await Task.findOne({ where: { task_id: taskId } });
    if (!detail) {
      return NextResponse.json({ error: "Task tidak ditemukan" }, { status: 404 });
    }
    if (body.type == "department") {
      const rawIds = body.value.flat(); // jadi [3, 4]

      // Ambil info department-nya dari master table
      const departments = await Department.findAll({
        where: { department_id: rawIds },
        attributes: ['department_id', 'title']
      });

      // Format hasilnya
      const formattedDepartments = departments.map((dept) => ({
        department_id: dept.department_id,
        title: dept.title,
      }));

      const updateTask = await Task.update({
        [body.type]: formattedDepartments,
        "updated": dayjs().format('YYYY-MM-DD HH:mm:ss'),
        "updated_by": 1,
      }, {
        where: { task_id: taskId }, // jangan lupa tambahkan where condition-nya di sini
        logging: console.log, // ← log khusus query ini saja
      }
      );

      // Simpan data ke database
      return NextResponse.json({ message: "Task berhasil diubah", department: formattedDepartments });
    } else {
      const updateTask = await Task.update({
        [body.type]: body.value,
        "updated": dayjs().format('YYYY-MM-DD HH:mm:ss'),
        "updated_by": 1,
      }, {
        where: { task_id: taskId }, // jangan lupa tambahkan where condition-nya di sini
        logging: console.log, // ← log khusus query ini saja
      }
      );

      // Simpan data ke database
      return NextResponse.json({ message: "Task berhasil diubah" });
    }
  } catch (error) {
    console.error("Error adding Task:", error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

export const POST = withAuth(async function POST_HANDLER(req, { params }, currentUser) {
  try {
    const { taskId } = params;
    const body = await req.json();

    if (!body.title) {
      return NextResponse.json({ error: "Judul Sub Task wajib diisi." }, { status: 400 });
    }

    // Cek apakah task utama ada
    const detail = await Task.findOne({ where: { task_id: taskId }, order: [['created', 'DESC']] });
    if (!detail) {
      return NextResponse.json({ error: "Task tidak ditemukan" }, { status: 404 });
    }

    // Simpan SubTask
    const nowUnix = getUnixTimestampUTC(); // Using global helper      
    const newSubTask = await SubTask.create({
      title: body.title,
      task_id: taskId,
      created: nowUnix,
      created_by: currentUser.user_id,
      updated: nowUnix,
      updated_by: currentUser.user_id,
    });

    return NextResponse.json({
      message: "Sub Task berhasil ditambahkan",
      subTask: newSubTask, // hanya satu subtask
    });
  } catch (error) {
    console.error("Error adding SubTask:", error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
})

