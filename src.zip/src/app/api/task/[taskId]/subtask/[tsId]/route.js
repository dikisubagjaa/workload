export const dynamic = 'force-dynamic';
export const revalidate = 0;

import { NextResponse } from "next/server";
import { Task, SubTask } from "@/database/models";
import { withAuth } from "@/utils/session"; // samain dengan import yg lain
import { getUnixTimestampUTC } from "@/utils/dateHelpers";

// EDIT SUBTASK
export const PUT = withAuth(async (req, { params }, currentUser) => {
    try {
        const { taskId, tsId } = params;
        const body = await req.json();
        const title = (body?.title ?? "").trim();

        if (!taskId || !tsId) {
            return NextResponse.json({ error: "Invalid params" }, { status: 400 });
        }
        if (!title) {
            return NextResponse.json({ error: "Title is required" }, { status: 422 });
        }

        const task = await Task.findOne({ where: { task_id: taskId } });
        if (!task) return NextResponse.json({ error: "Task not found" }, { status: 404 });

        const sub = await SubTask.findOne({ where: { ts_id: tsId, task_id: taskId } });
        if (!sub) return NextResponse.json({ error: "Subtask not found" }, { status: 404 });

        const nowUnix = getUnixTimestampUTC();
        await SubTask.update(
            { title, updated: nowUnix, updated_by: currentUser.user_id },
            { where: { ts_id: tsId, task_id: taskId } }
        );

        const updated = await SubTask.findOne({ where: { ts_id: tsId } });
        return NextResponse.json({ message: "Subtask updated", subTask: updated }, { status: 200 });
    } catch (e) {
        console.error("Update Subtask error:", e);
        return NextResponse.json({ error: e.message }, { status: 500 });
    }
});

// DELETE SUBTASK
export const DELETE = withAuth(async (_req, { params }, currentUser) => {
    try {
        const { taskId, tsId } = params;

        if (!taskId || !tsId) {
            return NextResponse.json({ error: "Invalid params" }, { status: 400 });
        }

        const sub = await SubTask.findOne({ where: { ts_id: tsId, task_id: taskId } });
        if (!sub) return NextResponse.json({ error: "Subtask not found" }, { status: 404 });

        await SubTask.update(
            { deleted: true, deleted_at: getUnixTimestampUTC(), deleted_by: currentUser.user_id },
            { where: { ts_id: tsId, task_id: taskId } }
        );

        await Task.update(
            { deleted: true, deleted_at: getUnixTimestampUTC(), deleted_by: currentUser.user_id },
            { where: { ts_id: tsId } }
        );

        return NextResponse.json({ message: "Subtask deleted", tsId: Number(tsId) }, { status: 200 });
    } catch (e) {
        console.error("Delete Subtask error:", e);
        return NextResponse.json({ error: e.message }, { status: 500 });
    }
});
