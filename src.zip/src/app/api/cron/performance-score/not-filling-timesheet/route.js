// src/app/api/cron/performance-score/not-filling-timesheet/route.js
import 'server-only';
import db from '@/database/models';
import dayjs from 'dayjs';
import tz from 'dayjs/plugin/timezone';
import { withCronLock } from '@/utils/cronLock';

dayjs.extend(tz);

export const dynamic = 'force-dynamic';
export const revalidate = 0;

const { Timesheet, Task, TaskAssignment, PerformanceEventLog, Sequelize } = db;
const { Op } = Sequelize;

const TZ = process.env.NEXT_PUBLIC_APP_TIMEZONE || 'Asia/Jakarta';

// Not Filling Timesheet (hanya untuk user yang masih punya task belum completed)
const PERF_CONFIG_ID = 10;
const SCORE_VALUE = -5;

const DONE_STATUSES = ['completed'];
const CANCEL_STATUSES = ['cancel'];

export async function GET(req) {
    const t0 = Date.now();

    try {
        const { searchParams } = new URL(req.url);
        const dateParam = searchParams.get('date');
        const dryRun =
            String(searchParams.get('dryRun') || '').toLowerCase() === 'true';

        // eventDate = hari ini (TZ) atau ?date=YYYY-MM-DD
        const eventDate =
            dateParam && /^\d{4}-\d{2}-\d{2}$/.test(dateParam)
                ? dateParam
                : dayjs().tz(TZ).format('YYYY-MM-DD');

        const periodYear = Number(dayjs(eventDate).year());
        const periodMonth = Number(dayjs(eventDate).month() + 1);
        const periodStart = dayjs(eventDate)
            .startOf('month')
            .format('YYYY-MM-DD');

        const res = await withCronLock(
            `perf-not-filling-timesheet-${eventDate}`,
            async () => {
                // =====================================================
                // 1) Cari TASK AKTIF (belum completed/cancel)
                //    Task.todo NOT IN (DONE, CANCEL)
                // =====================================================
                const activeTasks = await Task.findAll({
                    attributes: ['task_id'],
                    where: {
                        todo: {
                            [Op.notIn]: [...DONE_STATUSES, ...CANCEL_STATUSES],
                        },
                    },
                    raw: true,
                });

                const activeTaskIds = activeTasks.map((t) => t.task_id).filter(Boolean);

                if (!activeTaskIds.length) {
                    return {
                        inserted: 0,
                        scanned: 0,
                        target: 0,
                        skipped: 0,
                        note: 'no active (incomplete) tasks',
                    };
                }

                // =====================================================
                // 2) Dari task aktif itu, ambil USER yg masih dapat assign
                //    -> hanya mereka yang wajib isi timesheet
                // =====================================================
                const assignedRows = await TaskAssignment.findAll({
                    attributes: ['user_id'],
                    where: {
                        task_id: { [Op.in]: activeTaskIds },
                        user_id: { [Op.ne]: null },
                    },
                    group: ['user_id'],
                    raw: true,
                });

                const assignedUserIds = assignedRows
                    .map((r) => r.user_id)
                    .filter(Boolean);

                if (!assignedUserIds.length) {
                    return {
                        inserted: 0,
                        scanned: 0,
                        target: 0,
                        skipped: 0,
                        note: 'no users with assignment on active tasks',
                    };
                }

                // =====================================================
                // 3) Dari user-user itu, cek siapa yg sudah isi Timesheet
                //    Timesheet.date = eventDate (sesuai model)
                // =====================================================
                const filledRows = await Timesheet.findAll({
                    where: {
                        user_id: { [Op.in]: assignedUserIds },
                        date: eventDate,              // <-- kolom date (DATEONLY)
                    },
                    attributes: ['user_id'],
                    group: ['user_id'],
                    raw: true,
                });

                const filledUserIds = new Set(
                    filledRows.map((r) => r.user_id).filter(Boolean),
                );

                // =====================================================
                // 4) Target penalti:
                //    user yang MASIH punya task aktif,
                //    TAPI tidak ada Timesheet.date = eventDate
                // =====================================================
                const targetUserIds = assignedUserIds.filter(
                    (uid) => !filledUserIds.has(uid),
                );

                if (!targetUserIds.length) {
                    return {
                        inserted: 0,
                        scanned: assignedUserIds.length,
                        target: 0,
                        skipped: 0,
                        note: 'all users with active tasks filled timesheet',
                    };
                }

                // =====================================================
                // 5) Cek existing log biar idempotent
                //    (per user per hari per config)
                // =====================================================
                const existing = await PerformanceEventLog.findAll({
                    where: {
                        perf_config_id: PERF_CONFIG_ID,
                        event_date: eventDate,
                        user_id: { [Op.in]: targetUserIds },
                    },
                    attributes: ['user_id'],
                    raw: true,
                });
                const existedUsers = new Set(
                    existing.map((e) => e.user_id).filter(Boolean),
                );

                const nowUnix = Math.floor(Date.now() / 1000);
                const rows = [];
                let skipped = 0;

                for (const userId of targetUserIds) {
                    if (!userId) continue;
                    if (existedUsers.has(userId)) {
                        skipped++;
                        continue;
                    }

                    rows.push({
                        user_id: userId,
                        event_date: eventDate,
                        period_year: periodYear,
                        period_month: periodMonth,
                        period_start_date: periodStart,
                        perf_config_id: PERF_CONFIG_ID,
                        score_value: SCORE_VALUE,
                        source: 'timesheet',
                        ref_id: 0, // tidak terkait ke 1 record tertentu
                        note: `Not filling timesheet on ${eventDate}`,
                        meta: JSON.stringify({
                            bucket: 'not_filling_timesheet',
                            date: eventDate,
                            has_active_task: true,
                        }),
                        created: nowUnix,
                        updated: nowUnix,
                    });
                }

                if (dryRun) {
                    return {
                        scanned: assignedUserIds.length,
                        target: targetUserIds.length,
                        inserted: 0,
                        skipped,
                        willInsert: rows.length,
                        sample: rows.slice(0, 5),
                        dryRun: true,
                    };
                }

                let inserted = 0;
                if (rows.length) {
                    const result = await PerformanceEventLog.bulkCreate(rows, {
                        ignoreDuplicates: true,
                    });
                    inserted = Array.isArray(result) ? result.length : 0;
                }

                return {
                    inserted,
                    scanned: assignedUserIds.length,
                    target: targetUserIds.length,
                    skipped,
                };
            },
            { ttlSec: 60 },
        );

        if (res?.locked) {
            return new Response(
                JSON.stringify({
                    ok: false,
                    rule: 'not-filling-timesheet',
                    date: eventDate,
                    busy: true,
                }),
                { status: 423 },
            );
        }

        return Response.json({
            ok: true,
            rule: 'not-filling-timesheet',
            date: eventDate,
            ...res,
            ms: Date.now() - t0,
        });
    } catch (err) {
        console.error('[cron][not-filling-timesheet] error:', err);
        return new Response(
            JSON.stringify({ ok: false, error: String(err?.message || err) }),
            { status: 500 },
        );
    }
}
