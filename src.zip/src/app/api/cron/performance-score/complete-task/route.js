// src/app/api/cron/performance-score/complete-task/route.js
import 'server-only';
import { Task, PerformanceEventLog, Sequelize } from '@/database/models';
import dayjs from 'dayjs';
import tz from 'dayjs/plugin/timezone';
import { withCronLock } from '@/utils/cronLock';
dayjs.extend(tz);

export const dynamic = 'force-dynamic';
export const revalidate = 0;

const TZ = process.env.NEXT_PUBLIC_APP_TIMEZONE || 'Asia/Jakarta';

// Rule "Complete Task On Deadline"
const PERF_CONFIG_ID = 5;
const SCORE_VALUE = 0;

// Status yang dianggap selesai
const DONE_STATUSES = ['done', 'completed', 'approved_ae'];

export async function GET(req) {
    const t0 = Date.now();
    const { Op } = Sequelize;

    try {
        const { searchParams } = new URL(req.url);
        const dateParam = searchParams.get('date');
        const dryRun =
            String(searchParams.get('dryRun') || '').toLowerCase() === 'true';

        // default ke hari ini (TZ)
        const eventDate =
            dateParam && /^\d{4}-\d{2}-\d{2}$/.test(dateParam)
                ? dateParam
                : dayjs().tz(TZ).format('YYYY-MM-DD');

        const periodYear = Number(dayjs(eventDate).year());
        const periodMonth = Number(dayjs(eventDate).month() + 1);
        const periodStart = dayjs(eventDate)
            .startOf('month')
            .format('YYYY-MM-DD');

        const res = await withCronLock(
            `perf-complete-on-deadline-${eventDate}`,
            async () => {
                const taskAttrs = Task.rawAttributes || {};
                const hasEndDate = 'end_date' in taskAttrs;
                const hasTodo = 'todo' in taskAttrs;
                const hasUpdated = 'updated' in taskAttrs;

                if (!hasEndDate || !hasTodo || !hasUpdated) {
                    return {
                        inserted: 0,
                        scanned: 0,
                        skipped: 0,
                        note: 'Task model missing required columns',
                    };
                }

                const dayStart = dayjs
                    .tz(eventDate, TZ)
                    .startOf('day')
                    .unix();
                const dayEnd = dayjs
                    .tz(eventDate, TZ)
                    .endOf('day')
                    .unix();

                // Task yang:
                //  - todo selesai
                //  - diupdate di hari eventDate (anggap sebagai tanggal selesai)
                //  - end_date tepat di hari eventDate (on deadline)
                const tasks = await Task.findAll({
                    where: {
                        todo: { [Op.in]: DONE_STATUSES },
                        updated: { [Op.between]: [dayStart, dayEnd] },
                        end_date: { [Op.between]: [dayStart, dayEnd] },
                    },
                    attributes: ['task_id', 'title', 'end_date'],
                    raw: true,
                });

                if (!tasks.length) {
                    return {
                        inserted: 0,
                        scanned: 0,
                        skipped: 0,
                        note: 'no tasks completed on deadline',
                    };
                }

                const taskIds = tasks.map((t) => t.task_id);

                // Ambil semua assignee aktif
                const assigns = await TaskAssignment.findAll({
                    where: { task_id: { [Op.in]: taskIds } },
                    attributes: ['task_id', 'user_id'],
                    raw: true,
                });

                if (!assigns.length) {
                    return {
                        inserted: 0,
                        scanned: tasks.length,
                        skipped: 0,
                        note: 'no assignees',
                    };
                }

                const usersByTask = new Map();
                for (const a of assigns) {
                    if (!usersByTask.has(a.task_id)) usersByTask.set(a.task_id, []);
                    if (a.user_id) usersByTask.get(a.task_id).push(a.user_id);
                }

                const allRefPairs = [];
                for (const t of tasks) {
                    const users = usersByTask.get(t.task_id) || [];
                    for (const uid of users) {
                        allRefPairs.push({ ref_id: t.task_id, user_id: uid });
                    }
                }

                if (!allRefPairs.length) {
                    return {
                        inserted: 0,
                        scanned: tasks.length,
                        skipped: 0,
                        note: 'no assignees after mapping',
                    };
                }

                const refIds = [...new Set(allRefPairs.map((p) => p.ref_id))];

                // Cek existing log (idempotent)
                const existing = await PerformanceEventLog.findAll({
                    where: {
                        perf_config_id: PERF_CONFIG_ID,
                        event_date: eventDate,
                        ref_id: { [Op.in]: refIds },
                    },
                    attributes: ['ref_id', 'user_id'],
                    raw: true,
                });
                const existed = new Set(
                    existing.map((e) => `${e.user_id}:${e.ref_id}`),
                );

                const byIdTitle = new Map(
                    tasks.map((t) => [t.task_id, t.title]),
                );
                const byIdDeadline = new Map(
                    tasks.map((t) => [t.task_id, t.end_date]),
                );

                const nowUnix = Math.floor(Date.now() / 1000);
                const rows = [];
                let skipped = 0;

                for (const { user_id, ref_id } of allRefPairs) {
                    const key = `${user_id}:${ref_id}`;
                    if (existed.has(key)) {
                        skipped++;
                        continue;
                    }

                    const deadlineUnix = byIdDeadline.get(ref_id);
                    const deadlineYmd = deadlineUnix
                        ? dayjs.unix(deadlineUnix).tz(TZ).format('YYYY-MM-DD')
                        : null;

                    rows.push({
                        user_id,
                        event_date: eventDate,
                        period_year: periodYear,
                        period_month: periodMonth,
                        period_start_date: periodStart,
                        perf_config_id: PERF_CONFIG_ID,
                        score_value: SCORE_VALUE,
                        source: 'task',
                        ref_id,
                        note: `Complete Task On Deadline: [#${ref_id}] ${byIdTitle.get(ref_id) || '(no title)'
                            }`,
                        meta: JSON.stringify({
                            task_id: ref_id,
                            title: byIdTitle.get(ref_id) || null,
                            deadline: deadlineYmd,
                            bucket: 'on_deadline',
                        }),
                        created: nowUnix,
                        updated: nowUnix,
                    });
                }

                if (dryRun) {
                    return {
                        scanned: tasks.length,
                        inserted: 0,
                        skipped,
                        willInsert: rows.length,
                        sample: rows.slice(0, 5),
                        dryRun: true,
                    };
                }

                let inserted = 0;
                if (rows.length) {
                    const result = await PerformanceEventLog.bulkCreate(rows, {
                        ignoreDuplicates: true,
                    });
                    inserted = Array.isArray(result) ? result.length : 0;
                }

                return { inserted, scanned: tasks.length, skipped };
            },
            { ttlSec: 60 },
        );

        if (res?.locked) {
            return new Response(
                JSON.stringify({
                    ok: false,
                    rule: 'complete-on-deadline',
                    date: eventDate,
                    busy: true,
                }),
                { status: 423 },
            );
        }

        return Response.json({
            ok: true,
            rule: 'complete-on-deadline',
            date: eventDate,
            ...res,
            ms: Date.now() - t0,
        });
    } catch (err) {
        console.error('[cron][complete-on-deadline] error:', err);
        return new Response(
            JSON.stringify({ ok: false, error: String(err?.message || err) }),
            { status: 500 },
        );
    }
}
