// src/app/api/client/[clientId]/route.js
import { NextResponse } from 'next/server';
import db from "@/database/models";
const { Client, User } = db; // Import model Client dan User
import dayjs from 'dayjs';
import utc from 'dayjs/plugin/utc';
dayjs.extend(utc);

import { getUnixTimestampUTC } from "@/utils/dateHelpers";
import { withActive } from "@/utils/session";

export const GET = withActive(async function GET_HANDLER(req, { params }, currentUser) {
    try {
        const { clientId } = params;
        const client = await Client.findByPk(clientId);

        if (!client) {
            return NextResponse.json({ error: "Client not found." }, { status: 404 });
        }

        const clientJson = client.toJSON();
        // `brand` di sini akan menjadi array of objects (dari DB)
        const rawBrands = Array.isArray(clientJson.brand) ? clientJson.brand : [];

        const formattedClient = {
            ...clientJson,
            brand: rawBrands, // Sekarang 'brand' adalah array of objects
            created: clientJson.created ? dayjs.unix(clientJson.created) : null,
            updated: clientJson.updated ? dayjs.unix(clientJson.updated) : null,
            deleted: clientJson.deleted ? dayjs.unix(clientJson.deleted) : null,
        };

        return NextResponse.json({ client: formattedClient }, { status: 200 });
    } catch (error) {
        console.error("Error fetching client detail:", error);
        return NextResponse.json({ error: error.message || "Failed to fetch client detail." }, { status: 500 });
    }
});

export const PUT = withActive(async function PUT_HANDLER(req, { params }, currentUser) {

    try {
        const { clientId } = params;
        const body = await req.json();
        const nowUnix = getUnixTimestampUTC();

        const clientToUpdate = await Client.findByPk(clientId);
        if (!clientToUpdate) {
            return NextResponse.json({ error: "Client not found." }, { status: 404 });
        }

        const updatedData = {
            updated: nowUnix,
            updated_by: currentUser,
        };

        // Kolom yang bisa diupdate
        if (body.type !== undefined) updatedData.type = body.type;
        if (body.client_name !== undefined) updatedData.client_name = body.client_name;
        // --- PERBAIKAN: Hidrasi brand dari brand_id (array of integers) ke objek lengkap di PUT ---
        let finalBrandsForDb = [];
        if (Array.isArray(body.brand) && body.brand.length > 0) {
            const fetchedBrandsByIds = await Brand.findAll({
                where: { brand_id: body.brand }, // <-- Cari brand berdasarkan array brand_id
                attributes: ['brand_id', 'name']
            });
            finalBrandsForDb = fetchedBrandsByIds.map(b => b.toJSON());
        }
        updatedData.brand = finalBrandsForDb; // <-- Disimpan sebagai array of objects lengkap
        // --- AKHIR PERBAIKAN ---

        if (body.division !== undefined) updatedData.division = body.division;
        if (body.address !== undefined) updatedData.address = body.address;
        if (body.pic_name !== undefined) updatedData.pic_name = body.pic_name;
        if (body.pic_phone !== undefined) updatedData.pic_phone = body.pic_phone;
        if (body.pic_email !== undefined) updatedData.pic_email = body.pic_email;
        if (body.finance_name !== undefined) updatedData.finance_name = body.finance_name;
        if (body.finance_phone !== undefined) updatedData.finance_phone = body.finance_phone;
        if (body.finance_email !== undefined) updatedData.finance_email = body.finance_email;

        const [updatedCount] = await Client.update(updatedData, { where: { client_id: clientId } });

        if (updatedCount === 0) {
            return NextResponse.json({ message: "No changes applied to client or client not found." }, { status: 200 });
        }

        const updatedClient = await Client.findByPk(clientId);
        return NextResponse.json({ message: "Client updated successfully!", client: updatedClient.toJSON() });
    } catch (error) {
        console.error("Error updating client:", error);
        return NextResponse.json({ error: error.message || "Failed to update client." }, { status: 500 });
    }
});

export const DELETE = withActive(async function DELETE_HANDLER(req, { params }, currentUser) {
    if (currentUser.user_role !== 'admin' && currentUser.user_role !== 'superadmin') {
        return NextResponse.json({ error: "Unauthorized" }, { status: 403 });
    }
    try {
        const { clientId } = params;
        const nowUnix = getUnixTimestampUTC();

        const clientToDelete = await Client.findByPk(clientId);
        if (!clientToDelete) {
            return NextResponse.json({ error: "Client not found." }, { status: 404 });
        }

        await clientToDelete.update({
            deleted: nowUnix,
            deleted_by: currentUser,
        });

        return NextResponse.json({ message: "Client soft-deleted successfully!" }, { status: 200 });
    } catch (error) {
        console.error("Error soft deleting client:", error);
        return NextResponse.json({ error: error.message || "Failed to perform soft delete." }, { status: 500 });
    }
});