// src/app/api/cron/performance-score/late-to-work/route.js
import 'server-only';
import { Attendance, PerformanceEventLog, Sequelize } from '@/database/models';
import dayjs from 'dayjs';
import tz from 'dayjs/plugin/timezone';
import { withCronLock } from '@/utils/cronLock';

dayjs.extend(tz);

export const dynamic = 'force-dynamic';
export const revalidate = 0;

const TZ = process.env.NEXT_PUBLIC_APP_TIMEZONE || 'Asia/Jakarta';
const OPEN_AT = '09:00:00';       // batas terlambat (jam kantor buka)
const PERF_CONFIG_ID = 1;         // config "Late To Work"
const SCORE_VALUE = -1;           // penalti

export async function GET(req) {
    const t0 = Date.now();
    const { Op, fn, col, where } = Sequelize;

    try {
        const { searchParams } = new URL(req.url);
        const dateParam = searchParams.get('date');
        const dryRun = String(searchParams.get('dryRun') || '').toLowerCase() === 'true';

        // eventDate = hari ini (TZ) atau ?date=YYYY-MM-DD
        const eventDate =
            dateParam && /^\d{4}-\d{2}-\d{2}$/.test(dateParam)
                ? dateParam
                : dayjs().tz(TZ).format('YYYY-MM-DD');

        const periodYear = Number(dayjs(eventDate).year());
        const periodMonth = Number(dayjs(eventDate).month() + 1);
        const periodStart = dayjs(eventDate).startOf('month').format('YYYY-MM-DD');

        const res = await withCronLock(
            `perf-late-to-work-${eventDate}`,
            async () => {
                // 1) Cari karyawan yang clock_in > OPEN_AT di tanggal eventDate
                const late = await Attendance.findAll({
                    where: {
                        date: eventDate,
                        clock_in: { [Op.ne]: null },
                        [Op.and]: where(fn('TIME', col('clock_in')), '>', OPEN_AT),
                    },
                    attributes: ['attendance_id', 'user_id', 'clock_in'],
                    raw: true,
                });

                if (!late.length) {
                    return {
                        inserted: 0,
                        scanned: 0,
                        skipped: 0,
                        note: 'no late attendance',
                    };
                }

                const refIds = late
                    .map((a) => a.attendance_id)
                    .filter(Boolean);

                const userByRef = new Map(
                    late.map((a) => [a.attendance_id, a.user_id]),
                );
                const clockByRef = new Map(
                    late.map((a) => [a.attendance_id, a.clock_in]),
                );

                // 2) Cek existing log biar idempotent
                const existing = await PerformanceEventLog.findAll({
                    where: {
                        perf_config_id: PERF_CONFIG_ID,
                        event_date: eventDate,
                        ref_id: { [Op.in]: refIds },
                    },
                    attributes: ['ref_id', 'user_id'],
                    raw: true,
                });

                const existed = new Set(
                    existing.map((e) => `${e.user_id}:${e.ref_id}`),
                );

                const nowUnix = Math.floor(Date.now() / 1000);
                const rows = [];
                let skipped = 0;

                for (const attendanceId of refIds) {
                    const userId = userByRef.get(attendanceId);
                    if (!userId) continue;

                    const key = `${userId}:${attendanceId}`;
                    if (existed.has(key)) {
                        skipped++;
                        continue;
                    }

                    const clockIn = clockByRef.get(attendanceId);
                    const clockStr = clockIn
                        ? dayjs(clockIn).tz(TZ).format('HH:mm:ss')
                        : null;

                    rows.push({
                        user_id: userId,
                        event_date: eventDate,
                        period_year: periodYear,
                        period_month: periodMonth,
                        period_start_date: periodStart,
                        perf_config_id: PERF_CONFIG_ID,
                        score_value: SCORE_VALUE,
                        source: 'attendance',
                        ref_id: attendanceId,
                        note: `Late to work — clock_in ${clockStr || '-'}`,
                        meta: JSON.stringify({
                            attendance_id: attendanceId,
                            clock_in: clockStr,
                            open_at: OPEN_AT,
                        }),
                        created: nowUnix,
                        updated: nowUnix,
                    });
                }

                if (dryRun) {
                    return {
                        scanned: late.length,
                        inserted: 0,
                        skipped,
                        willInsert: rows.length,
                        sample: rows.slice(0, 5),
                        dryRun: true,
                    };
                }

                let inserted = 0;
                if (rows.length) {
                    const result = await PerformanceEventLog.bulkCreate(rows, {
                        ignoreDuplicates: true,
                    });
                    inserted = Array.isArray(result) ? result.length : 0;
                }

                return {
                    inserted,
                    scanned: late.length,
                    skipped,
                };
            },
            { ttlSec: 60 },
        );

        if (res?.locked) {
            return new Response(
                JSON.stringify({
                    ok: false,
                    rule: 'late-to-work',
                    date: eventDate,
                    openAt: OPEN_AT,
                    busy: true,
                }),
                { status: 423 },
            );
        }

        return Response.json({
            ok: true,
            rule: 'late-to-work',
            date: eventDate,
            openAt: OPEN_AT,
            ...res,
            ms: Date.now() - t0,
        });
    } catch (err) {
        console.error('[cron][late-to-work]', err);
        return new Response(
            JSON.stringify({ ok: false, error: String(err?.message || err) }),
            { status: 500 },
        );
    }
}
