// src/app/api/department/[departmentId]/route.js
export const dynamic = "force-dynamic";
export const revalidate = 0;

import { NextResponse } from "next/server";
import db from "@/database/models";
import dayjs from "dayjs";
import utc from "dayjs/plugin/utc";
import { withActive } from "@/utils/session";

dayjs.extend(utc);

const { Department } = db;
const nowUnix = () => dayjs().utc().unix();

export const GET = withActive(async function GET_HANDLER(_req, { params }) {
  try {
    const id = Number(params?.departmentId);
    if (!id) return NextResponse.json({ error: "Invalid departmentId" }, { status: 400 });

    const row = await Department.findOne({ where: { department_id: id } });
    if (!row) return NextResponse.json({ error: "Not found" }, { status: 404 });

    return NextResponse.json({ department: row }, { status: 200 });
  } catch (error) {
    console.error("Error fetching department:", error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
});

export const PUT = withActive(async function PUT_HANDLER(req, { params }, currentUser) {
  try {
    const id = Number(params?.departmentId);
    if (!id) return NextResponse.json({ error: "Invalid departmentId" }, { status: 400 });

    const row = await Department.findOne({ where: { department_id: id } });
    if (!row) return NextResponse.json({ error: "Not found" }, { status: 404 });

    const body = await req.json();
    const title = String(body?.title || "").trim();
    const description = body?.description != null ? String(body.description).trim() : null;

    if (!title) return NextResponse.json({ error: "Title is required." }, { status: 400 });
    if (title.length > 100) return NextResponse.json({ error: "Title max 100 characters." }, { status: 400 });

    const userId = currentUser?.user_id || currentUser?.id || 1;
    const now = nowUnix();

    await row.update({
      title,
      description,
      updated: now,
      updated_by: userId,
    });

    return NextResponse.json({ message: "Department updated", department: row }, { status: 200 });
  } catch (error) {
    console.error("Error updating department:", error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
});

export const DELETE = withActive(async function DELETE_HANDLER(_req, { params }, currentUser) {
  try {
    const id = Number(params?.departmentId);
    if (!id) return NextResponse.json({ error: "Invalid departmentId" }, { status: 400 });

    const row = await Department.findOne({ where: { department_id: id } });
    if (!row) return NextResponse.json({ error: "Not found" }, { status: 404 });

    const userId = currentUser?.user_id || currentUser?.id || 1;
    const now = nowUnix();

    // soft delete (konsisten sama model lain yang pakai deleted/deleted_by)
    await row.update({
      deleted: now,
      deleted_by: userId,
    });

    return NextResponse.json({ message: "Department deleted" }, { status: 200 });
  } catch (error) {
    console.error("Error deleting department:", error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
});
