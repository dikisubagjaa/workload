import { Page, sequelize } from "@/database/models/website";
import { getUnixTimestampUTC } from "@/utils/dateHelpers";
import { withAuth } from "@/utils/session";

export async function GET(_, { params }) {
    try {
        await sequelize.sync();
        const page = await Page.findByPk(params.id);
        if (!page) {
            return Response.json({ message: 'Not found' }, { status: 404 });
        }
        return Response.json(page);
    } catch (error) {
        console.error('❌ GET /page/:id error:', error);
        return new Response(
            JSON.stringify({ message: 'Failed to get page', error: error.message }),
            { status: 500 }
        );
    }
}

export const PUT = withAuth(async function PUT_HANDLER(req, { params }, currentUser) {
    try {
        await sequelize.sync();
        const body = await req.json();
        const page = await Page.findByPk(params.id);
        if (!page) {
            return Response.json({ message: 'Not found' }, { status: 404 });
        }
        
        const nowUnix = getUnixTimestampUTC();
        await page.update({
            ...body,
            updated: nowUnix,
            updated_by: currentUser.user_id
        });

        return Response.json({ message: 'Updated' });
    } catch (error) {
        console.error('❌ PUT /page/:id error:', error);
        return new Response(
            JSON.stringify({ message: 'Failed to update page', error: error.message }),
            { status: 500 }
        );
    }
});

export const DELETE = withAuth(async function DELETE_HANDLER(req, { params }, currentUser) {
    try {
        await sequelize.sync();

        const page = await Page.findByPk(params.id);
        if (!page) {
            return Response.json({ message: 'Not found' }, { status: 404 });
        }

        const nowUnix = getUnixTimestampUTC();
        await Page.update(
            {
                deleted: nowUnix,
                deleted_by: currentUser.user_id
            },
            { where: { page_id: params.id } }
        );

        return Response.json({ message: 'Soft deleted' });
    } catch (error) {
        console.error('❌ DELETE /page/:id error:', error);
        return new Response(
            JSON.stringify({ message: 'Failed to delete page', error: error.message }),
            { status: 500 }
        );
    }
});

