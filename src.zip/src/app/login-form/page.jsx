// src/app/test-login/page.jsx
"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { signIn } from "next-auth/react";
import { Card, Input, Button, Alert } from "antd";

const enableTestLogin =
  process.env.NEXT_PUBLIC_ENABLE_TEST_LOGIN === "true";

export default function TestLoginPage() {
  const router = useRouter();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");

  if (!enableTestLogin) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-100">
        <Card className="shadow-lg rounded-xl">
          <div className="text-center space-y-2">
            <h1 className="text-xl font-semibold">Test Login Disabled</h1>
            <p className="text-sm text-gray-500">
              Set{" "}
              <code className="bg-slate-100 px-1 rounded">
                NEXT_PUBLIC_ENABLE_TEST_LOGIN=true
              </code>{" "}
              di <code>.env.local</code> untuk mengaktifkan halaman ini.
            </p>
          </div>
        </Card>
      </div>
    );
  }

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setSubmitting(true);

    try {
      const res = await signIn("credentials", {
        redirect: false,
        username,
        password,
        callbackUrl: "/dashboard",
      });

      // res bisa null/undefined kalau ada masalah internal
      if (!res) {
        setError("Login gagal (no response).");
        return;
      }

      if (res.error) {
        // error default dari NextAuth untuk credentials
        setError(
          res.error === "CredentialsSignin"
            ? "Username / password salah"
            : res.error
        );
        return;
      }

      // login sukses → NextAuth sudah set cookie JWT
      router.push(res.url || "/dashboard");
    } catch (err) {
      console.error("Test login client error:", err);
      setError("Terjadi kesalahan saat login.");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-100">
      <Card
        style={{ width: 360 }}
        className="shadow-2xl rounded-2xl py-8 px-6"
        classNames={{ body: "p-0" }}
      >
        <div className="text-center mb-6">
          <h1 className="text-2xl font-semibold text-slate-800">
            VP Workload – Test Login
          </h1>
          <p className="text-xs text-gray-500 mt-2">
            Halaman khusus QA / Playwright. Tidak untuk user produksi.
          </p>
        </div>

        {error && (
          <div className="mb-3">
            <Alert type="error" message={error} showIcon />
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-3">
          <div>
            <label className="block text-xs font-medium text-gray-600 mb-1">
              Username
            </label>
            <Input
              size="middle"
              placeholder={
                process.env.NEXT_PUBLIC_TEST_USER_USERNAME ||
                "TEST_USER_USERNAME"
              }
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              autoComplete="off"
              data-testid="login-email"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-gray-600 mb-1">
              Password
            </label>
            <Input.Password
              size="middle"
              placeholder="TEST_USER_PASSWORD"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              autoComplete="off"
              data-testid="login-password"
            />
          </div>

          <Button
            type="primary"
            htmlType="submit"
            loading={submitting}
            block
            data-testid="login-submit"
          >
            Sign in (Test User)
          </Button>
        </form>
      </Card>
    </div>
  );
}
