// src/app/api/calendar/events/[eventId]/route.js
export const dynamic = 'force-dynamic';
export const revalidate = 0;

import { NextResponse } from 'next/server';
import db from '@/database/models';
import dayjs from 'dayjs';
import utc from 'dayjs/plugin/utc';
import timezone from 'dayjs/plugin/timezone';
import { withActive } from '@/utils/session';

dayjs.extend(utc);
dayjs.extend(timezone);
dayjs.tz.setDefault(process.env.NEXT_PUBLIC_APP_TIMEZONE || 'Asia/Jakarta');

const { CalendarEvent } = db;

const nowUnix = () => dayjs().tz().unix();

function validHex(color) {
    if (!color) return true;
    return /^#([A-Fa-f0-9]{3}|[A-Fa-f0-9]{6})$/.test(color);
}

// ---------- PATCH /api/calendar/events/[eventId] ----------
export const PATCH = withActive(async function PATCH_HANDLER(req, { params, locals }) {
    const sessionUserId = locals?.user?.user_id;
    const eventId = Number(params?.eventId);
    if (!Number.isInteger(eventId)) {
        return NextResponse.json({ error: 'Invalid eventId' }, { status: 400 });
    }

    // load event
    const ev = await CalendarEvent.findOne({
        where: { event_id: eventId, deleted: null },
        attributes: [
            'event_id', 'user_id', 'title', 'description', 'start_at', 'end_at',
            'color', 'is_public', 'created', 'updated',
        ],
    });
    if (!ev) return NextResponse.json({ ok: false, error: 'Event not found' }, { status: 404 });


    let payload;
    try {
        payload = await req.json();
    } catch {
        return NextResponse.json({ error: 'Invalid JSON' }, { status: 400 });
    }

    const updates = {};
    if (typeof payload.title !== 'undefined') {
        const t = String(payload.title || '').trim();
        if (!t || t.length > 150) {
            return NextResponse.json({ error: 'Title is required (1..150 chars).' }, { status: 400 });
        }
        updates.title = t;
    }
    if (typeof payload.description !== 'undefined') {
        updates.description = payload.description ? String(payload.description) : null;
    }
    if (typeof payload.start_at !== 'undefined') {
        if (!Number.isInteger(Number(payload.start_at))) {
            return NextResponse.json({ error: 'start_at must be unix seconds (integer).' }, { status: 400 });
        }
        updates.start_at = Number(payload.start_at);
    }
    if (typeof payload.end_at !== 'undefined') {
        if (!Number.isInteger(Number(payload.end_at))) {
            return NextResponse.json({ error: 'end_at must be unix seconds (integer).' }, { status: 400 });
        }
        updates.end_at = Number(payload.end_at);
    }
    if (typeof updates.start_at !== 'undefined' || typeof updates.end_at !== 'undefined') {
        const a = typeof updates.start_at !== 'undefined' ? updates.start_at : ev.start_at;
        const b = typeof updates.end_at !== 'undefined' ? updates.end_at : ev.end_at;
        if (b < a) {
            return NextResponse.json({ error: 'end_at must be greater than or equal to start_at.' }, { status: 400 });
        }
    }
    if (typeof payload.color !== 'undefined') {
        const color = payload.color ? String(payload.color) : null;
        if (!validHex(color)) {
            return NextResponse.json({ error: 'Invalid color hex.' }, { status: 400 });
        }
        updates.color = color;
    }
    if (typeof payload.is_public !== 'undefined') {
        updates.is_public = !!payload.is_public;
    }

    updates.updated = nowUnix();
    await ev.update(updates);

    return NextResponse.json({ ok: true, data: ev }, { status: 200 });
});

// ---------- DELETE /api/calendar/events/[eventId] ----------
export const DELETE = withActive(async function DELETE_HANDLER(req, { params, locals }) {
    const sessionUserId = locals?.user?.user_id;
    const eventId = Number(params?.eventId);
    if (!Number.isInteger(eventId)) {
        return NextResponse.json({ error: 'Invalid eventId' }, { status: 400 });
    }

    const ev = await CalendarEvent.findOne({
        where: { event_id: eventId, deleted: null },
        attributes: ['event_id', 'user_id'],
    });
    if (!ev) return NextResponse.json({ error: 'Event not found' }, { status: 404 });

    // safety: hanya owner yang boleh hapus
    if (ev.user_id && ev.user_id !== sessionUserId) {
        return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
    }

    await ev.update({ deleted: nowUnix(), updated: nowUnix() });
    return NextResponse.json({ ok: true }, { status: 200 });
});
