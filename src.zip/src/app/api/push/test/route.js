export const dynamic = "force-dynamic";
export const revalidate = 0;

import { NextResponse } from "next/server";
import { sendPushToUser } from "@/server/push/sendPush";

export async function GET(req) {
    try {
        //const { title, body, url } = await req.json();
        let userId = 19;
        // // if (!userId) return NextResponse.json({ ok: false, error: "userId required" }, { status: 400 });
        let title = "Test Push Title";
        let body = `Hello user ${userId} 👋`;
        let url = "/notification";
        const r = await sendPushToUser(userId, {
            title: title || "Test Push",
            body: body || `Hello user ${userId} 👋`,
            data: { url: url || "/notification", type: "test" },
        });

        return NextResponse.json({ ok: true, message: "Push test endpoint is ready." });
    } catch (e) {
        return NextResponse.json({ ok: false, error: e?.message || "Internal error" }, { status: 500 });
    }
}
