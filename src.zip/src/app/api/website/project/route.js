import { Project, sequelize } from "@/database/models/website";
import dayjs from "dayjs";
import utc from "dayjs/plugin/utc";
import { getUnixTimestampUTC } from "@/utils/dateHelpers";
import { withAuth } from "@/utils/session";
dayjs.extend(utc);

// Fungsi untuk hapus tag HTML
function stripHTML(html) {
    return html ? html.replace(/<[^>]*>?/gm, "").trim() : "";
}

// GET /api/website/project
export async function GET() {
    try {
        await sequelize.sync();
        const projects = await Project.findAll({
            order: [["project_id", "DESC"]],
            raw: true 
        });

        const formattedProjects = projects.map(project => ({
            ...project,
            description: stripHTML(project.description),
            created: project.created
                ? dayjs.unix(project.created).format("YYYY-MM-DD HH:mm:ss")
                : null
        }));

        return new Response(JSON.stringify(formattedProjects), {
            status: 200,
            headers: {
                "Content-Type": "application/json",
                "Access-Control-Allow-Origin": "http://localhost:4000", // izinkan frontend
                "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
                "Access-Control-Allow-Headers": "Content-Type, Authorization",
            },
        });
    } catch (error) {
        console.error("❌ Error in GET /api/website/project:", error);
        return new Response(
            JSON.stringify({ message: "Failed to fetch projects", error: error.message }),
            { status: 500 }
        );
    }
}

// POST /api/website/project
export const POST = withAuth(async function POST_HANDLER(req, context, currentUser) {
    try {
        const nowUnix = getUnixTimestampUTC();
        const body = await req.json();

        const newProject = await Project.create({
            ...body,
            created: nowUnix,
            created_by: currentUser.user_id,
            updated: nowUnix,
            updated_by: currentUser.user_id,
        });

        // Bersihkan & format data yang baru dibuat
        const cleanProject = {
            ...newProject.get({ plain: true }),
            description: stripHTML(newProject.description),
            created: dayjs.unix(newProject.created).format("DD MMM YYYY")
        };

        return Response.json(cleanProject, { status: 201 });
    } catch (error) {
        console.error("❌ Error in POST /api/website/project:", error);
        return new Response(
            JSON.stringify({ message: "Failed to create project", error: error.message }),
            { status: 500 }
        );
    }
});
