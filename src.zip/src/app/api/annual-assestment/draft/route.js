export const dynamic = "force-dynamic";
export const revalidate = 0;

import { NextResponse } from "next/server";
import db from "@/database/models";
import { withActive } from "@/utils/session";

const {
  AnnualAssestment,
  User,
  MasterAnnualAssesmentQuestion,
  MasterAnnualAssesmentPeriod,
} = db;

const isTrue = (v) => v === "true" || v === true || v === 1 || v === "1";

function safeToPlain(val, fallback) {
  try {
    if (val == null) return fallback;
    if (typeof val === "object") return val;
    return JSON.parse(String(val));
  } catch {
    return fallback;
  }
}

async function buildQuestionsSnapshot() {
  const rows = await MasterAnnualAssesmentQuestion.findAll({
    where: {
      deleted: null,
      deleted_by: null,
      is_active: 1,
    },
    order: [
      ["section_key", "ASC"],
      ["sort_order", "ASC"],
      ["question_id", "ASC"],
    ],
    raw: true,
  });

  return (rows || []).map((q) => ({
    section_key: q.section_key,
    question_key: q.question_key,
    title: q.title,
    description: q.description,
    input_type: q.input_type,
    options_json: q.options_json,
    scale_min: q.scale_min,
    scale_max: q.scale_max,
    sort_order: q.sort_order,
  }));
}

function isPrivileged(currentUser) {
  return isTrue(currentUser?.is_superadmin) || isTrue(currentUser?.is_hrd);
}

async function getPeriodSettingForYear(year) {
  const row = await MasterAnnualAssesmentPeriod.findOne({
    where: {
      year,
      deleted: null,
      deleted_by: null,
      is_active: 1,
    },
  });
  return row ? row.toJSON() : null;
}

function getPeriodState(periodRow, now) {
  if (!periodRow) {
    return { configured: false, isOpen: false };
  }
  const openAt = Number(periodRow.open_at);
  const closeAt = Number(periodRow.close_at);

  const isOpen =
    Number.isFinite(openAt) &&
    Number.isFinite(closeAt) &&
    now >= openAt &&
    now <= closeAt;

  return { configured: true, isOpen, openAt, closeAt };
}

export const GET = withActive(async function GET_HANDLER(req, ctx, currentUser) {
  try {
    const now = Math.floor(Date.now() / 1000);

    const { searchParams } = new URL(req.url);

    // ✅ support period filter (default current year)
    const yearParam = searchParams.get("year");
    const periodToYear = yearParam ? Number(yearParam) : new Date().getFullYear();
    if (!Number.isFinite(periodToYear)) {
      return NextResponse.json({ error: "Invalid year" }, { status: 400 });
    }
    const periodFromYear = periodToYear - 1;

    // ✅ Period window
    const periodRow = await getPeriodSettingForYear(periodToYear);
    const periodState = getPeriodState(periodRow, now);

    // ✅ staff only: always create/read draft milik sendiri
    let row = await AnnualAssestment.findOne({
      where: {
        staff_id: currentUser.user_id,
        period_to_year: periodToYear,
      },
      order: [["annual_assestment_id", "DESC"]],
    });

    // =========================
    // Create draft only if open
    // =========================
    if (!row) {
      // period belum diset -> block create untuk staff biasa
      if (!periodState.configured && !isPrivileged(currentUser)) {
        return NextResponse.json(
          {
            error: `Assessment period is not configured for year ${periodToYear}. Please contact HRD.`,
            meta: { year: periodToYear },
          },
          { status: 400 }
        );
      }

      // configured tapi lagi tutup -> block create untuk staff biasa
      if (periodState.configured && !periodState.isOpen && !isPrivileged(currentUser)) {
        const msg =
          now < periodState.openAt
            ? "Assessment period is not open yet."
            : "Assessment period is closed.";

        return NextResponse.json(
          {
            error: msg,
            meta: {
              year: periodToYear,
              openAt: periodState.openAt,
              closeAt: periodState.closeAt,
              now,
            },
          },
          { status: 400 }
        );
      }

      // auto-assign HOD
      let hodId = null;
      if (currentUser.department_id) {
        const hod = await User.findOne({
          where: {
            department_id: currentUser.department_id,
            is_hod: "true",
            deleted: null,
            deleted_by: null,
          },
          order: [["user_id", "ASC"]],
        });
        hodId = hod ? hod.user_id : null;
      }

      const questionsSnapshot = await buildQuestionsSnapshot();

      row = await AnnualAssestment.create({
        period_from_year: periodFromYear,
        period_to_year: periodToYear,
        staff_id: currentUser.user_id,
        hod_id: hodId,
        status: "draft",

        // snapshot + answers
        questions_json: questionsSnapshot,
        staff_answers_json: {},
        hod_answers_json: null,

        // legacy JSON payload columns
        staff_payload_json: { answers: {} },
        hod_payload_json: null,

        created: now,
        created_by: currentUser.user_id,
        updated: now,
        updated_by: currentUser.user_id,
      });

      return NextResponse.json(
        {
          data: row,
          meta: {
            period: periodRow,
            periodState,
          },
        },
        { status: 200 }
      );
    }

    // =========================
    // Backfill untuk row lama
    // =========================
    const updates = {};

    if (!row.questions_json) {
      updates.questions_json = await buildQuestionsSnapshot();
    }

    if (!row.staff_answers_json) {
      const staffPayload = safeToPlain(row.staff_payload_json, null);
      const staffAns = staffPayload?.answers || null;
      if (staffAns) updates.staff_answers_json = staffAns;
    }

    if (!row.hod_answers_json) {
      const hodPayload = safeToPlain(row.hod_payload_json, null);
      const hodAns = hodPayload?.answers || null;
      if (hodAns) updates.hod_answers_json = hodAns;
    }

    if (!row.staff_payload_json) {
      updates.staff_payload_json = { answers: {} };
    }

    if (Object.keys(updates).length) {
      updates.updated = now;
      updates.updated_by = currentUser.user_id;
      await row.update(updates);
    }

    return NextResponse.json(
      {
        data: row,
        meta: {
          period: periodRow,
          periodState,
        },
      },
      { status: 200 }
    );
  } catch (error) {
    console.error("GET /annual-assestment/draft error:", error);
    return NextResponse.json(
      { error: error?.message || "Internal error" },
      { status: 500 }
    );
  }
});
