// src/app/api/leave/[leaveId]/route.js
export const dynamic = "force-dynamic";
export const revalidate = 0;

import { NextResponse } from "next/server";
import db from "@/database/models";
import dayjs from "dayjs";
import { withActive } from "@/utils/session";
import { notify as notifyUser } from "@/utils/notifier";

const { LeaveRequest } = db;

// =========================
// GET /api/leave/[leaveId]
// =========================
export const GET = withActive(async function GET_HANDLER(req, { params }, currentUser) {
  try {
    const uid = Number(currentUser?.user_id || 0);
    if (!uid) return NextResponse.json({ error: "Unauthenticated" }, { status: 401 });

    const leaveId = Number(params?.leaveId || params?.id || params?.leave_id || 0);
    if (!leaveId) return NextResponse.json({ error: "Invalid id" }, { status: 400 });

    const row = await LeaveRequest.findOne({ where: { leave_id: leaveId, deleted: null } });
    if (!row) return NextResponse.json({ error: "Not found" }, { status: 404 });

    const isSuperadmin = currentUser?.is_superadmin === "true";
    const isHrd = currentUser?.is_hrd === "true";

    const allow =
      Number(row.user_id || 0) === uid ||
      Number(row.assign_to || 0) === uid ||
      Number(row.hod || 0) === uid ||
      Number(row.hrd || 0) === uid ||
      Number(row.operational_director || 0) === uid ||
      isSuperadmin ||
      isHrd;

    if (!allow) return NextResponse.json({ error: "Forbidden" }, { status: 403 });

    return NextResponse.json({ ok: true, data: row.toJSON() }, { status: 200 });
  } catch (err) {
    console.error("GET /api/leave/[leaveId] error:", err);
    return NextResponse.json({ error: err?.message || "Failed" }, { status: 500 });
  }
});

// =========================
// POST /api/leave/[leaveId]
// body:
// - { action:"cancel" }
// - { action:"set_approver", hrd, operational_director }
// - { action:"approve", target? }  // target only for superadmin: assign_to|hod|hrd|operational_director
// - { action:"reject", target?  }
// =========================
export const POST = withActive(async function POST_HANDLER(req, { params }, currentUser) {
  try {
    const uid = Number(currentUser?.user_id || 0);
    if (!uid) return NextResponse.json({ error: "Unauthenticated" }, { status: 401 });

    const leaveId = Number(params?.leaveId || params?.id || params?.leave_id || 0);
    if (!leaveId) return NextResponse.json({ error: "Invalid id" }, { status: 400 });

    const isSuperadmin = currentUser?.is_superadmin === "true";
    const isHrd = currentUser?.is_hrd === "true";
    const isDirectorOperational = currentUser?.is_director_operational === "true";

    const body = await req.json();
    const action = String(body?.action || "").toLowerCase();
    const target = body?.target ? String(body.target).toLowerCase() : null; // only for superadmin

    const row = await LeaveRequest.findOne({ where: { leave_id: leaveId, deleted: null } });
    if (!row) return NextResponse.json({ error: "Not found" }, { status: 404 });

    const now = dayjs().unix();
    const actorName = currentUser?.fullname || currentUser?.email || `User #${uid}`;
    const requesterId = Number(row.user_id || 0);

    const reasonStr = row.reason || "-";
    const rangeStr = `${row.start_date} → ${row.end_date}`;
    const url = "/leave";

    const approverIds = Array.from(
      new Set(
        [row.assign_to, row.hod, row.hrd, row.operational_director]
          .map((x) => Number(x || 0))
          .filter((x) => x > 0)
      )
    );

    const currentStatus = String(row.status || "").toLowerCase();
    if (["approved", "rejected", "cancelled"].includes(currentStatus)) {
      return NextResponse.json({ error: `Request already ${row.status}` }, { status: 400 });
    }

    // =========================
    // CANCEL (requester only)
    // =========================
    if (action === "cancel") {
      if (Number(row.user_id || 0) !== uid) return NextResponse.json({ error: "Forbidden" }, { status: 403 });

      row.status = "cancelled";
      row.updated = now;
      row.updated_by = uid;
      await row.save();

      for (const toId of approverIds) {
        try {
          await notifyUser({
            userId: toId,
            sender: "system",
            description: `${actorName} cancelled leave (${reasonStr}) for ${rangeStr}.`,
            url,
            payload: { type: "leave_cancelled", leaveId: row.leave_id },
          });
        } catch (e) {
          console.warn("notify cancel failed:", e?.message || e);
        }
      }

      return NextResponse.json({ ok: true, data: row.toJSON() }, { status: 200 });
    }

    // =========================
    // SET APPROVER (superadmin/hrd/director_operational)
    // =========================
    if (action === "set_approver") {
      const canSet = isSuperadmin || isHrd || isDirectorOperational;
      if (!canSet) return NextResponse.json({ error: "Forbidden" }, { status: 403 });

      if (body?.hrd !== undefined) {
        const nextHrd = Number(body.hrd || 0);
        row.hrd = nextHrd > 0 ? nextHrd : null;
        row.approval_hrd_status = "pending";
        row.approval_hrd_at = null;
      }

      if (body?.operational_director !== undefined) {
        const nextDir = Number(body.operational_director || 0);
        row.operational_director = nextDir > 0 ? nextDir : null;
        row.approval_operational_director_status = "pending";
        row.approval_operational_director_at = null;
      }

      row.updated = now;
      row.updated_by = uid;
      await row.save();

      try {
        await notifyUser({
          userId: requesterId,
          sender: "system",
          description: `Approver updated by ${actorName} for leave (${reasonStr}) ${rangeStr}.`,
          url,
          payload: { type: "leave_approver_updated", leaveId: row.leave_id },
        });
      } catch (e) {
        console.warn("notify requester failed:", e?.message || e);
      }

      if (row.hrd) {
        try {
          await notifyUser({
            userId: Number(row.hrd),
            sender: "system",
            description: `Leave (${reasonStr}) for ${rangeStr} needs your approval (HRD).`,
            url,
            payload: { type: "leave_need_approval_hrd", leaveId: row.leave_id },
          });
        } catch (e) {
          console.warn("notify hrd failed:", e?.message || e);
        }
      }

      if (row.operational_director) {
        try {
          await notifyUser({
            userId: Number(row.operational_director),
            sender: "system",
            description: `Leave (${reasonStr}) for ${rangeStr} needs your approval (Director).`,
            url,
            payload: { type: "leave_need_approval_director", leaveId: row.leave_id },
          });
        } catch (e) {
          console.warn("notify director failed:", e?.message || e);
        }
      }

      return NextResponse.json({ ok: true, data: row.toJSON() }, { status: 200 });
    }

    // =========================
    // APPROVE / REJECT (Pola A)
    // - detect scope from row (no scope from FE)
    // - superadmin must pass target
    // =========================
    if (action !== "approve" && action !== "reject") {
      return NextResponse.json({ error: "Unsupported action" }, { status: 400 });
    }

    let scope = null;

    if (Number(row.assign_to || 0) === uid) scope = "assign_to";
    else if (Number(row.hod || 0) === uid) scope = "hod";
    else if (Number(row.hrd || 0) === uid) scope = "hrd";
    else if (Number(row.operational_director || 0) === uid) scope = "operational_director";
    else if (isSuperadmin) scope = target || null;

    if (!scope || !["assign_to", "hod", "hrd", "operational_director"].includes(scope)) {
      return NextResponse.json(
        { error: isSuperadmin ? "Superadmin must provide target" : "Forbidden" },
        { status: isSuperadmin ? 400 : 403 }
      );
    }

    // extra guard for HRD
    if (!isSuperadmin && scope === "hrd") {
      if (!(isHrd && Number(row.hrd || 0) === uid)) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    }

    // superadmin: jangan approve role yang tidak ada
    if (isSuperadmin) {
      if (scope === "assign_to" && !Number(row.assign_to || 0)) return NextResponse.json({ error: "No assign_to" }, { status: 400 });
      if (scope === "hod" && !Number(row.hod || 0)) return NextResponse.json({ error: "No hod" }, { status: 400 });
      if (scope === "hrd" && !Number(row.hrd || 0)) return NextResponse.json({ error: "No hrd" }, { status: 400 });
      if (scope === "operational_director" && !Number(row.operational_director || 0)) {
        return NextResponse.json({ error: "No operational_director" }, { status: 400 });
      }
    }

    // apply approve/reject to the scope column
    if (action === "approve") {
      if (scope === "assign_to") {
        row.approval_assign_to_status = "approved";
        row.approval_assign_to_at = now;
      } else if (scope === "hod") {
        row.approval_hod_status = "approved";
        row.approval_hod_at = now;
      } else if (scope === "hrd") {
        row.approval_hrd_status = "approved";
        row.approval_hrd_at = now;
      } else if (scope === "operational_director") {
        row.approval_operational_director_status = "approved";
        row.approval_operational_director_at = now;
      }
    } else {
      if (scope === "assign_to") {
        row.approval_assign_to_status = "rejected";
        row.approval_assign_to_at = now;
      } else if (scope === "hod") {
        row.approval_hod_status = "rejected";
        row.approval_hod_at = now;
      } else if (scope === "hrd") {
        row.approval_hrd_status = "rejected";
        row.approval_hrd_at = now;
      } else if (scope === "operational_director") {
        row.approval_operational_director_status = "rejected";
        row.approval_operational_director_at = now;
      }
    }

    // ====== FINAL STATUS (Pola A) ======
    // Final APPROVED hanya jika semua approver yang diisi sudah approved.
    // Final REJECTED jika salah satu approver reject.
    // Selain itu: pending.
    const needAssign = Number(row.assign_to || 0) > 0;
    const needHod = Number(row.hod || 0) > 0;
    const needHrd = Number(row.hrd || 0) > 0;
    const needDir = Number(row.operational_director || 0) > 0;

    const stAssign = String(row.approval_assign_to_status || "pending").toLowerCase();
    const stHod = String(row.approval_hod_status || "pending").toLowerCase();
    const stHrd = String(row.approval_hrd_status || "pending").toLowerCase();
    const stDir = String(row.approval_operational_director_status || "pending").toLowerCase();

    const anyReject =
      (needAssign && stAssign === "rejected") ||
      (needHod && stHod === "rejected") ||
      (needHrd && stHrd === "rejected") ||
      (needDir && stDir === "rejected");

    if (anyReject) {
      row.status = "rejected";
    } else {
      const allApproved =
        (!needAssign || stAssign === "approved") &&
        (!needHod || stHod === "approved") &&
        (!needHrd || stHrd === "approved") &&
        (!needDir || stDir === "approved");

      row.status = allApproved ? "approved" : "pending";
    }

    row.updated = now;
    row.updated_by = uid;
    await row.save();

    // notif requester
    try {
      if (String(row.status).toLowerCase() === "approved") {
        await notifyUser({
          userId: requesterId,
          sender: "system",
          description: `Your leave (${reasonStr}) for ${rangeStr} is fully approved.`,
          url,
          payload: { type: "leave_final_approved", leaveId: row.leave_id },
        });
      } else if (String(row.status).toLowerCase() === "rejected") {
        await notifyUser({
          userId: requesterId,
          sender: "system",
          description: `Your leave (${reasonStr}) for ${rangeStr} was rejected by ${actorName}.`,
          url,
          payload: { type: "leave_rejected", leaveId: row.leave_id, scope },
        });
      } else {
        await notifyUser({
          userId: requesterId,
          sender: "system",
          description:
            action === "approve"
              ? `Your leave (${reasonStr}) for ${rangeStr} was approved by ${actorName}. (Waiting others)`
              : `Your leave (${reasonStr}) for ${rangeStr} was updated by ${actorName}.`,
          url,
          payload: { type: "leave_progress_updated", leaveId: row.leave_id, scope, status: row.status },
        });
      }
    } catch (e) {
      console.warn("notify requester failed:", e?.message || e);
    }

    // notif approver lain (FYI) kalau reject biar semua tau
    if (String(row.status).toLowerCase() === "rejected") {
      for (const toId of approverIds) {
        if (toId === uid) continue;
        try {
          await notifyUser({
            userId: toId,
            sender: "system",
            description: `Leave (${reasonStr}) for ${rangeStr} was rejected by ${actorName}.`,
            url,
            payload: { type: "leave_rejected_fyi", leaveId: row.leave_id, scope },
          });
        } catch (e) {
          console.warn("notify reject fyi failed:", e?.message || e);
        }
      }
    }

    return NextResponse.json({ ok: true, data: row.toJSON() }, { status: 200 });
  } catch (err) {
    console.error("POST /api/leave/[leaveId] error:", err);
    return NextResponse.json({ error: err?.message || "Failed" }, { status: 500 });
  }
});
