// src/app/api/appraisal/route.js  (LIST)
export const dynamic = "force-dynamic";
export const revalidate = 0;

import { NextResponse } from "next/server";
import db from "@/database/models";
import { withActive } from "@/utils/session";
import {
  parseIntParam,
  parseOrder,
  isTrue,
  getStaffIdField,
  getDepartmentIdField,
  buildJsonSearchWhere,
} from "./_helper";

const { Sequelize, Appraisal } = db;
const { Op } = Sequelize;

function getDeptIdFromUser(u) {
  const v = u?.department_id;
  return v == null ? null : Number(v);
}

export const GET = withActive(async function GET_HANDLER(req, ctx, currentUser) {
  try {
    const { searchParams } = new URL(req.url);

    const page = Math.max(1, parseIntParam(searchParams.get("page"), 1));
    const limit = Math.min(100, Math.max(1, parseIntParam(searchParams.get("limit"), 10)));
    const offset = (page - 1) * limit;

    const q = (searchParams.get("q") || "").trim();
    let status = (searchParams.get("status") || "").trim(); // draft|submitted|approved|rejected
    const title = (searchParams.get("title") || "").trim();
    const deptIdParam = searchParams.get("department_id");
    const staffIdParam = searchParams.get("staffId"); // optional

    const order = parseOrder(searchParams.get("sortBy"), searchParams.get("sortDir"));

    const staffIdField = getStaffIdField();
    const deptField = getDepartmentIdField();

    const superadmin = isTrue(currentUser?.is_superadmin);
    const isHod = isTrue(currentUser?.is_hod);
    const isHrd = isTrue(currentUser?.is_hrd);
    const isDirector = isTrue(currentUser?.is_operational_director);

    const myId = Number(currentUser?.user_id);

    const where = {
      deleted: { [Op.is]: null },
      deleted_by: { [Op.is]: null },
    };

    // ✅ Default view mode:
    // - staff biasa: hanya miliknya sendiri
    // - HOD: non-draft (default: submitted step=hod)
    // - HRD: non-draft (default: submitted step=hrd)
    // - Director: non-draft (default: submitted step=director)
    // - superadmin: bebas
    const isApprover = isHod || isHrd || isDirector;

    if (!superadmin && !isApprover) {
      // staff biasa
      //where[staffIdField] = myId;
    } else {
      // approver / superadmin
      // jangan tampilkan draft untuk approver (draft itu kerjaan superadmin)
      // if (!status) {
      //   status = "submitted";
      // }
      // if (!superadmin && status === "submitted") {
      //   // auto fokus ke step masing-masing biar list bersih
      //   if (isHod && !isHrd && !isDirector) where.current_step = "hod";
      //   if (isHrd && !isDirector) where.current_step = "hrd";
      //   if (isDirector) where.current_step = "director";
      // }
    }

    // optional staffId filter
    if (staffIdParam) {
      const staffId = Number(staffIdParam);
      if (!Number.isFinite(staffId)) return NextResponse.json({ error: "Invalid staffId" }, { status: 400 });
      if (!superadmin && staffId !== myId) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
      where[staffIdField] = staffId;
    }

    if (status) where.status = status;
    if (title) where.title = title;

    // department filter
    if (deptIdParam) {
      const deptId = Number(deptIdParam);
      if (!Number.isFinite(deptId)) {
        return NextResponse.json({ error: "Invalid department_id" }, { status: 400 });
      }

      if (deptField) {
        where[deptField] = deptId;
      } else {
        where[Op.and] = [
          ...(Array.isArray(where[Op.and]) ? where[Op.and] : []),
          Sequelize.where(Sequelize.json("staff_snapshot_json.department_id"), deptId),
        ];
      }
    } else {
      // ✅ HOD default: batasi dept sendiri (kalau ada dept_id)
      if (!superadmin && isHod && !isHrd && !isDirector) {
        const myDept = getDeptIdFromUser(currentUser);
        if (myDept != null) {
          where[Op.and] = [
            ...(Array.isArray(where[Op.and]) ? where[Op.and] : []),
            Sequelize.where(Sequelize.json("staff_snapshot_json.department_id"), myDept),
          ];
        }
      }
    }

    // q search
    const jsonSearch = buildJsonSearchWhere(q);
    if (jsonSearch) {
      where[Op.and] = [
        ...(Array.isArray(where[Op.and]) ? where[Op.and] : []),
        jsonSearch,
      ];
    }

    const { rows, count } = await Appraisal.findAndCountAll({
      where,
      order,
      limit,
      offset,
    });

    return NextResponse.json({ ok: true, data: rows, meta: { page, limit, total: count } }, { status: 200 });
  } catch (error) {
    console.error("GET /api/appraisal error:", error);
    return NextResponse.json({ error: error?.message || "Failed to fetch appraisal list." }, { status: 500 });
  }
});
