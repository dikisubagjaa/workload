import { Button } from 'antd';

export default function Step1_ChooseClientType({ onSelectType }) {
    return (
        <div className="flex flex-col items-center py-5">
            <h4 className="text-xl fc-base mb-5">Is it a new client?</h4>
            <div className="flex gap-3">
                <Button htmlType='button' size='large' onClick={() => onSelectType('existclient')}>
                    No
                </Button>
                <Button htmlType='button' size='large' className="btn-success" onClick={() => onSelectType('newclient')}>
                    Yes
                </Button>
            </div>
        </div>
    );
}