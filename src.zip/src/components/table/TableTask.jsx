"use client";
import { useMemo, useState, useCallback } from "react";
import { Select, Table, Skeleton } from "antd";
import ModalTotalTime from "@components/modal/ModalTotalTIme";
import { useMobileQuery } from "../libs/UseMediaQuery";
import dayjs from "dayjs";
import utc from "dayjs/plugin/utc";
import relativeTime from "dayjs/plugin/relativeTime";
import { useRouter } from "next/navigation";
import { useSession } from "next-auth/react";
import { setTaskFocusItem } from "@/utils/focusItemStore";

dayjs.extend(utc);
dayjs.extend(relativeTime);

// ===== Helpers =====

const colorMap = {
  black: "#000000",
  white: "#FFFFFF",
  red: "#EC221F",
  yellow: "#E8B931",
  green: "#14AE5C",
  purple: "#D42DA4",
};

/** Normalize due date to dayjs (supports unix sec/ms or ISO) */
const toDayjsDate = (value) => {
  if (value == null) return null;
  if (typeof value === "number") {
    // 10-digit: seconds, 13-digit: milliseconds
    return value < 10_000_000_000 ? dayjs.unix(value) : dayjs(value);
  }
  return dayjs(value);
};

/**
 * Color by due date diff (H = days to due):
 * - H+ (overdue)          -> red
 * - H-0 .. H-3 (≤3 days)  -> yellow
 * - H-4 and earlier       -> green
 */
const renderColorTodo = (dueDate) => {
  const d = toDayjsDate(dueDate);
  if (!d || !d.isValid()) return colorMap.black;

  const today = dayjs().startOf("day");
  const diffDays = d.startOf("day").diff(today, "day");

  if (diffDays < 0) return colorMap.red;
  if (diffDays <= 3) return colorMap.yellow;
  return colorMap.green;
};

const toUnix = (v) => (typeof v === "number" ? v : Number(v));

const fmtDate = (unixSec) =>
  Number.isFinite(unixSec) ? dayjs.unix(unixSec).format("ddd, D MMM YY") : "-";

const fmtDueTime = (unixSec) => {
  if (!Number.isFinite(unixSec)) return "-";
  const due = dayjs.unix(unixSec);
  const now = dayjs();
  return due.isBefore(now) ? due.from(now) : `in ${now.to(due, true)}`;
};

/**
 * Status locked for STAFF (cannot change from these).
 * Revision is represented by revise_hod / revise_account.
 */
const STAFF_LOCKED_STATUSES = [
  "revise_account",
  "need_review_hod",
  "need_review_ae",
  "revise_hod",
  "revise_account",
  "approved_ae",
  "completed",
  "pending",
  "cancel",
  "todo",
  "review",
  "done",
];

/**
 * Build TODO options for desktop Select based on role.
 *
 * STAFF:
 *   - New (new)
 *   - In Progress (in_progress)
 *   - Need Review HOD (need_review_hod)
 *
 * ACCOUNT (AE):
 *   - Need Review AE (need_review_ae)
 *   - Revise Account (revise_account)
 *   - Approve AE (approved_ae)
 *   - Completed (completed)
 *
 * NOTE:
 * - revise_hod & revise_account are NOT static options here.
 *   We inject them dynamically per-row (as a single "Revision" option) if needed.
 */
const buildDesktopTodoOptions = (isAccount) => {
  if (isAccount) {
    // ACCOUNT / AE
    return [
      { value: "need_review_ae", label: "Need Review AE" },
      { value: "revise_account", label: "Revise Account" },
      { value: "approved_ae", label: "Approve AE" },
      { value: "completed", label: "Completed" },
    ];
  }

  // STAFF
  return [
    { value: "new", label: "New" },
    { value: "in_progress", label: "In Progress" },
    { value: "need_review_hod", label: "Need Review HOD" },
  ];
};

/**
 * Build TODO options for mobile Select based on role.
 */
const buildMobileTodoOptions = (isAccount) => {
  if (isAccount) {
    return [
      { value: "need_review_ae", label: "Need Review AE" },
      { value: "revise_account", label: "Revise Account" },
      { value: "approved_ae", label: "Approve AE" },
      { value: "completed", label: "Completed" },
    ];
  }

  return [
    { value: "new", label: "New" },
    { value: "in_progress", label: "In Progress" },
    { value: "need_review_hod", label: "Need Review HOD" },
  ];
};

const isRevisionStatus = (todo) =>
  todo === "revise_hod" || todo === "revise_account";

// ===== Desktop columns =====
const makeDesktopColumns = (
  onOpenTotalTime,
  onChangeStatus,
  onOpenTaskDetail,
  baseTodoOptions,
  isAccount
) => [
    {
      title: "Task Name",
      dataIndex: "name",
      key: "taskName",
      className: "h-full",
      render: (_v, record) => {
        const due = record.end_date;
        return (
          <div className="flex items-center gap-5">
            <div
              className="w-2 rounded-full min-h-12"
              style={{ backgroundColor: renderColorTodo(due) }}
            />
            <div className="flex flex-col gap-2">
              <button
                type="button"
                onClick={(e) => {
                  e.preventDefault();
                  e.stopPropagation();
                  onOpenTaskDetail?.(record);
                }}
                className="text-left text-sm font-medium text-[#0FA3B1] hover:underline decoration-dotted hover:decoration-solid"
                title="Open task detail"
              >
                {record.title}
              </button>
            </div>
          </div>
        );
      },
    },
    {
      title: "Version",
      dataIndex: "version",
      key: "version",
      render: (_v, record) => (
        <p className="text-sm text-[#383F50]">{record.last_version ?? "-"}</p>
      ),
    },
    {
      title: "Project Name",
      dataIndex: "projectClient",
      key: "projectClient",
      render: (_v, record) => (
        <p className="text-sm text-[#383F50]">{record.projectClient || "-"}</p>
      ),
    },
    {
      title: "Start Date",
      dataIndex: "startTime",
      key: "startTime",
      render: (_v, record) => (
        <p className="text-sm font-normal text-[#383F50]">
          {fmtDate(toUnix(record.start_date))}
        </p>
      ),
    },
    {
      title: "Due Date",
      dataIndex: "dueDate",
      key: "dueDateReview",
      render: (_v, record) => (
        <p className="text-sm font-normal text-[#383F50]">
          {fmtDate(toUnix(record.end_date))}
        </p>
      ),
    },
    {
      title: "Status",
      dataIndex: "status",
      key: "status",
      width: "15%",
      render: (_v, record) => {
        const current = record.todo;

        // Base disabled rule
        let disabledBase = false;
        if (!isAccount) {
          disabledBase = STAFF_LOCKED_STATUSES.includes(current);
        }

        const disabledCheck =
          record.btnCheck !== undefined && record.btnCheck !== null
            ? record.btnCheck
            : disabledBase;

        // Inject dynamic "Revision" option when needed
        let options = baseTodoOptions;
        if (isRevisionStatus(current)) {
          options = [
            { value: current, label: "Revision", disabled: true },
            ...baseTodoOptions,
          ];
        }

        return (
          <div className="flex items-center gap-5">
            <Select
              className="text-gray-400 w-40"
              value={current}
              options={options}
              onChange={(val) => onChangeStatus?.(record, val)}
              disabled={disabledCheck}
            />
          </div>
        );
      },
    },
  ];

// ===== Mobile =====
const MobileColumns = (
  onOpenTotalTime,
  onChangeStatus,
  onOpenTaskDetail,
  baseTodoOptions,
  isAccount
) => [
    {
      title: "Task Name",
      dataIndex: "name",
      key: "taskName",
      className: "h-full",
      colSpan: 2,
      align: "left",
      render: (_v, record) => {
        const due = record.end_date;

        let disabledBase = false;
        if (!isAccount) {
          disabledBase = STAFF_LOCKED_STATUSES.includes(record.todo);
        }
        const disabledCheck =
          record.btnCheck !== undefined && record.btnCheck !== null
            ? record.btnCheck
            : disabledBase;

        let options = baseTodoOptions;
        if (isRevisionStatus(record.todo)) {
          options = [
            { value: record.todo, label: "Revision", disabled: true },
            ...baseTodoOptions,
          ];
        }

        return (
          <div className="flex items-center gap-5">
            <div
              className="w-2 rounded-full min-h-12"
              style={{ backgroundColor: renderColorTodo(due) }}
            />
            <div className="flex flex-col gap-2">
              <button
                type="button"
                onClick={(e) => {
                  e.preventDefault();
                  e.stopPropagation();
                  onOpenTaskDetail?.(record);
                }}
                className="text-left text-sm font-medium text-[#0FA3B1] hover:underline decoration-dotted hover:decoration-solid"
                title="Open task detail"
              >
                {record.title}
              </button>

              <div className="text-xs text-[#383F50]">
                <div>Project: {record.projectClient || "-"}</div>
                <div>
                  Due:{" "}
                  {record.end_date
                    ? `${fmtDate(toUnix(record.end_date))} (${fmtDueTime(
                      toUnix(record.end_date)
                    )})`
                    : "-"}
                </div>
                <div>Status: {record.todo}</div>
              </div>

              <div className="flex items-center gap-3 mt-2">
                <Select
                  className="text-gray-400 w-40"
                  value={record.todo}
                  options={options}
                  onChange={(val) => onChangeStatus?.(record, val)}
                  disabled={disabledCheck}
                />
              </div>
            </div>
          </div>
        );
      },
    },
  ];

const ExpandTable = ({ record }) => (
  <ul className="flex flex-col gap-4">
    <li>
      <h3 className="text-sm font-semibold mb-2">Version</h3>
      <p className="text-sm text-[#383F50]">{record.version ?? "-"}</p>
    </li>
    <li>
      <h3 className="text-sm font-semibold mb-2">Project Name</h3>
      <p className="text-sm text-[#383F50]">{record.projectClient || "-"}</p>
    </li>
    <li>
      <h3 className="text-sm font-semibold mb-2">Start Time</h3>
      <p className="text-sm font-normal text-[#383F50]">
        {record.start_date
          ? `${fmtDate(toUnix(record.start_date))} (${fmtDueTime(
            toUnix(record.start_date)
          )})`
          : "-"}
      </p>
    </li>
    <li>
      <h3 className="text-sm font-semibold mb-2">Due Date</h3>
      <p className="text-sm font-normal text-[#383F50]">
        {record.end_date
          ? `${fmtDate(toUnix(record.end_date))} (${fmtDueTime(
            toUnix(record.end_date)
          )})`
          : "-"}
      </p>
    </li>
  </ul>
);

export default function TableTask({
  dataTask = [],
  loading = false,
  onChangeStatus,
  onOpenTotalTime,
}) {
  const [modalTotalTime, setModalTotalTime] = useState(false);
  const [selectedTask, setSelectedTask] = useState(null);
  const isMobile = useMobileQuery();
  const router = useRouter();
  const { data: session } = useSession();

  const userRole = session?.user?.user_role;
  const isAccount = userRole === "account";

  const desktopTodoOptions = useMemo(
    () => buildDesktopTodoOptions(isAccount),
    [isAccount]
  );

  const mobileTodoOptions = useMemo(
    () => buildMobileTodoOptions(isAccount),
    [isAccount]
  );

  const handleOpenTotalTime = (open, task) => {
    setSelectedTask(open ? task : null);
    setModalTotalTime(open);
    onOpenTotalTime?.(open, task);
  };

  const handleOpenTaskDetail = useCallback(
    (task) => {
      const taskId = task?.task_id;
      if (!taskId) return;

      let url = `/dashboard?modul=task&openmodal=true&task=${encodeURIComponent(
        taskId
      )}`;

      const parentId = task?.parent_id;
      if (parentId) {
        setTaskFocusItem(parentId, taskId);
        url = `/dashboard?modul=task&openmodal=true&task=${encodeURIComponent(
          parentId
        )}`;
      }

      router.push(url);
    },
    [router]
  );

  const columns = useMemo(
    () =>
      isMobile
        ? MobileColumns(
          handleOpenTotalTime,
          onChangeStatus,
          handleOpenTaskDetail,
          mobileTodoOptions,
          isAccount
        )
        : makeDesktopColumns(
          handleOpenTotalTime,
          onChangeStatus,
          handleOpenTaskDetail,
          desktopTodoOptions,
          isAccount
        ),
    [
      isMobile,
      onChangeStatus,
      handleOpenTaskDetail,
      handleOpenTotalTime,
      desktopTodoOptions,
      mobileTodoOptions,
      isAccount,
    ]
  );

  return (
    <>
      <Table
        dataSource={dataTask}
        columns={columns}
        rowKey={(r) => r.task_id ?? r.key}
        scroll={isMobile ? undefined : { x: "max-content" }}
        pagination={false}
        loading={{
          spinning: loading,
          tip: "Loading tasks...",
          indicator: <Skeleton active title paragraph={false} />,
        }}
        expandable={
          isMobile
            ? { expandedRowRender: (record) => <ExpandTable record={record} /> }
            : undefined
        }
      />

      <ModalTotalTime
        modalTotalTime={modalTotalTime}
        setModalTotalTime={setModalTotalTime}
        task={selectedTask}
      />
    </>
  );
}
