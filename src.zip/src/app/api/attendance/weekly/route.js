// src/app/api/attendance/weekly/route.js
export const dynamic = "force-dynamic";
export const revalidate = 0;

import { NextResponse } from "next/server";
import db from "@/database/models";
const { Attendance, User } = db;

import dayjs from "dayjs";
import utc from "dayjs/plugin/utc";
import timezone from "dayjs/plugin/timezone";
import { withAuth } from "@/utils/session";

dayjs.extend(utc);
dayjs.extend(timezone);
const SAFE_TZ = (process.env.NEXT_PUBLIC_APP_TIMEZONE || "Asia/Jakarta")
  .replace(/['"]/g, "")
  .trim();
dayjs.tz.setDefault(SAFE_TZ);

// Helper format jam "HH.mm" meski source TIME/DATETIME/string/UNIX seconds
function fmtTime(val, tz = SAFE_TZ) {
  if (val == null || val === "") return "";

  // Jika number atau numeric string → anggap UNIX seconds
  if (typeof val === "number" || /^\d+$/.test(String(val))) {
    const n = Number(val);
    if (Number.isFinite(n)) return dayjs.unix(n).tz(tz).format("HH.mm");
  }

  // Coba pola string umum
  const tryFormats = ["HH:mm:ss", "HH:mm", "YYYY-MM-DD HH:mm:ss", "YYYY-MM-DDTHH:mm:ssZ"];
  for (const f of tryFormats) {
    const d = dayjs(val, f, true);
    if (d.isValid()) return d.tz(tz).format("HH.mm");
  }

  // Fallback
  const d = dayjs(val);
  return d.isValid() ? d.tz(tz).format("HH.mm") : "";
}

function dayShort(d) {
  const map = { Mon: "Mon", Tue: "Tue", Wed: "Wed", Thu: "Thurs", Fri: "Fri", Sat: "Sat", Sun: "Sun" };
  const key = dayjs(d).format("ddd");
  return map[key] || key;
}

// di atas: helper & konstanta warna
const GREEN = "#14AE5C";
const YELLOW = "#E8B931";
const RED = "#EC221F";
const LATE_CUTOFF = process.env.NEXT_PUBLIC_LATE_CUTOFF || "10:00"; // HH:mm

function toMinutesFromAny(val) {
  if (val == null || val === "") return null;
  // numeric (unix detik)
  if (typeof val === "number" || /^\d+$/.test(String(val))) {
    const n = Number(val);
    // treat as unix seconds → ke menit dalam hari
    const date = dayjs.unix(n).tz("Asia/Jakarta");
    return date.hour() * 60 + date.minute();
  }
  // string "HH:mm" / "HH.mm"
  const s = String(val).trim().replace(".", ":");
  const m = /^(\d{1,2}):(\d{2})$/.exec(s);
  if (!m) return null;
  const hh = Number(m[1]),
    mm = Number(m[2]);
  if (hh < 0 || hh > 23 || mm < 0 || mm > 59) return null;
  return hh * 60 + mm;
}

function hhmmToMinutes(hhmm) {
  const m = /^(\d{1,2}):(\d{2})$/.exec(hhmm);
  if (!m) return null;
  return Number(m[1]) * 60 + Number(m[2]);
}

function isTruthy(v) {
  return v === true || v === "true" || v === 1 || v === "1";
}

export const GET = withAuth(async function GET_HANDLER(req, ctx, currentUser) {
  try {
    // ===== staff override (superadmin only) =====
    const url = new URL(req.url);
    const staffIdParam = url.searchParams.get("staffId");
    const isSuperadmin = isTruthy(currentUser?.is_superadmin);

    let effectiveUserId = currentUser.user_id;

    if (isSuperadmin && staffIdParam) {
      const parsed = parseInt(staffIdParam, 10);
      if (!Number.isNaN(parsed) && parsed > 0) {
        const targetUser = await User.findOne({
          where: { user_id: parsed },
          attributes: ["user_id"],
        });

        if (!targetUser) {
          return NextResponse.json({ error: "Staff tidak ditemukan" }, { status: 404 });
        }

        effectiveUserId = targetUser.user_id;
      }
    }

    // Cari tanggal attendance PERDANA user (paling awal)
    const first = await Attendance.findOne({
      where: { user_id: effectiveUserId },
      attributes: ["date"],
      order: [["date", "ASC"]],
    });

    // Kalau belum pernah absen sama sekali → kosongkan saja biar gak misleading
    if (!first) {
      return NextResponse.json({ weekly: [] }, { status: 200 });
    }

    const today = dayjs().tz(SAFE_TZ).startOf("day");
    const firstDate = dayjs(first.date).tz(SAFE_TZ).startOf("day");

    // Window 7 hari terakhir dihitung mundur dari hari ini.
    // Tapi kalau firstDate masih dalam 7 hari terakhir, start-nya digeser ke firstDate.
    const sevenDaysAgo = today.subtract(6, "day"); // total 7 hari: 0..6
    const start = firstDate.isAfter(sevenDaysAgo) ? firstDate : sevenDaysAgo;

    const days = [];
    // Urutan: hari ini mundur ke start (maks 7 item), jadi tampil: Wed, Tue, Mon, ...
    for (let i = 0; i < 7; i++) {
      const d = today.subtract(i, "day");
      if (d.isBefore(start)) break;

      const dateStr = d.format("YYYY-MM-DD");
      const att = await Attendance.findOne({ where: { user_id: effectiveUserId, date: dateStr } });

      const hasClockIn = !!att?.clock_in;
      const cinMin = toMinutesFromAny(att?.clock_in);
      const cutoffMin = hhmmToMinutes(LATE_CUTOFF);

      let statusText = "Absent";
      let color = RED;

      if (hasClockIn) {
        const isLate = cutoffMin != null && cinMin != null ? cinMin > cutoffMin : false;
        if (isLate) {
          statusText = "Late";
          color = YELLOW;
        } else {
          statusText = "Normal";
          color = GREEN;
        }
      }

      days.push({
        day: dayShort(d),
        startTime: fmtTime(att?.clock_in),
        endTime: fmtTime(att?.clock_out),
        status: statusText, // "Normal" | "Late" | "Absent"
        timesheet: att?.timesheet, // 'true' | 'false' | null (enum string)
        color, // hex sesuai legend
        rawDate: dateStr,
      });
    }

    return NextResponse.json({ weekly: days }, { status: 200 });
  } catch (err) {
    console.error("attendance/weekly error:", err);
    return NextResponse.json({ error: "Failed to fetch weekly attendance." }, { status: 500 });
  }
});
