// src/app/api/user/[userId]/password/route.js
export const dynamic = "force-dynamic";
export const revalidate = 0;

import { NextResponse } from "next/server";
import models from "@/database/models";
import { withAuth } from "@/utils/session";
import dayjs from "dayjs";

const { User, sequelize } = models;

export const PUT = withAuth(async (req, { params }, currentUser) => {
  // superadmin only (konsisten sama /api/user/[userId])
  const isSuperadmin = currentUser?.is_superadmin === "true";
  if (!isSuperadmin) {
    return NextResponse.json(
      { error: "Forbidden: superadmin only." },
      { status: 403 }
    );
  }

  const userId = Number(params?.userId);
  if (!Number.isInteger(userId)) {
    return NextResponse.json({ error: "Invalid user id" }, { status: 400 });
  }

  let body;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON body" }, { status: 400 });
  }

  const password = String(body?.password ?? "").trim();

  if (!password) {
    return NextResponse.json({ error: "Password is required." }, { status: 400 });
  }
  if (password.length < 6) {
    return NextResponse.json(
      { error: "Password must be at least 6 characters." },
      { status: 400 }
    );
  }

  const t = await sequelize.transaction();
  try {
    const user = await User.findOne({
      where: { user_id: userId },
      transaction: t,
    });

    if (!user) {
      await t.rollback();
      return NextResponse.json({ error: "User not found" }, { status: 404 });
    }

    const bcrypt = (await import("bcryptjs")).default;
    const hashed = await bcrypt.hash(password, 10);

    const nowUnix = dayjs().unix();

    await user.update(
      {
        password: hashed,
        updated: nowUnix,
        updated_by: currentUser?.user_id ?? null,
      },
      { transaction: t }
    );

    await t.commit();
    return NextResponse.json({ message: "Password updated." }, { status: 200 });
  } catch (err) {
    await t.rollback();
    console.error("PUT /user/[userId]/password error:", err);
    return NextResponse.json(
      { error: "Failed to update password." },
      { status: 500 }
    );
  }
});
