// src/app/api/appraisal/[appraisalId]/route.js
export const dynamic = "force-dynamic";
export const revalidate = 0;

import { NextResponse } from "next/server";
import db from "@/database/models";
import { withActive } from "@/utils/session";
import {
  nowUnix,
  isTrue,
  getStaffIdField,
  calcScore,
} from "../_helper";

const { Appraisal } = db;

function getDeptIdFromRow(row) {
  const d1 = row?.department_id;
  if (d1 != null) return Number(d1);
  const snap = row?.staff_snapshot_json && typeof row.staff_snapshot_json === "object"
    ? row.staff_snapshot_json
    : {};
  return snap?.department_id == null ? null : Number(snap.department_id);
}

function canRead(currentUser, row) {
  if (isTrue(currentUser?.is_superadmin)) return true;

  const isHod = isTrue(currentUser?.is_hod);
  const isHrd = isTrue(currentUser?.is_hrd);
  const isDirector = isTrue(currentUser?.is_operational_director);

  // approver boleh baca semua non-draft (HOD dibatasi dept)
  if (isHrd || isDirector) {
    return String(row?.status) !== "draft";
  }

  if (isHod) {
    if (String(row?.status) === "draft") return false;
    const myDept = currentUser?.department_id == null ? null : Number(currentUser.department_id);
    const rowDept = getDeptIdFromRow(row);
    if (myDept != null && rowDept != null) return myDept === rowDept;
    return true;
  }

  // staff biasa: hanya miliknya sendiri
  const myId = Number(currentUser?.user_id);
  const staffIdField = getStaffIdField();
  return Number(row?.[staffIdField]) === myId;
}

function canEdit(currentUser, row) {
  // ✅ sesuai request kamu: staff biasa gak boleh ngisi/edit
  return isTrue(currentUser?.is_superadmin) && String(row?.status) === "draft";
}

export const GET = withActive(async function GET_HANDLER(req, { params }, currentUser) {
  try {
    const appraisalId = Number(params?.appraisalId);
    if (!Number.isFinite(appraisalId)) {
      return NextResponse.json({ error: "Invalid appraisalId" }, { status: 400 });
    }

    const row = await Appraisal.findOne({
      where: { appraisal_id: appraisalId, deleted: null, deleted_by: null },
    });
    if (!row) return NextResponse.json({ error: "Not found" }, { status: 404 });

    if (!canRead(currentUser, row)) {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    }

    return NextResponse.json({ ok: true, data: row }, { status: 200 });
  } catch (error) {
    console.error("GET /api/appraisal/[id] error:", error);
    return NextResponse.json({ error: error?.message || "Failed." }, { status: 500 });
  }
});

export const PUT = withActive(async function PUT_HANDLER(req, { params }, currentUser) {
  try {
    const appraisalId = Number(params?.appraisalId);
    if (!Number.isFinite(appraisalId)) {
      return NextResponse.json({ error: "Invalid appraisalId" }, { status: 400 });
    }

    const row = await Appraisal.findOne({
      where: { appraisal_id: appraisalId, deleted: null, deleted_by: null },
    });
    if (!row) return NextResponse.json({ error: "Not found" }, { status: 404 });

    if (!canEdit(currentUser, row)) {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    }

    const body = await req.json().catch(() => ({}));
    const updates = {};
    const now = nowUnix();
    const actorId = Number(currentUser?.user_id);

    // merge answers_json
    if (body?.answers && typeof body.answers === "object") {
      const existing =
        row.answers_json && typeof row.answers_json === "object" ? row.answers_json : {};
      const merged = { ...existing };

      for (const [k, v] of Object.entries(body.answers)) {
        const key = String(k);
        if (v && typeof v === "object") {
          const n =
            v.value == null || v.value === "" ? null : Number(v.value);
          merged[key] = {
            value: Number.isFinite(n) ? n : null,
            note: typeof v.note === "string" ? v.note : (merged[key]?.note || ""),
          };
        } else {
          const n = v == null || v === "" ? null : Number(v);
          merged[key] = { value: Number.isFinite(n) ? n : null, note: merged[key]?.note || "" };
        }
      }

      updates.answers_json = merged;
    }

    // optional: general_comment
    if (body?.generalComment !== undefined) {
      updates.general_comment = body.generalComment != null ? String(body.generalComment) : null;
    }

    // optional: before/after status (tetap fleksibel)
    if (body?.beforeStatus !== undefined || body?.afterStatus !== undefined) {
      const emp =
        row.employment_snapshot_json && typeof row.employment_snapshot_json === "object"
          ? row.employment_snapshot_json
          : {};
      updates.employment_snapshot_json = {
        ...emp,
        before_status:
          body.beforeStatus !== undefined ? (body.beforeStatus || null) : (emp.before_status ?? null),
        after_status:
          body.afterStatus !== undefined ? (body.afterStatus || null) : (emp.after_status ?? null),
      };
    }

    // recompute score
    const questions = row.questions_json;
    const answers = updates.answers_json ?? row.answers_json;
    const score = calcScore(questions, answers);

    updates.total_score = score.total_score;
    updates.average_score = score.average_score;
    updates.grade = score.grade;

    const prevScoring =
      row.scoring_json && typeof row.scoring_json === "object" ? row.scoring_json : {};
    updates.scoring_json = {
      ...prevScoring,
      total_score: score.total_score,
      average_score: score.average_score,
      grade: score.grade,
      answered_count: score.answered_count,
      question_count: score.question_count,
    };

    updates.updated = now;
    updates.updated_by = actorId;

    await row.update(updates);

    return NextResponse.json({ ok: true, data: row }, { status: 200 });
  } catch (error) {
    console.error("PUT /api/appraisal/[id] error:", error);
    return NextResponse.json({ error: error?.message || "Failed." }, { status: 500 });
  }
});

export const DELETE = withActive(async function DELETE_HANDLER(req, { params }, currentUser) {
  try {
    const appraisalId = Number(params?.appraisalId);
    if (!Number.isFinite(appraisalId)) {
      return NextResponse.json({ error: "Invalid appraisalId" }, { status: 400 });
    }

    if (!isTrue(currentUser?.is_superadmin)) {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    }

    const row = await Appraisal.findOne({
      where: { appraisal_id: appraisalId, deleted: null, deleted_by: null },
    });
    if (!row) return NextResponse.json({ error: "Not found" }, { status: 404 });

    const now = nowUnix();
    const actorId = Number(currentUser?.user_id);

    await row.update({
      deleted: now,
      deleted_by: actorId,
      updated: now,
      updated_by: actorId,
    });

    return NextResponse.json({ ok: true, message: "Deleted" }, { status: 200 });
  } catch (error) {
    console.error("DELETE /api/appraisal/[id] error:", error);
    return NextResponse.json({ error: error?.message || "Failed." }, { status: 500 });
  }
});
