export const dynamic = 'force-dynamic';
export const revalidate = 0;

import { NextResponse } from "next/server";
import { CountryCode } from "@/database/models"; // Pastikan path sesuai dengan lokasi models

// Ambil semua profil dari database
export async function GET() {
    try {
        const countryCodeData = await CountryCode.findAll();
        return NextResponse.json({ success: true, countryCode: countryCodeData });
    } catch (error) {
        console.error("Error fetching data:", error);
        return NextResponse.json({ error: "Gagal mengambil data" }, { status: 500 });
    }
}

