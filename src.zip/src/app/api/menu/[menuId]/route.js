// src/app/api/menu/[menuId]/route.js
import { NextResponse } from "next/server";
import db from "@/database/models";
import dayjs from "dayjs";
import utc from "dayjs/plugin/utc";
import { withAuth } from "@/utils/session";

dayjs.extend(utc);

const { Menu } = db;
const nowUnix = () => dayjs().utc().unix();

/**
 * Normalisasi value boolean ke enum string "true"/"false"
 * Accept:
 *  - "true" / "false"
 *  - true / false
 *  - 1 / 0
 *  - "1" / "0"
 */
function normalizeBoolEnum(value, defaultValue = "true") {
  if (value === undefined || value === null) return defaultValue;

  if (value === true || value === "true" || value === 1 || value === "1") {
    return "true";
  }
  if (value === false || value === "false" || value === 0 || value === "0") {
    return "false";
  }
  return defaultValue;
}

/* ====================== PUT: Update Menu ====================== */
export const PUT = withAuth(
  async function PUT_HANDLER(req, { params }, currentUser) {
    try {
      const { menuId } = params;
      const payload = await req.json().catch(() => ({}));

      const fields = {};

      if (payload.title !== undefined) {
        fields.title = String(payload.title).trim();
      }

      if (payload.path !== undefined) {
        const path =
          payload.path != null && String(payload.path).trim() !== ""
            ? String(payload.path).trim()
            : null;
        fields.path = path;
      }

      if (payload.icon !== undefined) {
        const icon =
          payload.icon != null && String(payload.icon).trim() !== ""
            ? String(payload.icon).trim()
            : null;
        fields.icon = icon;
      }

      if (payload.ordered !== undefined) {
        const orderedRaw = payload.ordered;
        fields.ordered = Number.isFinite(+orderedRaw) ? +orderedRaw : 0;
      }

      if (payload.parent_id !== undefined) {
        const parentRaw = payload.parent_id;
        fields.parent_id =
          parentRaw === null ||
          parentRaw === undefined ||
          parentRaw === ""
            ? null
            : Number(parentRaw);
      }

      if (payload.is_active !== undefined) {
        fields.is_active = normalizeBoolEnum(payload.is_active);
      }

      if (payload.is_show !== undefined) {
        fields.is_show = normalizeBoolEnum(payload.is_show);
      }

      if (payload.type !== undefined) {
        fields.type = payload.type === "dashboard" ? "dashboard" : "page";
      }

      const now = nowUnix();
      const userId = currentUser?.user_id ?? currentUser?.id ?? null;

      if (!userId) {
        return NextResponse.json(
          { error: "Invalid current user (missing user_id)." },
          { status: 500 }
        );
      }

      fields.updated = now;
      fields.updated_by = userId;

      const [affected] = await Menu.update(fields, {
        where: { menu_id: menuId },
      });

      if (!affected) {
        return NextResponse.json(
          { error: "Menu not found." },
          { status: 404 }
        );
      }

      const updatedMenu = await Menu.findOne({
        where: { menu_id: menuId },
      });

      return NextResponse.json(
        {
          message: "Menu updated.",
          menu: updatedMenu ? updatedMenu.toJSON() : null,
        },
        { status: 200 }
      );
    } catch (error) {
      console.error("Error updating menu:", error);
      return NextResponse.json(
        { error: error.message || "Failed to update menu." },
        { status: 500 }
      );
    }
  }
);

/* ====================== DELETE: Soft Delete Menu ====================== */
export const DELETE = withAuth(
  async function DELETE_HANDLER(_req, { params }, currentUser) {
    try {
      const { menuId } = params;

      const now = nowUnix();
      const userId = currentUser?.user_id ?? currentUser?.id ?? null;

      if (!userId) {
        return NextResponse.json(
          { error: "Invalid current user (missing user_id)." },
          { status: 500 }
        );
      }

      const [affected] = await Menu.update(
        {
          updated: now,
          updated_by: userId,
          deleted: now,
          deleted_by: userId,
        },
        {
          where: { menu_id: menuId },
        }
      );

      if (!affected) {
        return NextResponse.json(
          { error: "Menu not found." },
          { status: 404 }
        );
      }

      return NextResponse.json(
        { message: "Menu deleted" },
        { status: 200 }
      );
    } catch (error) {
      console.error("Error deleting menu:", error);
      return NextResponse.json(
        { error: error.message || "Failed to delete menu." },
        { status: 500 }
      );
    }
  }
);
