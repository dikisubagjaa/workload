// src/utils/performanceLog.js
import db from "@/database/models";
import dayjs from "dayjs";

// Single source of truth untuk poin
export const SCORE = {
  LATE_TO_WORK: -1,
  MISS_DEADLINE: -3,
  MISS_DEADLINE_H3: -5,
  MISS_DEADLINE_H7: -10,
  COMPLETE_TASK: 0,
  COMPLETE_TASK_H1: +1,
  COMPLETE_TASK_H3: +2,
  COMPLETE_TASK_H7: +3,
  COMPLETE_OVERDUE_TASK: +2,
  NOT_FILLING_TIMESHEET: -5,
};

const nowUnix = () => Math.floor(Date.now() / 1000);
const curYear = () => new Date().getFullYear();
const toYmd = (sec) => dayjs.unix(Number(sec) || 0).format("YYYY-MM-DD");
const yearOfYmd = (ymd) => Number(String(ymd).slice(0, 4));

async function ensurePerfYear(userId) {
  const u = await db.User.findOne({
    where: { user_id: userId },
    attributes: ["user_id", "performance_score", "performance_year"],
  });
  if (!u) return;

  const thisYear = curYear();
  if (u.performance_year !== thisYear) {
    await db.User.update(
      { performance_year: thisYear, performance_score: 0 },
      { where: { user_id: userId } }
    );
  }
}

/**
 * Tulis satu event ke performance_event_log (idempotent by dedup_key).
 * Setelah create, update user.performance_score jika event tahun berjalan.
 */
export async function writeLog({
  user_id,
  event_type,
  points,
  occurred,       // epoch seconds
  date_ymd,       // optional, auto dari occurred jika kosong
  task_id = null,
  attendance_id = null,
  meta = null,    // object/string
  dedup_key,
}) {
  // Validasi ringan biar errornya jelas untuk pemula
  if (!user_id) throw new Error("writeLog: user_id is required");
  if (!event_type) throw new Error("writeLog: event_type is required");
  if (typeof points !== "number") throw new Error("writeLog: points must be number");
  if (!dedup_key) throw new Error("writeLog: dedup_key is required");

  const now = nowUnix();
  const occurredSec = Number(occurred) || now;
  const ymd = date_ymd || toYmd(occurredSec);

  const payload = {
    user_id,
    event_type,
    points,
    occurred: occurredSec,
    date_ymd: ymd,
    task_id,
    attendance_id,
    meta: meta ? (typeof meta === "object" ? JSON.stringify(meta) : String(meta)) : null,
    dedup_key,
    created: now,
    updated: now,
  };

  // Idempotent insert (kalau ada race tanpa UNIQUE index, tetap aman via findOrCreate)
  let row, created;
  try {
    [row, created] = await db.PerformanceEventLog.findOrCreate({
      where: { dedup_key },
      defaults: payload,
    });
  } catch (err) {
    // Kalau nanti dedup_key dibuat UNIQUE dan terjadi race, balas gracefully
    const isUnique =
      err?.name === "SequelizeUniqueConstraintError" ||
      err?.original?.code === "ER_DUP_ENTRY";
    if (isUnique) {
      row = await db.PerformanceEventLog.findOne({ where: { dedup_key } });
      created = false;
    } else {
      throw err;
    }
  }

  // Jika row baru dibuat → sinkronkan agregat user
  if (created) {
    await ensurePerfYear(user_id);

    const u = await db.User.findOne({
      where: { user_id },
      attributes: ["performance_score", "performance_year"],
    });
    if (u && yearOfYmd(ymd) === u.performance_year) {
      const newScore = Number(u.performance_score || 0) + Number(points || 0);
      await db.User.update(
        { performance_score: newScore },
        { where: { user_id } }
      );
    }
  }

  return row;
}

/** Util opsional (berguna untuk repair/backfill manual) */
export async function recalcUserScore(userId, year = null) {
  const y = year || curYear();
  const rows = await db.sequelize.query(
    `
    SELECT COALESCE(SUM(points), 0) AS total
    FROM performance_event_log
    WHERE user_id = ?
      AND YEAR(date_ymd) = ?
      AND (deleted IS NULL OR deleted = 0)
    `,
    { replacements: [userId, y], type: db.Sequelize.QueryTypes.SELECT }
  );

  const total = Number(rows?.[0]?.total || 0);
  await db.User.update(
    { performance_score: total, performance_year: y },
    { where: { user_id: userId } }
  );
  return total;
}

/** Util kecil agar API nanti tinggal pakai (boleh dipakai/diabaikan dulu) */
export async function getPerfScore(userId) {
  await ensurePerfYear(userId);
  const u = await db.User.findOne({
    where: { user_id: userId },
    attributes: ["performance_score", "performance_year"],
  });
  if (!u) throw new Error("User not found");
  return {
    score: Number(u.performance_score || 0),
    year: Number(u.performance_year || curYear()),
  };
}
