// src/app/client/page.jsx
"use client";

import React, { useState, useEffect, useCallback } from 'react';
import { Table, Button, message, Spin, Popconfirm, Space, Card, Input, Popover } from 'antd';
import { PlusOutlined, EditOutlined, DeleteOutlined, LoadingOutlined, SearchOutlined, MoreOutlined } from '@ant-design/icons';
import axiosInstance from '@/utils/axios';
import dayjs from "dayjs";
import { Layout } from 'antd'; // NEW: Hanya impor Layout
const { Content, Header, Sider } = Layout; // NEW: Destruktur Content, Header, Sider dari objek Layout

import ModalClient from '@/components/modal/ModalClient'; // Import modal client
import { useMobileQuery } from '@/components/libs/UseMediaQuery';
import Image from 'next/image';
import Link from 'next/link';

export default function ClientManagementPage() {
    const isMobile = useMobileQuery();
    const [clients, setClients] = useState([]);
    const [loading, setLoading] = useState(true);
    const [searchTerm, setSearchTerm] = useState('');
    const [isModalVisible, setIsModalVisible] = useState(false);
    const [editingClient, setEditingClient] = useState(null);
    const [openActionFor, setOpenActionFor] = useState(null);

    // --- Fetch Clients ---
    const fetchClients = useCallback(async () => {
        setLoading(true);
        try {
            const response = await axiosInstance.get('/client'); // <-- API GET client
            setClients(response.data.clients); // Asumsi API mengembalikan { clients: [...] }
        } catch (error) {
            console.error("Error fetching clients:", error.response || error.message);
            message.error("Failed to load clients.");
        } finally {
            setLoading(false);
        }
    }, []);

    useEffect(() => {
        fetchClients();
    }, [fetchClients]);

    // --- Handlers Modal & Delete ---
    const showAddModal = () => {
        setEditingClient(null);
        setIsModalVisible(true);
    };

    const showEditModal = (client) => {
        setEditingClient(client);
        setIsModalVisible(true);
    };

    const handleDelete = async (clientId) => {
        try {
            await axiosInstance.delete(`/client/${clientId}`); // <-- API DELETE client
            message.success("Client soft-deleted successfully!");
            fetchClients(); // Refresh list
        } catch (error) {
            console.error("Error deleting client:", error.response || error.message);
            message.error(`Failed to delete client: ${error.response?.data?.error || error.message}`);
        }
    };

    // ===== ACTION POPOVER CONTENT =====
    const buildActionContent = (record) => (
        <div className="p-1">
            <div className="text-xs font-semibold opacity-70 px-1 pb-2">
                Quick actions
            </div>
            <div className="flex flex-col gap-2 px-1 pb-1">
                <Button
                    size="small"
                    type="default"
                    className="flex justify-start px-3"
                    icon={<EditOutlined />}
                    onClick={() => showEditModal(record)}
                >
                    Edit
                </Button>
                <Popconfirm
                    title="Are you sure to delete this client?"
                    onConfirm={() => handleDelete(record.client_id)}
                    okText="Yes"
                    cancelText="No"
                >
                    <Button
                        size="small"
                        danger
                        className="flex justify-start px-3"
                        icon={<DeleteOutlined />}
                        onClick={(e) => e.stopPropagation()}
                    >
                        Delete
                    </Button>
                </Popconfirm>
            </div>
        </div>
    );

    // --- Kolom Tabel ---
    const colomnDetail = () => [
        { title: 'ID', dataIndex: 'client_id', sorter: true, key: 'client_id', width: 60 },
        { title: 'Type', dataIndex: 'type', sorter: true, key: 'type' },
        { title: 'Client Name', dataIndex: 'client_name', sorter: true, key: 'client_name' },
        {
            title: 'Brand',
            dataIndex: 'brand',
            sorter: true,
            key: 'brand',
            render: brands => {
                return Array.isArray(brands)
                    ? brands.map(brandObj => brandObj.title).join(', ')
                    : '-';
            }
        },
        { title: 'Division', dataIndex: 'division', sorter: true, key: 'division' },
        { title: 'Address', dataIndex: 'address', sorter: true, key: 'address' },
        { title: 'PIC Name', dataIndex: 'pic_name', sorter: true, key: 'pic_name' },
        { title: 'PIC Phone', dataIndex: 'pic_phone', sorter: true, key: 'pic_phone' },
        { title: 'PIC Email', dataIndex: 'pic_email', sorter: true, key: 'pic_email' },
        { title: 'Created At', dataIndex: 'created', sorter: true, key: 'created', render: text => text ? dayjs(text).format("YYYY-MM-DD HH:mm:ss") : "-" },
        {
            key: 'actions',
            fixed: "right",
            width: 50,
            render: (_v, r) => {
                const content = buildActionContent(r);
                return (
                    <Popover
                        trigger="click"
                        placement="left"
                        open={openActionFor === r.client_id}
                        onOpenChange={(v) => setOpenActionFor(v ? r.client_id : null)}
                        content={content}
                    >
                        <Button size="small" type="text" icon={<MoreOutlined />} />
                    </Popover>
                );
            },
        },
    ];

    const mobileColomnDetail = () => [
        {
            title: 'Client Name',
            dataIndex: 'client_name',
            key: 'client_name',
            render: (_v, r) => {
                const content = buildActionContent(r);
                return (
                    <div className="flex">
                        <div>
                            <h4 className="text-base font-semibold">Client Name:</h4>
                            <h3 className="text-sm">{r.client_name}</h3>
                        </div>

                        <div className=" ms-auto flex gap-2">
                            <Popover
                                trigger="click"
                                placement="left"
                                open={openActionFor === r.client_id}
                                onOpenChange={(v) => setOpenActionFor(v ? r.client_id : null)}
                                content={content}
                            >
                                <Button size="small" type="text" icon={<MoreOutlined />} />
                            </Popover>
                        </div>
                    </div>
                );
            },
        },
    ];

    const ExpandTable = ({ record }) => {
        const brands = Array.isArray(record.brand)
            ? record.brand.map(b => b.title).join(', ')
            : '-';

        return (
            <ul className="flex flex-col gap-3">
                <li>
                    <h4 className="text-base font-semibold">Brands:</h4>
                    <h3 className="text-sm">{brands}</h3>
                </li>

                <li>
                    <h4 className="text-base font-semibold">ID:</h4>
                    <h3 className="text-sm">{record.client_id}</h3>
                </li>

                <li>
                    <h4 className="text-base font-semibold">Type:</h4>
                    <h3 className="text-sm">{record.type}</h3>
                </li>

                <li>
                    <h4 className="text-base font-semibold">Division:</h4>
                    <h3 className="text-sm">{record.division}</h3>
                </li>

                <li>
                    <h4 className="text-base font-semibold">PIC Name:</h4>
                    <h3 className="text-sm">{record.pic_name}</h3>
                </li>

                <li>
                    <h4 className="text-base font-semibold">PIC Phone:</h4>
                    <h3 className="text-sm">{record.pic_phone}</h3>
                </li>

                <li>
                    <h4 className="text-base font-semibold">PIC Email:</h4>
                    <h3 className="text-sm">{record.pic_email}</h3>
                </li>

                <li>
                    <h4 className="text-base font-semibold">Created At:</h4>
                    <h3 className="text-sm">
                        {record.created ? dayjs(record.created).format("YYYY-MM-DD HH:mm:ss") : "-"}
                    </h3>
                </li>
            </ul>
        )
    };

    const filteredData = clients.filter(item =>
        item.client_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.brand?.some(b => b.title?.toLowerCase().includes(searchTerm.toLowerCase()))
    );

    return (
        <section className="container py-10">
            <Card
                className='card-table shadow-md'
                title={
                    <h3 className="fc-base text-xl">Client Management</h3>
                }
            >
                <Spin spinning={loading} indicator={<LoadingOutlined style={{ fontSize: 24 }} spin />}>
                    <div className="flex flex-wrap gap-3 justify-between mb-6">
                        <div className="w-full sm:w-96">
                            <Input
                                placeholder="Search..."
                                allowClear
                                onChange={e => setSearchTerm(e.target.value)}
                                className="w-full text-sm"
                                suffix={<SearchOutlined className="text-base text-gray" />}
                            />
                        </div>

                        <Button type='primary' className="font-semibold w-full sm:w-auto" onClick={showAddModal}>
                            <PlusOutlined /> Add New Client
                        </Button>
                    </div>

                    <Table
                        dataSource={filteredData.map(item => ({ ...item, key: item.client_id }))}
                        columns={isMobile ? mobileColomnDetail() : colomnDetail()}
                        pagination={{ pageSize: 5, position: ['bottomCenter'] }}
                        showHeader={isMobile ? false : true}
                        expandable={isMobile ? {
                            expandedRowRender: (record) => (
                                <ExpandTable record={record} />
                            ),
                        } : null}
                        scroll={isMobile ? null : { x: "max-content" }}
                    />
                </Spin>
            </Card>

            <ModalClient
                isModalVisible={isModalVisible}
                setIsModalVisible={setIsModalVisible}
                editingClient={editingClient}
                setEditingClient={setEditingClient}
                fetchClients={fetchClients}
            />
        </section>
    );
}