export const timeAgo = (date) => {
    const now = new Date();
    const past = new Date(date);
    const diffInSeconds = Math.floor((now - past) / 1000);

    const intervals = {
        year: 31536000,
        month: 2592000,
        week: 604800,
        day: 86400,
        hour: 3600,
        minute: 60,
        second: 1
    };

    for (let [key, value] of Object.entries(intervals)) {
        const count = Math.floor(diffInSeconds / value);
        if (count > 0) {
            return `${count} ${key}${count > 1 ? 's' : ''} ago`;
        }
    }
    return "Just now";
};

export const getCurrentTime = () => {
    return new Date().toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit", second: "2-digit" });
};

export const formatTime = (date) => {
    if (!date) return null;
    return new Date(date).toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit", second: "2-digit" });
};

export const getTimeDifference = (startTime, endTime) => {
    const start = new Date(startTime);
    const end = new Date(endTime);
    const diffInSeconds = Math.floor((end - start) / 1000);

    const hours = Math.floor(diffInSeconds / 3600);
    const minutes = Math.floor((diffInSeconds % 3600) / 60);
    const seconds = diffInSeconds % 60;

    return `${hours} hour(s), ${minutes} minute(s), ${seconds} second(s)`;
};

/*
    timeAgo(date)	Menampilkan waktu berlalu dari suatu tanggal dalam format "X menit yang lalu"
    getCurrentTime()	Mendapatkan waktu saat ini dalam format HH:mm:ss
    formatTime(date)	Mengubah format waktu menjadi HH:mm:s
    getTimeDifference(startTime, endTime)	Menghitung selisih waktu antara dua tanggal	
*/