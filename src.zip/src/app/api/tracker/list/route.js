// src/app/api/tracker/list/route.js
export const dynamic = 'force-dynamic';
export const revalidate = 0;

import { NextResponse } from 'next/server';
import db from '@/database/models';
import dayjs from 'dayjs';
import utc from 'dayjs/plugin/utc';
import timezone from 'dayjs/plugin/timezone';
import { withActive } from '@/utils/session';

dayjs.extend(utc);
dayjs.extend(timezone);
dayjs.tz.setDefault(process.env.NEXT_PUBLIC_APP_TIMEZONE || 'Asia/Jakarta');

const { Sequelize, Project, Client, ProjectQuotation, ProjectPurchaseOrder } = db;
const { Op } = Sequelize;

// --- helpers ---
function toYMD(s) {
    const d = dayjs(String(s || '').trim(), 'YYYY-MM-DD', true);
    return d.isValid() ? d.format('YYYY-MM-DD') : null;
}
function toUnixStart(ymd) {
    if (!ymd) return null;
    return dayjs.tz(ymd, 'YYYY-MM-DD').startOf('day').unix();
}
function toUnixEnd(ymd) {
    if (!ymd) return null;
    return dayjs.tz(ymd, 'YYYY-MM-DD').endOf('day').unix();
}
function toYMDFromCreated(created) {
    if (created == null) return null;
    // created kebanyakan INTEGER (unix seconds). Jika bukan, dayjs tetap coba format.
    if (typeof created === 'number') return dayjs.unix(created).tz().format('YYYY-MM-DD');
    const d = dayjs(created);
    return d.isValid() ? d.tz().format('YYYY-MM-DD') : null;
}

// Normalisasi satu baris
function normRow({ id, category, title, client, created }) {
    return {
        id,
        category,                // 'project' | 'proposal' | 'po'
        title: title || '-',
        client: client || '-',
        date: toYMDFromCreated(created), // YYYY-MM-DD
        status: null,            // di model tidak ada status → tampilkan '-' di FE
        _created: typeof created === 'number' ? created : (dayjs(created).isValid() ? dayjs(created).unix() : 0), // for sorting
    };
}

export const GET = withActive(async function GET_HANDLER(req) {
    try {
        const { searchParams } = new URL(req.url);

        // pagination
        const page = Math.max(1, parseInt(searchParams.get('page') || '1', 10));
        const limit = Math.min(50, Math.max(1, parseInt(searchParams.get('limit') || '10', 10)));

        // filters
        const category = (searchParams.get('category') || 'all').toLowerCase(); // project|proposal|po|all
        const q = (searchParams.get('q') || '').trim();
        const from = toYMD(searchParams.get('from'));
        const to = toYMD(searchParams.get('to'));
        const fromUnix = toUnixStart(from);
        const toUnix = toUnixEnd(to);

        // sorting
        const sortBy = (searchParams.get('sortBy') || 'date').toLowerCase();     // date|title|client|category
        const sortDir = (searchParams.get('sortDir') || 'desc').toLowerCase() === 'asc' ? 'asc' : 'desc';

        // Build WHERE by date (di level DB untuk ngurangin dataset)
        const rangeWhere = (modelField = 'created') => {
            if (fromUnix != null && toUnix != null) {
                return { [modelField]: { [Op.between]: [fromUnix, toUnix] } };
            }
            return {};
        };

        // --- ambil data per kategori (db → array) ---
        const results = [];

        // PROJECT
        if (category === 'project' || category === 'all') {
            const rows = await Project.findAll({
                where: { ...rangeWhere('created') },
                include: [
                    { model: Client, as: 'Client', attributes: ['client_name'] },
                ],
                attributes: ['project_id', 'title', 'created'],
                order: [['created', 'DESC']],
            });

            rows.forEach((r) => {
                const j = r.toJSON();
                results.push(
                    normRow({
                        id: j.project_id,
                        category: 'project',
                        title: j.title,
                        client: j.Client?.client_name,
                        created: j.created,
                    })
                );
            });
        }

        // PROPOSAL (QUOTATION)
        if (category === 'proposal' || category === 'all') {
            // Asumsi relasi umum:
            // ProjectQuotation.belongsTo(Project, { as: 'Project', foreignKey: 'project_id' })
            // Project.belongsTo(Client, { as: 'Client', foreignKey: 'client_id' })
            const pqRows = await ProjectQuotation.findAll({
                where: { ...rangeWhere('created') },
                include: [
                    {
                        model: Project,
                        as: 'Project',
                        attributes: ['project_id', 'client_id', 'title'],
                        include: [{ model: Client, as: 'Client', attributes: ['client_name'] }],
                    },
                ],
                attributes: ['pq_id', 'quotation_number', 'created'],
                order: [['created', 'DESC']],
            });

            pqRows.forEach((r) => {
                const j = r.toJSON();
                results.push(
                    normRow({
                        id: j.pq_id,
                        category: 'proposal',
                        title: j.quotation_number || j.Project?.title,
                        client: j.Project?.Client?.client_name,
                        created: j.created,
                    })
                );
            });
        }

        // PURCHASE ORDER (PO)
        if (category === 'po' || category === 'all') {
            // Asumsi relasi umum yang sering dipakai:
            // ProjectPurchaseOrder.belongsTo(ProjectQuotation, { as: 'Quotation', foreignKey: 'pq_id' })
            // ProjectQuotation.belongsTo(Project, { as: 'Project', foreignKey: 'project_id' })
            // Project.belongsTo(Client, { as: 'Client', foreignKey: 'client_id' })
            const poRows = await ProjectPurchaseOrder.findAll({
                where: { ...rangeWhere('created') },
                include: [
                    {
                        model: ProjectQuotation,
                        as: 'Quotation', // banyak repo pakai alias 'Quotation' untuk relasi ke PQ
                        attributes: ['pq_id', 'project_id', 'quotation_number'],
                        include: [
                            {
                                model: Project,
                                as: 'Project',
                                attributes: ['project_id', 'client_id', 'title'],
                                include: [{ model: Client, as: 'Client', attributes: ['client_name'] }],
                            },
                        ],
                    },
                ],
                attributes: ['po_id', 'po_number', 'created'],
                order: [['created', 'DESC']],
            });

            poRows.forEach((r) => {
                const j = r.toJSON();
                results.push(
                    normRow({
                        id: j.po_id,
                        category: 'po',
                        title: j.po_number || j.Quotation?.quotation_number || j.Quotation?.Project?.title,
                        client: j.Quotation?.Project?.Client?.client_name,
                        created: j.created,
                    })
                );
            });
        }

        // --- filter q (di atas hasil gabungan) ---
        let filtered = results;
        if (q) {
            const qq = q.toLowerCase();
            filtered = filtered.filter((it) => {
                const T = (it.title || '').toLowerCase();
                const C = (it.client || '').toLowerCase();
                return T.includes(qq) || C.includes(qq);
            });
        }

        // --- sorting gabungan ---
        const sorter = {
            date: (a, b) => (a._created || 0) - (b._created || 0),
            title: (a, b) => String(a.title || '').localeCompare(String(b.title || ''), undefined, { sensitivity: 'base' }),
            client: (a, b) => String(a.client || '').localeCompare(String(b.client || ''), undefined, { sensitivity: 'base' }),
            category: (a, b) => String(a.category || '').localeCompare(String(b.category || ''), undefined, { sensitivity: 'base' }),
        }[sortBy] || ((a, b) => (a._created || 0) - (b._created || 0));

        filtered.sort(sorter);
        if (sortDir === 'desc') filtered.reverse();

        // --- pagination ---
        const total = filtered.length;
        const start = (page - 1) * limit;
        const end = start + limit;
        const pageData = filtered.slice(start, end).map(({ _created, ...rest }) => rest);

        return NextResponse.json(
            { ok: true, data: pageData, meta: { page, limit, total } },
            { status: 200 }
        );
    } catch (error) {
        console.error('GET /api/tracker/list error:', error);
        return NextResponse.json({ error: error?.message || 'Failed to fetch tracker list' }, { status: 500 });
    }
});
