"use client";

import "swiper/css";
import "swiper/css/navigation";
import { Swiper, SwiperSlide } from "swiper/react";
import { useCallback, useEffect, useMemo, useState } from "react";
import { Button, Card, Tabs, message, Skeleton } from "antd";
import axiosInstance from "@/utils/axios";
import { useMobileQuery, useLaptopQuery, useDekstopQuery } from "@/components/libs/UseMediaQuery";
import ModalTask from "@/components/modal/ModalTask";
import TableTask from "@/components/table/TableTask";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faPlus } from "@fortawesome/free-solid-svg-icons";
import ModalProject from "@/components/modal/ModalProject";
import dayjs from "dayjs";
import utc from "dayjs/plugin/utc";
import { useSearchParams } from "next/navigation";
import StatsBar from "@/components/common/StatsBar";

dayjs.extend(utc);

/** ====================== Child: Overview ====================== */
const Overview = ({
  overviewData,
  isMobile,
  isLaptop,
  isDekstop,
  loading,
  tasks,
  onChangeStatus,
}) => {
  const slidesPerView = isMobile ? 1 : isLaptop ? 1 : 6;
  const width = isMobile ? 150 : isLaptop ? 160 : undefined;

  return (
    <section className="mb-7">
      <StatsBar 
        isMobile={isMobile} 
        isLaptop={isLaptop} 
        isDekstop={isDekstop}
      />
      <h3 className="fc-base text-lg mb-4">Task List</h3>
      <TableTask
        dataTask={tasks}
        loading={loading}
        onChangeStatus={onChangeStatus}
      />
    </section>
  );
};

/** ====================== Child: Archived ====================== */
const Archived = ({ tasks, loading, onChangeStatus }) => {
  return (
    <section className="mb-7">
      <h3 className="fc-base text-lg mb-4">Archived Task</h3>
      <TableTask
        dataTask={tasks.filter((t) => (t.status || t.todo) === "completed")}
        loading={loading}
        onChangeStatus={onChangeStatus}
      />
    </section>
  );
};

/** ====================== Parent: MainContent ====================== */
export default function MainContent() {
  const [modalTask, setModalTask] = useState(false);
  const [modalProject, setModalProject] = useState(false);
  const [loading, setLoading] = useState(true);
  const [tasks, setTasks] = useState([]);

  const isMobile = useMobileQuery();
  const isLaptop = useLaptopQuery();
  const isDekstop = useDekstopQuery();
  const searchParams = useSearchParams();
  const category = searchParams.get("category"); // <-- dari /task?category=overdue

  // Fetch all assigned tasks (default: user login)
  const fetchTasks = useCallback(async () => {
    try {
      setLoading(true);
      const res = await axiosInstance.get("/task/list-assign?scope=me");
      const data = res.data?.tasks || res.data?.Task || [];
      setTasks(Array.isArray(data) ? data : []);
    } catch (err) {
      console.error(err);
      message.error("Gagal memuat data task");
      setTasks([]);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchTasks();
  }, [fetchTasks]);

  // Re-fetch setelah modal ditutup
  useEffect(() => {
    if (!modalProject && !modalTask) {
      const t = setTimeout(() => fetchTasks(), 250);
      return () => clearTimeout(t);
    }
  }, [modalProject, modalTask, fetchTasks]);

  // --- helper kecil soal tanggal & status
  const now = dayjs.utc();
  const startOfToday = now.startOf("day");
  const endOfToday = now.endOf("day");
  const startOfWeek = now.startOf("week");
  const endOfWeek = now.endOf("week");

  const isCompleted = (t) =>
    (t?.todo && String(t.todo).toLowerCase() === "completed") ||
    (t?.status && String(t.status).toLowerCase() === "completed") ||
    (t?.status && String(t.status).toLowerCase() === "complete");

  const toUnix = (v) => (typeof v === "number" ? v : Number(v));
  const hasDue = (t) => Number.isFinite(toUnix(t?.end_date));

  // Hitung metrik overview di FE (tetap seperti aslinya)
  const overviewData = useMemo(() => {
    const dueToday = tasks.filter(
      (t) =>
        hasDue(t) &&
        !isCompleted(t) &&
        dayjs.unix(toUnix(t.end_date)).isAfter(startOfToday) &&
        dayjs.unix(toUnix(t.end_date)).isBefore(endOfToday)
    ).length;

    const overdueTask = tasks.filter(
      (t) => hasDue(t) && !isCompleted(t) && dayjs.unix(toUnix(t.end_date)).isBefore(now)
    ).length;

    const criticalDeadlines = tasks.filter((t) => {
      if (!hasDue(t) || isCompleted(t)) return false;
      const due = dayjs.unix(toUnix(t.end_date));
      const in48h = now.add(48, "hour");
      return due.isAfter(now) && due.isBefore(in48h);
    }).length;

    const dueThisWeek = tasks.filter((t) => {
      if (!hasDue(t) || isCompleted(t)) return false;
      const due = dayjs.unix(toUnix(t.end_date));
      return due.isAfter(startOfWeek) && due.isBefore(endOfWeek);
    }).length;

    const needReview = tasks.filter(
      (t) =>
        (t?.todo && String(t.todo).toLowerCase() === "review") ||
        t?.client_review === 1
    ).length;

    const totalTask = tasks.length;

    return [
      { title: "Due Today", value: dueToday, cardBorder: "!border-l-4 border-[#0FA3B1]" },
      { title: "Overdue Task", value: overdueTask, cardBorder: "!border-l-4 border-[#EC221F]" },
      { title: "Critical Deadlines", value: criticalDeadlines, cardBorder: "!border-l-4 border-[#E8B931]" },
      { title: "Due This Week", value: dueThisWeek, cardBorder: "!border-l-4 border-[#0FA3B1]" },
      { title: "Need Review", value: needReview, cardBorder: "!border-l-4 border-[#E8B931]" },
      { title: "Total Task", value: totalTask, cardBorder: "!border-l-4 border-[#0FA3B1]" },
    ];
  }, [tasks, now, startOfToday, endOfToday, startOfWeek, endOfWeek]);

  // === di sini inti filter dari query ?category=... ===
  const filteredTasks = useMemo(() => {
    if (!category) return tasks;

    switch (category) {
      case "new": // kita samakan ke "Due Today"
        return tasks.filter(
          (t) =>
            hasDue(t) &&
            !isCompleted(t) &&
            dayjs.unix(toUnix(t.end_date)).isAfter(startOfToday) &&
            dayjs.unix(toUnix(t.end_date)).isBefore(endOfToday)
        );
      case "overdue":
        return tasks.filter(
          (t) =>
            hasDue(t) &&
            !isCompleted(t) &&
            dayjs.unix(toUnix(t.end_date)).isBefore(now)
        );
      case "critical":
        return tasks.filter((t) => {
          if (!hasDue(t) || isCompleted(t)) return false;
          const due = dayjs.unix(toUnix(t.end_date));
          const in48h = now.add(48, "hour");
          return due.isAfter(now) && due.isBefore(in48h);
        });
      case "due_this_week":
        return tasks.filter((t) => {
          if (!hasDue(t) || isCompleted(t)) return false;
          const due = dayjs.unix(toUnix(t.end_date));
          return due.isAfter(startOfWeek) && due.isBefore(endOfWeek);
        });
      case "need_review":
        return tasks.filter(
          (t) =>
            (t?.todo && String(t.todo).toLowerCase() === "review") ||
            t?.client_review === 1
        );
      case "total_task":
        return tasks;
      // "new_task_assigned" belum punya field jelas di data, jadi fallback ke semua
      case "new_task_assigned":
        return tasks;
      default:
        return tasks;
    }
  }, [
    category,
    tasks,
    now,
    startOfToday,
    endOfToday,
    startOfWeek,
    endOfWeek,
  ]);

  const handleStatusUpdate = useCallback(async (record, newStatus) => {
    try {
      await axiosInstance.put(`/task/${record.task_id}`, {
        type: "todo",
        value: newStatus,
      });

      setTasks((prev) =>
        prev.map((t) =>
          t.task_id === record.task_id
            ? { ...t, todo: newStatus, status: newStatus }
            : t
        )
      );

      message.success(`Status "${record.name || record.title}" diperbarui`);
    } catch (err) {
      console.error(err);
      message.error("Gagal update status");
    }
  }, []);

  const itemsTabs = [
    {
      key: "1",
      label: "Overview",
      children: (
        <Overview
          overviewData={overviewData}
          isMobile={isMobile}
          isLaptop={isLaptop}
          loading={loading}
          tasks={filteredTasks} // ← yang dikirim sudah terfilter
          onChangeStatus={handleStatusUpdate}
        />
      ),
    },
    {
      key: "2",
      label: "Archived",
      children: (
        <Archived
          tasks={tasks}
          loading={loading}
          onChangeStatus={handleStatusUpdate}
        />
      ),
    },
  ];

  return (
    <>
      <section className="container pt-10">
        <div className="flex items-center justify-between">
          <h1 className="text-3xl">Tasks</h1>
          <div className="flex items-center gap-2">
            <Button className="btn-blue" onClick={() => setModalTask(true)}>
              <FontAwesomeIcon icon={faPlus} /> New Task
            </Button>
          </div>
        </div>
        <Tabs defaultActiveKey="1" items={itemsTabs} />
      </section>

      {/* modal */}
      <ModalProject
        modalProject={modalProject}
        setModalProject={setModalProject}
      />
      <ModalTask modalTask={modalTask} onCancel={() => setModalTask(false)} />
    </>
  );
}
