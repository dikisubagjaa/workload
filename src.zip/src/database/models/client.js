const { STRING } = require("sequelize");

module.exports = (sequelize, DataTypes) => {
  const Client = sequelize.define('Client', {
    client_id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
      allowNull: false,
    },
    type: {
      type: DataTypes.ENUM('PT', 'CV', 'UNOFFICIAL'),
      allowNull: false,
    },
    client_name: {
      type: STRING(255),
      allowNull: false,
    },
    address: {
      type: DataTypes.TEXT,
      allowNull: true,
    },
    brand: {
      type: DataTypes.JSON,
      allowNull: true,
    },
    pic_name: {
      type: STRING(255),
      allowNull: false,
    },
    pic_email: {
      type: STRING(255),
      allowNull: false,
    },
    pic_phone: {
      type: STRING(255),
      allowNull: false,
    },
    finance_name: {
      type: STRING(255),
      allowNull: false,
    },
    finance_email: {
      type: STRING(255),
      allowNull: false,
    },
    finance_phone: {
      type: STRING(255),
      allowNull: false,
    },
    division: {
      type: STRING(255),
      allowNull: false,
    },
    created: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    created_by: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    updated: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    updated_by: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    deleted: {
      type: DataTypes.INTEGER,
      allowNull: true,
    },
    deleted_by: {
      type: DataTypes.INTEGER,
      allowNull: true,
    }
  }, {
    tableName: 'client',
    timestamps: false,
    defaultScope: {
      where: {
        deleted: null,
        deleted_by: null
      }
    }
  });

  Client.associate = function(models) {
    Client.hasMany(models.Project, {
      foreignKey: 'client_id',
      as: 'Projects'
    });
  };

  return Client;
};
