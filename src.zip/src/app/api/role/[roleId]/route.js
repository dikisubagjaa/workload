// src/app/api/role/[roleId]/route.js
import 'server-only';
import { NextResponse } from 'next/server';
import db from '@/database/models';
import { withAuth } from '@/utils/session';

const { Role, Sequelize } = db;
const { Op } = Sequelize;

const nowUnix = () => Math.floor(Date.now() / 1000);

function sanitizeMenuAccess(val) {
  if (val == null) return undefined; // undefined → jangan update kolom ini
  if (Array.isArray(val)) {
    const arr = val
      .map((x) => (typeof x === 'string' ? x.trim() : ''))
      .filter(Boolean);
    return arr.filter((v, i) => arr.indexOf(v) === i); // unique
  }
  try {
    const parsed = JSON.parse(val);
    if (Array.isArray(parsed)) return sanitizeMenuAccess(parsed);
  } catch { }
  return []; // kalau dikirim tapi invalid → jadikan array kosong
}

function normSlug(s) {
  if (!s) return '';
  return String(s).trim().toLowerCase()
    .replace(/[^a-z0-9_-]+/g, '-')
    .replace(/^-+|-+$/g, '');
}

function parseIdOrNull(s) {
  const n = Number(s);
  return Number.isFinite(n) && String(n) === String(s) ? n : null;
}

async function findRoleByParam(roleId) {
  const asId = parseIdOrNull(roleId);
  const where = asId != null
    ? { [Op.or]: [{ role_id: asId }, { slug: String(roleId) }] }
    : { slug: String(roleId) };
  return Role.findOne({ where }); // defaultScope sudah exclude soft-deleted
}

// ============================
// GET /api/role/[roleId]
// ============================
export const GET = withAuth(async function GET_HANDLER(_req, { params }, _currentUser) {
  try {
    const roleId = params?.roleId;
    if (!roleId) {
      return NextResponse.json({ ok: false, error: 'roleId is required' }, { status: 400 });
    }

    const role = await findRoleByParam(roleId);
    if (!role) {
      return NextResponse.json({ ok: false, error: 'Role not found' }, { status: 404 });
    }

    return NextResponse.json({ ok: true, role }, { status: 200 });
  } catch (error) {
    console.error('GET /api/role/[roleId] error:', error);
    return NextResponse.json({ ok: false, error: error?.message || 'Failed to get role' }, { status: 500 });
  }
});

// ============================
// PUT /api/role/[roleId]  (update)
// Body (JSON, camelCase):
//  - title?        : string  (alias: name?)
//  - slug?         : string  (unique, will be normalized)
//  - description?  : string|null
//  - menu_access?  : string[] | JSON-string
// ============================
export const PUT = withAuth(async function PUT_HANDLER(req, { params }, currentUser) {
  let t = null;
  try {
    const roleId = params?.roleId;
    if (!roleId) {
      return NextResponse.json({ ok: false, error: 'roleId is required' }, { status: 400 });
    }

    const body = await req.json().catch(() => ({}));

    // Support alias "name" -> title
    const titleRaw = body?.title ?? body?.name;
    const title = titleRaw != null ? String(titleRaw).trim() : undefined;

    const slugRaw = body?.slug;
    const slug = slugRaw != null ? normSlug(slugRaw) : undefined;

    const description =
      body?.description === null ? null
        : body?.description !== undefined ? String(body.description)
          : undefined;

    const menu_access = sanitizeMenuAccess(body?.menu_access);

    const fields = {};
    if (title !== undefined) fields.title = title;
    if (slug !== undefined) fields.slug = slug;
    if (description !== undefined) fields.description = description;
    if (menu_access !== undefined) fields.menu_access = menu_access;

    if (Object.keys(fields).length === 0) {
      return NextResponse.json({ ok: false, error: 'No fields to update' }, { status: 400 });
    }

    const target = await findRoleByParam(roleId);
    if (!target) {
      return NextResponse.json({ ok: false, error: 'Role not found' }, { status: 404 });
    }

    // Uniqueness check for slug (if provided)
    if (fields.slug) {
      const exists = await Role.findOne({
        where: {
          slug: fields.slug,
          role_id: { [Op.ne]: target.role_id },
        },
      });
      if (exists) {
        return NextResponse.json({ ok: false, error: 'slug already exists' }, { status: 409 });
      }
    }

    t = await db.sequelize.transaction();
    const now = nowUnix();
    fields.updated = now;
    fields.updated_by = currentUser?.user_id;

    await Role.update(fields, { where: { role_id: target.role_id }, transaction: t });
    const updated = await Role.findOne({ where: { role_id: target.role_id }, transaction: t });

    await t.commit();
    return NextResponse.json({ ok: true, role: updated }, { status: 200 });
  } catch (error) {
    if (t) { try { await t.rollback(); } catch { } }
    console.error('PUT /api/role/[roleId] error:', error);
    return NextResponse.json({ ok: false, error: error?.message || 'Failed to update role' }, { status: 500 });
  }
});

// ============================
// DELETE /api/role/[roleId]  (soft delete)
// ============================
export const DELETE = withAuth(async function DELETE_HANDLER(_req, { params }, currentUser) {
  let t = null;
  try {
    const roleId = params?.roleId;
    if (!roleId) {
      return NextResponse.json({ ok: false, error: 'roleId is required' }, { status: 400 });
    }

    const target = await findRoleByParam(roleId);
    if (!target) {
      return NextResponse.json({ ok: false, error: 'Role not found' }, { status: 404 });
    }

    t = await db.sequelize.transaction();
    const now = nowUnix();

    const fields = {
      deleted: now,
      deleted_by: currentUser?.user_id,
      updated: now,
      updated_by: currentUser?.user_id,
    };

    await Role.update(fields, { where: { role_id: target.role_id }, transaction: t });
    await t.commit();

    return NextResponse.json({ ok: true }, { status: 200 });
  } catch (error) {
    if (t) { try { await t.rollback(); } catch { } }
    console.error('DELETE /api/role/[roleId] error:', error);
    return NextResponse.json({ ok: false, error: error?.message || 'Failed to delete role' }, { status: 500 });
  }
});
