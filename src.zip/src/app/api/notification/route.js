export const dynamic = 'force-dynamic';
export const revalidate = 0;

import { NextResponse } from 'next/server';
import db from '@/database/models';

export async function GET(req) {
  const url = new URL(req.url);
  const userId = Number(url.searchParams.get('userId') || 1);

  const page = Math.max(1, parseInt(url.searchParams.get('page') || '1', 10));
  const limit = Math.min(100, Math.max(1, parseInt(url.searchParams.get('limit') || '20', 10)));
  const offset = (page - 1) * limit;

  const { Notification } = db;
  const where = { user_id: userId };

  const { rows, count } = await Notification.findAndCountAll({
    where,
    order: [['created', 'DESC']],
    limit,
    offset,
    raw: true,
  });

  const data = rows.map(r => ({
    notificationId: r.notification_id,
    userId: r.user_id,
    sender: r.sender,
    description: r.description,
    url: r.url,
    payload: r.payload,
    isRead: r.is_read === 'true',
    created: r.created, // unix seconds
    updated: r.updated,
  }));

  return NextResponse.json({
    ok: true,
    data,
    meta: { page, limit, total: count, totalPages: Math.ceil(count / limit) },
  }, { headers: { 'Cache-Control': 'no-store' } });
}
