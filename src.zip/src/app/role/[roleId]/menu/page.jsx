// src/app/role/[roleId]/menu/page.jsx
"use client";

import { useEffect, useMemo, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import {
  Alert,
  Button,
  Card,
  Checkbox,
  Divider,
  Spin,
  Tag,
  message,
} from "antd";
import {
  ArrowLeftOutlined,
  SaveOutlined,
  ReloadOutlined,
} from "@ant-design/icons";
import axiosInstance from "@/utils/axios";
import dayjs from "dayjs";

export default function RoleMenuAccessPage() {
  const params = useParams();
  const router = useRouter();
  const roleId = params?.roleId;

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  const [role, setRole] = useState(null);
  const [menus, setMenus] = useState([]);
  const [selectedMenuIds, setSelectedMenuIds] = useState(new Set());
  const [initialSelected, setInitialSelected] = useState(new Set());
  const [error, setError] = useState("");

  // ===== FETCH ROLE + MENUS =====
  useEffect(() => {
    if (!roleId) return;

    async function loadData() {
      setLoading(true);
      setError("");
      try {
        const [roleRes, menuRes] = await Promise.all([
          axiosInstance.get(`/role/${roleId}`),
          axiosInstance.get("/menu"),
        ]);

        const roleData =
          roleRes.data?.role ||
          roleRes.data?.data ||
          roleRes.data;

        const menuData = menuRes.data?.menus || menuRes.data || [];

        setRole(roleData);
        setMenus(menuData);

        const accessArray = normalizeMenuAccess(roleData?.menu_access);
        const accessSet = new Set(accessArray);
        setSelectedMenuIds(accessSet);
        setInitialSelected(new Set(accessArray));
      } catch (err) {
        console.error(err);
        setError(
          err?.response?.data?.error ||
            "Failed to load role or menus data."
        );
        message.error("Failed to load role or menus data.");
      } finally {
        setLoading(false);
      }
    }

    loadData();
  }, [roleId]);

  // Normalise menu_access from API (array of ids or array of objects)
  function normalizeMenuAccess(menu_access) {
    if (!Array.isArray(menu_access)) return [];
    if (menu_access.length && typeof menu_access[0] === "object") {
      return menu_access.map((m) => m.menu_id);
    }
    return menu_access;
  }

  // Helper: global show/hidden flag
  const isMenuShown = (menu) => {
    const v = menu?.is_show;
    return v === true || v === "true" || v === 1 || v === "1";
  };

  // ===== MEMO: MAP MENU, CHILDREN, ROOT =====
  const menuById = useMemo(
    () => Object.fromEntries(menus.map((m) => [m.menu_id, m])),
    [menus]
  );

  const childrenMap = useMemo(() => {
    const map = {};
    menus.forEach((m) => {
      const parentKey = m.parent_id ?? null;
      if (!map[parentKey]) map[parentKey] = [];
      map[parentKey].push(m);
    });

    // sort by ordered asc
    Object.keys(map).forEach((key) => {
      map[key].sort((a, b) => (a.ordered || 0) - (b.ordered || 0));
    });

    return map;
  }, [menus]);

  const rootMenus = useMemo(
    () =>
      (childrenMap[null] || []).sort(
        (a, b) => (a.ordered || 0) - (b.ordered || 0)
      ),
    [childrenMap]
  );

  // ===== HANDLER: TOGGLE MENU =====
  const toggleMenu = (menuId, checked) => {
    setSelectedMenuIds((prev) => {
      const next = new Set(prev);
      if (checked) {
        next.add(menuId);
      } else {
        next.delete(menuId);
      }
      return next;
    });
  };

  const toggleGroup = (rootMenu, checked) => {
    const childList = childrenMap[rootMenu.menu_id] || [];
    setSelectedMenuIds((prev) => {
      const next = new Set(prev);
      if (checked) {
        next.add(rootMenu.menu_id);
        childList.forEach((c) => next.add(c.menu_id));
      } else {
        next.delete(rootMenu.menu_id);
        childList.forEach((c) => next.delete(c.menu_id));
      }
      return next;
    });
  };

  const isGroupFullySelected = (rootMenu) => {
    const childList = childrenMap[rootMenu.menu_id] || [];
    const allIds = [rootMenu.menu_id, ...childList.map((c) => c.menu_id)];
    return allIds.every((id) => selectedMenuIds.has(id));
  };

  const isGroupPartiallySelected = (rootMenu) => {
    const childList = childrenMap[rootMenu.menu_id] || [];
    const allIds = [rootMenu.menu_id, ...childList.map((c) => c.menu_id)];
    const someChecked = allIds.some((id) => selectedMenuIds.has(id));
    const allChecked = allIds.every((id) => selectedMenuIds.has(id));
    return someChecked && !allChecked;
  };

  const hasChanges = useMemo(() => {
    if (initialSelected.size !== selectedMenuIds.size) return true;
    for (const id of selectedMenuIds) {
      if (!initialSelected.has(id)) return true;
    }
    return false;
  }, [initialSelected, selectedMenuIds]);

  // ===== SAVE =====
  const handleSave = async () => {
    if (!role) return;
    setSaving(true);
    try {
      const payload = {
        title: role.title,
        slug: role.slug,
        description: role.description,
        menu_access: Array.from(selectedMenuIds),
      };

      await axiosInstance.put(`/role/${role.role_id}`, payload);

      setInitialSelected(new Set(selectedMenuIds));
      message.success("Role access updated successfully.");
    } catch (err) {
      console.error(err);
      message.error(
        err?.response?.data?.error || "Failed to update role access."
      );
    } finally {
      setSaving(false);
    }
  };

  const handleReset = () => {
    setSelectedMenuIds(new Set(initialSelected));
  };

  const handleBack = () => {
    router.push("/role");
  };

  // ===== UI RENDER =====
  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[300px]">
        <Spin size="large" />
      </div>
    );
  }

  if (!role) {
    return (
      <div className="p-4 md:p-6 space-y-4">
        <Button
          icon={<ArrowLeftOutlined />}
          onClick={handleBack}
          className="mb-2"
        >
          Back to Roles
        </Button>
        <Alert
          type="error"
          message="Role not found"
          description={error || "Unable to load this role."}
          showIcon
        />
      </div>
    );
  }

  const totalSelected = selectedMenuIds.size;
  const totalMenus = menus.length;

  return (
    <div className="p-4 md:p-6 space-y-4">
      {/* Header & Back */}
      <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
        <div className="flex items-center gap-3">
          <Button
            icon={<ArrowLeftOutlined />}
            onClick={handleBack}
            className="mr-1"
          >
            Back
          </Button>
          <div>
            <h1 className="text-xl font-semibold">
              Edit Role Access: {role.title}
            </h1>
            <p className="text-xs text-gray-500">
              Slug: <code>{role.slug}</code>
            </p>
          </div>
        </div>

        <div className="flex flex-col sm:flex-row gap-2 sm:items-center">
          <Button
            icon={<ReloadOutlined />}
            onClick={handleReset}
            disabled={!hasChanges}
          >
            Reset
          </Button>
          <Button
            type="primary"
            icon={<SaveOutlined />}
            onClick={handleSave}
            loading={saving}
            disabled={!hasChanges}
          >
            Save changes
          </Button>
        </div>
      </div>

      {/* Info Role & Summary */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <Card size="small" title="Role information" className="lg:col-span-2">
          <div className="space-y-2 text-sm">
            <div>
              <span className="font-semibold">Title:</span>{" "}
              <span>{role.title}</span>
            </div>
            <div>
              <span className="font-semibold">Slug:</span>{" "}
              <code>{role.slug}</code>
            </div>
            <div>
              <span className="font-semibold">Description:</span>{" "}
              <span>{role.description || "-"}</span>
            </div>
            <div>
              <span className="font-semibold">Created at:</span>{" "}
              <span>
                {role.created
                  ? dayjs.unix(role.created).format("DD MMM YYYY HH:mm")
                  : "-"}
              </span>
            </div>
          </div>
        </Card>

        <Card size="small" title="Access summary">
          <div className="space-y-2 text-sm">
            <div>
              <span className="font-semibold">Selected menus:</span>{" "}
              <span>
                {totalSelected} / {totalMenus}
              </span>
            </div>
            <div>
              <span className="font-semibold">Status:</span>{" "}
              {hasChanges ? (
                <Tag color="orange">Unsaved changes</Tag>
              ) : (
                <Tag color="green">All changes saved</Tag>
              )}
            </div>
            <div className="text-xs text-gray-500">
              This page controls which menus the role is allowed to access.
              Menus marked as{" "}
              <Tag color="red" style={{ marginInline: 2 }}>
                Hidden
              </Tag>
              (global <code>is_show = false</code>) will not appear in the
              sidebar, even if they are checked here.
            </div>
          </div>
        </Card>
      </div>

      <Divider />

      {/* Menu categories per parent */}
      <div className="space-y-4">
        {rootMenus.length === 0 && (
          <Alert
            type="info"
            message="No menus found"
            description="There are no menus configured yet. Please add menus in the Menu Management page first."
            showIcon
          />
        )}

        {rootMenus.map((root) => {
          const children = childrenMap[root.menu_id] || [];
          const groupChecked = isGroupFullySelected(root);
          const groupIndeterminate = isGroupPartiallySelected(root);
          const rootShown = isMenuShown(root);

          return (
            <Card
              key={root.menu_id}
              size="small"
              className="border border-gray-100 shadow-sm"
            >
              <div className="flex flex-col gap-2 md:flex-row md:items-center md:justify-between mb-2">
                <div className="flex flex-wrap items-center gap-2">
                  <Checkbox
                    checked={groupChecked}
                    indeterminate={groupIndeterminate}
                    onChange={(e) => toggleGroup(root, e.target.checked)}
                  >
                    <span className="font-semibold">{root.title}</span>
                  </Checkbox>
                  {root.type && (
                    <Tag size="small" color="blue">
                      {root.type}
                    </Tag>
                  )}
                  <Tag
                    size="small"
                    color={rootShown ? "green" : "red"}
                  >
                    {rootShown ? "Shown" : "Hidden"}
                  </Tag>
                  {root.path && (
                    <span className="text-xs text-gray-500">
                      ({root.path})
                    </span>
                  )}
                </div>

                <div className="text-xs text-gray-400">
                  {children.length} submenu
                </div>
              </div>

              {children.length > 0 && (
                <div className="border-t border-dashed pt-2 mt-2 space-y-1">
                  {children.map((child) => {
                    const childShown = isMenuShown(child);
                    return (
                      <div
                        key={child.menu_id}
                        className="flex flex-col sm:flex-row sm:items-center sm:justify-between py-1 px-2 rounded hover:bg-gray-50"
                      >
                        <div className="flex flex-wrap items-center gap-2">
                          <Checkbox
                            checked={selectedMenuIds.has(child.menu_id)}
                            onChange={(e) =>
                              toggleMenu(child.menu_id, e.target.checked)
                            }
                          >
                            <span className="text-sm">{child.title}</span>
                          </Checkbox>
                          {child.type && (
                            <Tag
                              size="small"
                              color={
                                child.type === "button"
                                  ? "purple"
                                  : child.type === "dashboard"
                                  ? "green"
                                  : "blue"
                              }
                            >
                              {child.type}
                            </Tag>
                          )}
                          <Tag
                            size="small"
                            color={childShown ? "green" : "red"}
                          >
                            {childShown ? "Shown" : "Hidden"}
                          </Tag>
                        </div>
                        <div className="text-xs text-gray-500 mt-1 sm:mt-0">
                          {child.path || "-"}
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </Card>
          );
        })}
      </div>
    </div>
  );
}
