// src/app/api/task/[taskId]/subtaskitem/[subtaskItemId]/upload-attachment/route.js
export const dynamic = 'force-dynamic';
export const revalidate = 0;

import { NextResponse } from 'next/server';
import { Task, TaskAttachment } from "@/database/models";
import { uploadFile, getFilename } from "@/utils/imageHelpers";
import { Op } from 'sequelize';
import { getUnixTimestampUTC } from "@/utils/dateHelpers";
import { withAuth } from "@/utils/session";

export const POST = withAuth(async function POST_HANDLER(req, { params }, currentUser) {
    try {
        const { taskId, subtaskItemId } = params;

        if (!taskId) {
            return NextResponse.json({ error: "Subtask item not found." }, { status: 404 });
        }
        if (!subtaskItemId) {
            return NextResponse.json({ error: "Subtask item not found." }, { status: 404 });
        }

        // Ambil detail subtask item (+attachments root + revisions)
        const subtaskItemDetail = await Task.findOne({
            where: { task_id: subtaskItemId },
            attribute: ['task_id', 'title', 'priority', 'todo'],
            include: [
                {
                    model: TaskAttachment,
                    as: 'Attachments',
                    separate: true,
                    where: { revision_id: null },
                    order: [['attachment_id', 'DESC']],
                    include: [
                        {
                            model: TaskAttachment,
                            as: 'revisionFiles',
                            separate: true,
                            order: [['attachment_id', 'DESC']],
                            required: false
                        },
                    ],
                },
            ]
        });
        if (!subtaskItemDetail) {
            return NextResponse.json({ error: "Subtask item not found." }, { status: 404 });
        }

        const contentType = req.headers.get("content-type");
        if (!contentType || !contentType.includes("multipart/form-data")) {
            return NextResponse.json({ error: "Missing or invalid Content-Type." }, { status: 400 });
        }

        const formData = await req.formData();
        const file = formData.get("file");
        const rawRev = formData.get("attachment_id"); // optional, untuk re-parent revisi

        if (!file) {
            return NextResponse.json({ error: "File not found in formData." }, { status: 400 });
        }

        // === Simpan file via helper yang sudah standar ===
        // out: { original, resized? } — kita hanya butuh nama file fisik original (tanpa expose path)
        const out = await uploadFile(file, "task");
        const originalFileName = String(file.name || "").trim();
        const storedName = getFilename(out.original); // nama file fisik yang tersimpan

        const nowUnix = getUnixTimestampUTC();
        const newAttachment = await TaskAttachment.create({
            task_id: subtaskItemId,
            filename: storedName,              // nama file fisik
            real_filename: originalFileName,   // nama asli dari user
            is_star: "true",                   // default bintang untuk file baru
            task_payload: subtaskItemDetail,
            user_payload: currentUser,
            created: nowUnix,
            created_by: currentUser.user_id,
            updated: nowUnix,
            updated_by: currentUser.user_id,
            deleted: null,
            deleted_by: null,
        });

        // === Handle "re-parent" untuk revisi bila ada attachment_id lama dikirim ===
        const normalizeOptionalId = (v) => {
            if (v == null) return null;
            const s = String(v).trim().toLowerCase();
            if (s === '' || s === 'null' || s === 'undefined') return null;
            const n = Number(s);
            return Number.isInteger(n) && n > 0 ? n : null;
        };
        const revisionId = normalizeOptionalId(rawRev);

        if (revisionId !== null) {
            // 1) Pindahkan root lama dan semua revisinya ke root BARU
            await TaskAttachment.update(
                { revision_id: newAttachment.attachment_id },
                {
                    where: {
                        [Op.or]: [
                            { attachment_id: revisionId },  // root lama
                            { revision_id: revisionId }     // semua revisi root lama
                        ],
                        attachment_id: { [Op.ne]: newAttachment.attachment_id }
                    }
                }
            );

            // 2) Pastikan attachment baru tetap root (revision_id = null)
            if (newAttachment.revision_id !== null) {
                await TaskAttachment.update(
                    { revision_id: null },
                    { where: { attachment_id: newAttachment.attachment_id } }
                );
            }

            // 3) Reset bintang pada semua anggota grup BARU (kecuali yang baru)
            await TaskAttachment.update(
                { is_star: 'false' },
                {
                    where: {
                        [Op.or]: [
                            { attachment_id: newAttachment.attachment_id }, // root baru
                            { revision_id: newAttachment.attachment_id }    // semua revisinya
                        ],
                        attachment_id: { [Op.ne]: newAttachment.attachment_id }
                    }
                }
            );
        }

        // Ambil ulang detail subtask item untuk response terkini
        const subtaskItemDetail2 = await Task.findOne({
            where: { task_id: subtaskItemId },
            attribute: ['task_id', 'title', 'priority', 'todo'],
            include: [
                {
                    model: TaskAttachment,
                    as: 'Attachments',
                    separate: true,
                    where: { revision_id: null },
                    order: [['attachment_id', 'DESC']],
                    include: [
                        {
                            model: TaskAttachment,
                            as: 'revisionFiles',
                            separate: true,
                            order: [['attachment_id', 'DESC']],
                            required: false
                        },
                    ],
                },
            ]
        });

        return NextResponse.json({
            message: "File uploaded successfully to subtask item!",
            taskAttachment: newAttachment.toJSON(),
            taskSubtaskItem: subtaskItemDetail2,
        }, { status: 201 });

    } catch (error) {
        console.error("Error uploading file to subtask item:", error);
        return NextResponse.json({
            error: error.original?.sqlMessage || error.message || "An error occurred while uploading file to subtask item."
        }, { status: 500 });
    }
});
