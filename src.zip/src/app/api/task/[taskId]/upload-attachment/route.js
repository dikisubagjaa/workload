export const dynamic = 'force-dynamic';
export const revalidate = 0;

import { NextResponse } from 'next/server';
import { Task, TaskAttachment } from "@/database/models";
import { getUnixTimestampUTC } from "@/utils/dateHelpers";
import { withAuth } from "@/utils/session";
import { uploadFile, getFilename } from "@/utils/imageHelpers";

export const POST = withAuth(async function POST_HANDLER(req, { params }, currentUser) {
    try {
        const { taskId } = params;

        // Pastikan task ada
        const taskData = await Task.findOne({ where: { task_id: taskId } });
        if (!taskData) {
            return NextResponse.json({ error: "Task not found" }, { status: 404 });
        }

        // Validasi content-type
        const contentType = req.headers.get("content-type");
        if (!contentType || !contentType.includes("multipart/form-data")) {
            return NextResponse.json({ error: "Missing or invalid Content-Type" }, { status: 400 });
        }

        // Ambil file
        const formData = await req.formData();
        const file = formData.get("file");
        if (!file) {
            console.log("Backend Upload: ERROR - File not found in formData.");
            return NextResponse.json({ error: "File not found" }, { status: 400 });
        }

        const originalFileName = String(file.name || "").trim();
        console.log("Backend Upload: incoming file =", originalFileName);

        // Cek duplikat berdasarkan nama asli + task_id
        const existingAttachment = await TaskAttachment.findOne({
            where: { real_filename: originalFileName, task_id: taskId },
        });

        if (existingAttachment) {
            console.warn("Backend Upload: Attachment already exists for this task. Returning existing attachment.");
            return NextResponse.json(
                { message: "File already exists, no duplication.", taskAttachment: existingAttachment.toJSON() },
                { status: 200 }
            );
        }

        // === Simpan file via helper yang seragam ===
        const out = await uploadFile(file, "task");

        // Simpan hanya kolom sesuai model (TANPA menambah kolom baru)
        const nowUnix = getUnixTimestampUTC();
        const newAttachment = await TaskAttachment.create({
            filename: getFilename(out.original),
            real_filename: originalFileName,
            task_id: taskId,
            created: nowUnix,
            updated: nowUnix,
            created_by: currentUser.user_id,
            updated_by: currentUser.user_id,
            task_payload: taskData,
            user_payload: currentUser,
        });

        return NextResponse.json(
            { message: "Upload successful!", taskAttachment: newAttachment.toJSON() },
            { status: 201 }
        );

    } catch (error) {
        console.error("Backend Upload: ERROR", error);
        return NextResponse.json({
            error: error.original?.sqlMessage || error.message || "An error occurred on the server while uploading the file."
        }, { status: 500 });
    }
});
