// src/components/modal/ModalClient.jsx
"use client";

import React, { useState, useEffect, useCallback } from 'react';
import { Modal, Form, Input, Select, Button, message, Spin } from 'antd';
import { LoadingOutlined } from '@ant-design/icons';
import axiosInstance from '@/utils/axios';
import dayjs from 'dayjs'; 

const { Option } = Select;
const { TextArea } = Input;

export default function ModalClient({
    isModalVisible,
    setIsModalVisible,
    editingClient,
    setEditingClient,
    fetchClients 
}) {
    const [form] = Form.useForm();
    const [loading, setLoading] = useState(false); 
    const [brandOptions, setBrandOptions] = useState([]); 
   const [loadingBrands, setLoadingBrands] = useState(false); // <-- State baru untuk loading brand

    // --- Fetch Brand Options ---
    const fetchBrandOptions = useCallback(async () => {
       setLoadingBrands(true); // Mulai loading
        try {
            const response = await axiosInstance.get('/brand'); 
            setBrandOptions(response.data.brand.map(b => ({ value: b.brand_id, label: b.title }))); 
        } catch (error) {
            console.error("Error fetching brand options:", error.response || error.message);
            message.error("Failed to load brand options.");
        } finally {
           setLoadingBrands(false); // Akhiri loading
        }
    }, []);

    useEffect(() => {
        if (isModalVisible) {
            if (editingClient) {
                form.setFieldsValue({
                    type: editingClient.type,
                    client_name: editingClient.client_name,
                    brand: editingClient.brand || [], 
                    division: editingClient.division,
                    address: editingClient.address,
                    pic_name: editingClient.pic_name,
                    pic_phone: editingClient.pic_phone,
                    pic_email: editingClient.pic_email,
                    finance_name: editingClient.finance_name,
                    finance_phone: editingClient.finance_phone,
                    finance_email: editingClient.finance_email,
                });
            } else {
                form.resetFields(); 
            }
        }
     }, [isModalVisible, editingClient, form]); // Hapus fetchBrandOptions dari dependensi

   
    const handleOk = async () => {
       setLoading(true); // <-- Pastikan loading diaktifkan di awal
        try {
            const values = await form.validateFields();
            // Konversi brand ke JSON string jika perlu (tergantung cara DB menyimpannya)
            const payload = {
                ...values,
                brand: values.brand || [], 
            };
        
            if (editingClient) {
                await axiosInstance.put(`/client/${editingClient.client_id}`, payload); 
                message.success("Client updated successfully!");
            } else {
                await axiosInstance.post('/client', payload); 
                message.success("Client added successfully!");
            }
            setIsModalVisible(false);
            setEditingClient(null);
            form.resetFields();
            fetchClients(); 
        } catch (error) {
           console.error("DEBUG ModalClient: Form validation failed or API error:", error); // LOG Error
            message.error(`Failed to save client: ${error.response?.data?.error || error.message || 'Validation failed'}`);
        } finally {
           setLoading(false); // <-- Pastikan loading dinonaktifkan di akhir
        }
    };

    const handleCancel = () => { 
        setIsModalVisible(false);
        setEditingClient(null);
        form.resetFields();
    };

    return (
        <Modal
            title={editingClient ? "Edit Client" : "Add New Client"}
            open={isModalVisible}
            onOk={handleOk}
            onCancel={handleCancel}
            confirmLoading={loading}
            width={600}
        >
            <Form form={form} layout="vertical">
                <Form.Item name="type" label="Client Type" rules={[{ required: true, message: 'Please select client type!' }]}>
                    <Select placeholder="Select Type">
                        <Option value="PT">PT</Option>
                        <Option value="CV">CV</Option>
                        <Option value="UNOFFICIAL">Unofficial</Option>
                    </Select>
                </Form.Item>
                <Form.Item name="client_name" label="Client Name" rules={[{ required: true, message: 'Please input client name!' }]}>
                    <Input />
                </Form.Item>
                <Form.Item name="brand" label="Brand (separate with commas)" rules={[{ required: true, message: 'Please select or add brands!' }]}>
                    <Select
                        mode="tags"
                        style={{ width: '100%' }}
                        placeholder="Select or add brands"
                        tokenSeparators={[',']}
                       options={brandOptions} 
                       loading={loadingBrands} // <-- Tampilkan loading
                       onDropdownVisibleChange={(open) => { // <-- Panggil fetch saat dropdown dibuka
                           if (open) {
                               fetchBrandOptions();
                           }
                       }}
                       notFoundContent={loadingBrands ? <Spin size="small" /> : 'No Data'} // <-- Tampilkan spinner saat loading
                    />
                </Form.Item>
                <Form.Item name="division" label="Division">
                    <Input />
                </Form.Item>
                <Form.Item name="address" label="Address">
                    <TextArea rows={2} />
                </Form.Item>
                <Form.Item name="pic_name" label="PIC Name" rules={[{ required: true, message: 'Please input PIC Name!' }]}>
                    <Input />
                </Form.Item>
                <Form.Item name="pic_phone" label="PIC Phone" rules={[{ required: true, message: 'Please input PIC Phone!' }]}>
                    <Input />
                </Form.Item>
                <Form.Item name="pic_email" label="PIC Email" rules={[{ required: true, message: 'Please input PIC Email!' }, { type: 'email', message: 'Please enter a valid email!' }]}>
                    <Input />
                </Form.Item>
                <Form.Item name="finance_name" label="Finance Contact Name">
                    <Input />
                </Form.Item>
                <Form.Item name="finance_phone" label="Finance Contact Phone">
                    <Input />
                </Form.Item>
                <Form.Item name="finance_email" label="Finance Contact Email" rules={[{ type: 'email', message: 'Please enter a valid email!' }]}>
                    <Input />
                </Form.Item>
            </Form>
        </Modal>
    );
}