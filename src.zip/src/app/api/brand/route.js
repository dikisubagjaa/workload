export const dynamic = 'force-dynamic';
export const revalidate = 0;

import { NextResponse } from "next/server";
import db from "@/database/models";
import dayjs from "dayjs";
import { withActive } from "@/utils/session";
const { Brand } = db;
export const GET = withActive(async function GET_HANDLER(req) {
    try {
        const brands = await Brand.findAll({ where: { deleted: null } });
        return NextResponse.json({ brand: brands }, { status: 200 });
    } catch (error) {
        console.error("Error fetching Brands:", error);
        return NextResponse.json({ error: "Failed to fetch data" }, { status: 500 });
    }
});

// POST Handler yang Diperbaiki
export const POST = withActive(async function POST_HANDLER(req, context, currentUser) {
    try {
        const body = await req.json();

        // 1. Validasi input
        if (!body.title || body.title.trim() === '') {
            return NextResponse.json({ error: "Title is required." }, { status: 400 });
        }

        const nowUnix = dayjs().unix();

        const newBrand = await Brand.create({
            title: body.title,
            created: nowUnix,
            created_by: currentUser.user_id,
            updated: nowUnix,
            updated_by: currentUser.user_id,
        });

        return NextResponse.json({ message: "Brand added successfully", brand: newBrand }, { status: 201 });

    } catch (error) {
        console.error("Error adding Brand:", error);
        if (error.name === 'SequelizeUniqueConstraintError') {
            return NextResponse.json({ error: "Brand with this title already exists." }, { status: 409 });
        }
        return NextResponse.json({ error: "Failed to add brand" }, { status: 500 });
    }
});
