export const dynamic = 'force-dynamic';
export const revalidate = 0;

import { NextResponse } from 'next/server';
import { sequelize, Task, TaskAttachment } from '@/database/models';
import { Op } from 'sequelize';

export async function POST(_req, { params }) {
  const { taskId, subtaskItemId, attachmentId } = params;
  if (!attachmentId) {
    return NextResponse.json({ error: 'attachmentId is required' }, { status: 400 });
  }

  let t;
  try {
    t = await sequelize.transaction();

    // Cek attachment yang dipilih
    const selected = await TaskAttachment.findByPk(attachmentId, { transaction: t });
    if (!selected) {
      await t.rollback();
      return NextResponse.json({ error: 'Attachment not found' }, { status: 404 });
    }

    // Tentukan root saat ini (jika selected punya revision_id, berarti root = revision_id; jika tidak, dia sendiri root)
    const currentRoot = selected.revision_id
      ? await TaskAttachment.findByPk(selected.revision_id, { transaction: t })
      : selected;

    if (!currentRoot) {
      await t.rollback();
      return NextResponse.json({ error: 'Root attachment not found' }, { status: 404 });
    }

    // Jika yang dipilih SUDAH root: unstar semua lalu star root
    if (selected.attachment_id === currentRoot.attachment_id) {
      await TaskAttachment.update(
        { is_star: "false" },
        {
          where: {
            [Op.or]: [
              { attachment_id: currentRoot.attachment_id },
              { revision_id: currentRoot.attachment_id },
            ],
          },
          transaction: t,
        }
      );

      await currentRoot.update({ is_star: "true" }, { transaction: t });
      await t.commit();
      return NextResponse.json({ success: true });
    }

    // --- Promote selected menjadi root baru ---
    const oldRootId = currentRoot.attachment_id;
    const selectedId = selected.attachment_id;

    // 1) Unstar semua dalam grup lama (root + anak2)
    await TaskAttachment.update(
      { is_star: "false" },
      {
        where: {
          [Op.or]: [
            { attachment_id: oldRootId },
            { revision_id: oldRootId },
          ],
        },
        transaction: t,
      }
    );

    // 2) Jadikan selected sebagai root baru
    await TaskAttachment.update(
      { revision_id: null },
      { where: { attachment_id: selectedId }, transaction: t }
    );

    // 3) Root lama jadi child dari root baru
    await TaskAttachment.update(
      { revision_id: selectedId },
      { where: { attachment_id: oldRootId }, transaction: t }
    );

    // 4) Semua sibling lama pindah ke root baru (kecuali selected)
    await TaskAttachment.update(
      { revision_id: selectedId },
      {
        where: {
          revision_id: oldRootId,
          attachment_id: { [Op.ne]: selectedId },
        },
        transaction: t,
      }
    );

    // 5) Star hanya root baru
    await TaskAttachment.update(
      { is_star: "true" },
      { where: { attachment_id: selectedId }, transaction: t }
    );

    await t.commit();

    const subtaskItemDetail = await Task.findOne({
      where: { task_id: subtaskItemId },
      attribute: ['task_id', 'title', 'priority', 'todo'],
      include: [
        {
          model: TaskAttachment,
          as: 'Attachments',
          separate: true,
          where: { revision_id: null },
          order: [['attachment_id', 'DESC']],
          include: [
            {
              model: TaskAttachment,
              as: 'revisionFiles',
              separate: true,
              order: [['attachment_id', 'DESC']],
              required: false
            },
          ],
        },
      ]
    });
    return NextResponse.json({
      message: "File uploaded successfully to subtask item!",
      taskSubtaskItem: subtaskItemDetail,
    }, { status: 201 });

  } catch (e) {
    if (t) {
      try { await t.rollback(); } catch { }
    }
    return NextResponse.json({ error: e.message || 'Internal Server Error' }, { status: 500 });
  }
}
