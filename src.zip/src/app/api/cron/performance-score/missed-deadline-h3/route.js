// src/app/api/cron/performance-score/missed-deadline-h3/route.js
import 'server-only';
import {
    Task,
    TaskAssignment,
    PerformanceEventLog,
    Sequelize,
} from '@/database/models';
import dayjs from 'dayjs';
import tz from 'dayjs/plugin/timezone';
import { withCronLock } from '@/utils/cronLock';

dayjs.extend(tz);

export const dynamic = 'force-dynamic';
export const revalidate = 0;

const TZ = process.env.NEXT_PUBLIC_APP_TIMEZONE || 'Asia/Jakarta';

// Missed Deadline H+3 (3 hari setelah deadline, masih overdue)
const PERF_CONFIG_ID = 3;
const SCORE_VALUE = -2;

const DONE_STATUSES = ['done', 'completed', 'approved_ae'];
const CANCEL_STATUSES = ['cancel'];

export async function GET(req) {
    const t0 = Date.now();
    const { Op } = Sequelize;

    try {
        const { searchParams } = new URL(req.url);
        const dateParam = searchParams.get('date');
        const dryRun =
            String(searchParams.get('dryRun') || '').toLowerCase() === 'true';

        // eventDate = hari ini (TZ) atau ?date=YYYY-MM-DD
        const eventDate =
            dateParam && /^\d{4}-\d{2}-\d{2}$/.test(dateParam)
                ? dateParam
                : dayjs().tz(TZ).format('YYYY-MM-DD');

        const periodYear = Number(dayjs(eventDate).year());
        const periodMonth = Number(dayjs(eventDate).month() + 1);
        const periodStart = dayjs(eventDate)
            .startOf('month')
            .format('YYYY-MM-DD');

        // Target deadline = H-3 → sudah overdue 3 hari
        const targetDeadline = dayjs(eventDate)
            .subtract(3, 'day')
            .format('YYYY-MM-DD');
        const deadlineStartUnix = dayjs
            .tz(targetDeadline, TZ)
            .startOf('day')
            .unix();
        const deadlineEndUnix = dayjs
            .tz(targetDeadline, TZ)
            .endOf('day')
            .unix();

        const res = await withCronLock(
            `perf-missed-deadline-h3-${eventDate}`,
            async () => {
                // Task yang deadline-nya H-3 & masih belum selesai
                const baseWhere = {
                    end_date: { [Op.between]: [deadlineStartUnix, deadlineEndUnix] },
                    todo: {
                        [Op.notIn]: [...DONE_STATUSES, ...CANCEL_STATUSES],
                    },
                };

                // 1) Ambil semua task kandidat
                const tasks = await Task.findAll({
                    where: baseWhere,
                    attributes: ['task_id', 'title', 'end_date', 'todo', 'is_overdue'],
                    raw: true,
                });

                if (!tasks.length) {
                    return {
                        inserted: 0,
                        scanned: 0,
                        skipped: 0,
                        note: 'no missed-deadline tasks (H+3) for this date',
                    };
                }

                const taskIds = tasks.map((t) => t.task_id);

                // 2) Update is_overdue = 'true' untuk semua task yang telat & belum ditandai
                let overdueMarked = 0;
                if (!dryRun) {
                    const [affected] = await Task.update(
                        { is_overdue: 'true' },
                        {
                            where: {
                                task_id: { [Op.in]: taskIds },
                                [Op.or]: [
                                    { is_overdue: null },
                                    { is_overdue: { [Op.ne]: 'true' } },
                                ],
                            },
                        },
                    );
                    overdueMarked = affected || 0;
                }

                // 3) Ambil semua assignee
                const assigns = await TaskAssignment.findAll({
                    where: {
                        task_id: { [Op.in]: taskIds },
                    },
                    attributes: ['task_id', 'user_id'],
                    raw: true,
                });

                if (!assigns.length) {
                    return {
                        inserted: 0,
                        scanned: tasks.length,
                        skipped: 0,
                        overdueMarked,
                        note: 'no assignees',
                    };
                }

                const usersByTask = new Map();
                for (const a of assigns) {
                    if (!a.user_id) continue;
                    if (!usersByTask.has(a.task_id)) usersByTask.set(a.task_id, []);
                    usersByTask.get(a.task_id).push(a.user_id);
                }

                const allRefPairs = [];
                for (const t of tasks) {
                    const users = usersByTask.get(t.task_id) || [];
                    for (const uid of users) {
                        allRefPairs.push({ user_id: uid, ref_id: t.task_id });
                    }
                }

                if (!allRefPairs.length) {
                    return {
                        inserted: 0,
                        scanned: tasks.length,
                        skipped: 0,
                        overdueMarked,
                        note: 'no assignees after mapping',
                    };
                }

                const refIds = [...new Set(allRefPairs.map((p) => p.ref_id))];

                // 4) Cek existing log biar idempotent
                const existing = await PerformanceEventLog.findAll({
                    where: {
                        perf_config_id: PERF_CONFIG_ID,
                        event_date: eventDate,
                        ref_id: { [Op.in]: refIds },
                    },
                    attributes: ['ref_id', 'user_id'],
                    raw: true,
                });
                const existed = new Set(
                    existing.map((e) => `${e.user_id}:${e.ref_id}`),
                );

                const byIdTitle = new Map(
                    tasks.map((t) => [t.task_id, t.title]),
                );
                const byIdDeadline = new Map(
                    tasks.map((t) => [t.task_id, t.end_date]),
                );
                const byIdTodo = new Map(
                    tasks.map((t) => [t.task_id, t.todo]),
                );

                const nowUnix = Math.floor(Date.now() / 1000);
                const rows = [];
                let skipped = 0;

                for (const { user_id, ref_id } of allRefPairs) {
                    const key = `${user_id}:${ref_id}`;
                    if (existed.has(key)) {
                        skipped++;
                        continue;
                    }

                    const deadlineUnix = byIdDeadline.get(ref_id);
                    const deadlineYmd = deadlineUnix
                        ? dayjs.unix(deadlineUnix).tz(TZ).format('YYYY-MM-DD')
                        : null;

                    rows.push({
                        user_id,
                        event_date: eventDate, // hari H+3 (3 hari setelah deadline)
                        period_year: periodYear,
                        period_month: periodMonth,
                        period_start_date: periodStart,
                        perf_config_id: PERF_CONFIG_ID,
                        score_value: SCORE_VALUE,
                        source: 'task',
                        ref_id,
                        note: `Missed Deadline H+3: [#${ref_id}] ${byIdTitle.get(ref_id) || '(no title)'
                            } — todo=${byIdTodo.get(ref_id) || '-'} deadline ${deadlineYmd}`,
                        meta: JSON.stringify({
                            task_id: ref_id,
                            title: byIdTitle.get(ref_id) || null,
                            deadline: deadlineYmd,
                            todo: byIdTodo.get(ref_id) || null,
                            bucket: 'missed_deadline_h3',
                            is_overdue: true,
                        }),
                        created: nowUnix,
                        updated: nowUnix,
                    });
                }

                if (dryRun) {
                    return {
                        scanned: tasks.length,
                        inserted: 0,
                        skipped,
                        overdueMarked,
                        willInsert: rows.length,
                        sample: rows.slice(0, 5),
                        dryRun: true,
                    };
                }

                let inserted = 0;
                if (rows.length) {
                    const result = await PerformanceEventLog.bulkCreate(rows, {
                        ignoreDuplicates: true,
                    });
                    inserted = Array.isArray(result) ? result.length : 0;
                }

                return {
                    inserted,
                    scanned: tasks.length,
                    skipped,
                    overdueMarked,
                };
            },
            { ttlSec: 60 },
        );

        if (res?.locked) {
            return new Response(
                JSON.stringify({
                    ok: false,
                    rule: 'missed-deadline-h3',
                    date: eventDate,
                    targetDeadline,
                    busy: true,
                }),
                { status: 423 },
            );
        }

        return Response.json({
            ok: true,
            rule: 'missed-deadline-h3',
            date: eventDate,
            targetDeadline,
            ...res,
            ms: Date.now() - t0,
        });
    } catch (err) {
        console.error('[cron][missed-deadline-h3] error:', err);
        return new Response(
            JSON.stringify({ ok: false, error: String(err?.message || err) }),
            { status: 500 },
        );
    }
}
