export const dynamic = "force-dynamic";
export const revalidate = 0;

import { NextResponse } from "next/server";
import db from "@/database/models";
import { withActive } from "@/utils/session";

const { MasterAnnualAssesmentPeriod } = db;

const isTrue = (v) => v === "true" || v === true || v === 1 || v === "1";

function forbid() {
  return NextResponse.json({ error: "Forbidden" }, { status: 403 });
}

export const GET = withActive(async function GET_HANDLER(req, ctx, currentUser) {
  try {
    // ✅ HRD or Superadmin only
    const isHrd = isTrue(currentUser?.is_hrd);
    const isSuperadmin = isTrue(currentUser?.is_superadmin);
    if (!isHrd && !isSuperadmin) return forbid();

    const { searchParams } = new URL(req.url);
    const yearParam = searchParams.get("year");
    const year = yearParam ? Number(yearParam) : null;

    // GET detail by year
    if (yearParam) {
      if (!Number.isFinite(year)) {
        return NextResponse.json({ error: "Invalid year" }, { status: 400 });
      }

      const row = await MasterAnnualAssesmentPeriod.findOne({
        where: { year },
        raw: true,
      });

      return NextResponse.json({ data: row || null }, { status: 200 });
    }

    // GET list
    const rows = await MasterAnnualAssesmentPeriod.findAll({
      order: [["year", "DESC"]],
      raw: true,
    });

    return NextResponse.json({ data: rows || [] }, { status: 200 });
  } catch (error) {
    console.error("GET /master/annual-assesment-period error:", error);
    return NextResponse.json({ error: "Internal error" }, { status: 500 });
  }
});

export const POST = withActive(async function POST_HANDLER(req, ctx, currentUser) {
  try {
    // ✅ HRD or Superadmin only
    const isHrd = isTrue(currentUser?.is_hrd);
    const isSuperadmin = isTrue(currentUser?.is_superadmin);
    if (!isHrd && !isSuperadmin) return forbid();

    const body = await req.json();

    // ✅ FE payload camelCase: year, openAt, closeAt, isActive (optional)
    const year = Number(body?.year);
    const openAt = Number(body?.openAt);
    const closeAt = Number(body?.closeAt);

    // optional: allow isActive from FE (1/0 or "true"/"false")
    const isActive =
      body?.isActive == null ? null : isTrue(body.isActive) ? 1 : 0;

    if (!Number.isFinite(year) || year < 2000 || year > 2100) {
      return NextResponse.json({ error: "Invalid year" }, { status: 400 });
    }
    if (!Number.isFinite(openAt) || !Number.isFinite(closeAt)) {
      return NextResponse.json(
        { error: "openAt and closeAt are required" },
        { status: 400 }
      );
    }
    if (closeAt < openAt) {
      return NextResponse.json(
        { error: "closeAt must be after openAt" },
        { status: 400 }
      );
    }

    const now = Math.floor(Date.now() / 1000);

    // upsert by unique year
    const existing = await MasterAnnualAssesmentPeriod.findOne({
      where: { year },
    });

    if (existing) {
      const updatePayload = {
        open_at: openAt,
        close_at: closeAt,
        updated: now,
        updated_by: currentUser.user_id,
      };
      if (isActive !== null) updatePayload.is_active = isActive;

      await existing.update(updatePayload);

      return NextResponse.json(
        {
          message: "Period updated.",
          data: existing.toJSON ? existing.toJSON() : existing,
        },
        { status: 200 }
      );
    }

    const createPayload = {
      year,
      open_at: openAt,
      close_at: closeAt,
      is_active: isActive !== null ? isActive : 1,
      created: now,
      created_by: currentUser.user_id,
      updated: now,
      updated_by: currentUser.user_id,
      deleted: null,
      deleted_by: null,
    };

    const created = await MasterAnnualAssesmentPeriod.create(createPayload);

    return NextResponse.json(
      { message: "Period created.", data: created },
      { status: 201 }
    );
  } catch (error) {
    console.error("POST /master/annual-assesment-period error:", error);

    // handle unique year collision gracefully
    if (
      String(error?.name || "").toLowerCase().includes("sequel") &&
      String(error?.message || "").toLowerCase().includes("uq_year")
    ) {
      return NextResponse.json(
        { error: "Year already exists." },
        { status: 409 }
      );
    }

    return NextResponse.json({ error: "Internal error" }, { status: 500 });
  }
});
