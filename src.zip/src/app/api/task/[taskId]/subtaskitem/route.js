export const dynamic = 'force-dynamic';
export const revalidate = 0;

import { NextResponse } from 'next/server';
import { User, Task, Project, Client, TaskAttachment, TaskTodo } from "@/database/models"; // Pastikan path sesuai dengan lokasi model
import { withAuth } from "@/utils/session";
import { getUnixTimestampUTC } from "@/utils/dateHelpers";


export async function GET(req, { params }) {
    try {
        const { taskId } = params;
        if (!taskId) {
            return NextResponse.json({ error: "Task not found" }, { status: 404 });
        }

        const detailTask = await Task.findOne({
            where: { task_id: taskId },
            include: [
                { model: User, as: 'creator' },
                {
                    model: Project, as: 'Project',
                    include: [
                        { model: Client, as: 'Client' },
                    ]
                },
            ]
        });

        if (!detailTask) {
            return NextResponse.json({ error: "Data Task not found" }, { status: 404 });
        }

        const [attachmentData] = await Promise.all([
            TaskAttachment.findAll({
                where: { task_id: detailTask.task_id }
            })
        ]);


        return NextResponse.json({ detailTask: detailTask, taskAttachment: attachmentData }, { status: 200 });
    } catch (error) {
        console.error("Error fetching Tasks:", error);
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}

export const POST = withAuth(async function POST_HANDLER(req, { params }, currentUser) {
    try {
        const { taskId } = params;
        const body = await req.json();
        const { ts_id, title } = body;
        const detail = await Task.findOne({ where: { task_id: taskId } });
        if (!detail) {
            return NextResponse.json({ error: "Task is Not Found." }, { status: 400 });
        }
        if (!title || title.trim() === '') {
            return NextResponse.json({ error: "Subtask item title cannot be empty." }, { status: 400 });
        }
        if (!ts_id) {
            return NextResponse.json({ error: "Parent subtask ID (ts_id) is required." }, { status: 400 });
        }

        const nowUnix = getUnixTimestampUTC();
        const newSubtaskItem = await Task.create({
            title: title.trim(),
            ts_id: ts_id,
            parent_id: detail.task_id,
            project_id: detail.project_id,
            pq_id: detail.pq_id,
            po_id: detail.po_id,
            description: null,
            priority: 'medium',
            todo: 'new',
            client_review: null,
            is_overdue: 'false',
            tags: null,
            is_revise: 'false',
            count_revision: 0,
            start_date: null,
            end_date: null,
            allotted_time: null,
            department: null,
            created_by: currentUser.user_id,
            created: nowUnix,
            updated_by: currentUser.user_id,
            updated: nowUnix,
            deleted_by: null,
            deleted: null,
        });

        const totalChild = await Task.count({ where: { parent_id: taskId } });
        const totalCompleted = await Task.count({ where: { parent_id: taskId, todo: "completed" } });
        await detail.update(
            {
                count_task_child_completed: totalCompleted,
                count_task_child: totalChild,
                progress: totalChild > 0 ? (totalCompleted / totalChild) * 100 : 0,
                updated: nowUnix,
                updated_by: currentUser?.user_id,
            });

        await TaskTodo.create(
            {
                task_id: taskId,
                todo: "new",
                created: nowUnix,
                created_by: currentUser?.user_id,
                updated: nowUnix,
                updated_by: currentUser?.user_id,
            },
        );

        return NextResponse.json({ message: "Subtask item added successfully!", taskSubtaskItem: newSubtaskItem.toJSON() }, { status: 201 });

    } catch (error) {
        console.error("Error adding subtask item:", error);
        return NextResponse.json({
            error: error.original?.sqlMessage || error.message || "An error occurred while adding the subtask item."
        }, { status: 500 });
    }
});

// Handler GET untuk mengambil daftar subtask item (jika dibutuhkan, bisa ditambahkan di sini)
// export const GET = async function GET_HANDLER(req, { params }) { /* ... */ };