export const dynamic = "force-dynamic";
export const revalidate = 0;

import { NextResponse } from "next/server";
import db from "@/database/models";
import { withActive } from "@/utils/session";

const { AnnualAssestment, User } = db;

function normalizeBool(v) {
  return v === true || v === "true" || v === 1 || v === "1";
}

function getRunningPeriod() {
  const year = new Date().getFullYear();
  return { periodFromYear: year - 1, periodToYear: year };
}

export const GET = withActive(async function GET_HANDLER(req, ctx, currentUser) {
  try {
    // ✅ HOD only
    if (!normalizeBool(currentUser?.is_hod)) {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    }

    const url = new URL(req.url);
    const yearParam = url.searchParams.get("year");
    const statusParam = url.searchParams.get("status"); // optional: draft|submitted_by_staff|reviewed_by_hod|finalized|all

    const { periodToYear } = getRunningPeriod();
    const year = yearParam ? Number(yearParam) : periodToYear;

    if (!year || Number.isNaN(year)) {
      return NextResponse.json({ error: "Invalid year" }, { status: 400 });
    }

    const where = {
      hod_id: currentUser.user_id,
      period_to_year: year,
    };

    if (statusParam && String(statusParam).toLowerCase() !== "all") {
      where.status = String(statusParam);
    }

    const rows = await AnnualAssestment.findAll({
      where,
      order: [
        ["status", "ASC"],
        ["updated", "DESC"],
        ["annual_assestment_id", "DESC"],
      ],
      include: [
        {
          model: User,
          as: "staff",
          attributes: ["user_id", "fullname", "name", "email", "department_id"],
          required: false,
        },
      ],
    });

    const data = rows.map((r) => ({
      annual_assestment_id: r.annual_assestment_id,
      staff_id: r.staff_id,
      hod_id: r.hod_id,
      period_from_year: r.period_from_year,
      period_to_year: r.period_to_year,
      status: r.status,
      staff_submitted_at: r.staff_submitted_at || r.submitted_at || null,
      updated: r.updated || null,
      staff: r.staff
        ? {
            user_id: r.staff.user_id,
            fullname: r.staff.fullname || r.staff.name || null,
            name: r.staff.name || null,
            email: r.staff.email || null,
            department_id: r.staff.department_id ?? null,
          }
        : null,
    }));

    return NextResponse.json({ data }, { status: 200 });
  } catch (error) {
    console.error("GET /annual-assestment/hod/list error:", error);
    return NextResponse.json(
      { error: error?.message || "Internal error" },
      { status: 500 }
    );
  }
});
