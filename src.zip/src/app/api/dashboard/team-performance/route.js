// src/app/api/dashboard/team-performance/route.js
export const dynamic = "force-dynamic";
export const revalidate = 0;

import { NextResponse } from "next/server";
import { withActive } from "@/utils/session";
import db from "@/database/models";

const { User, Timesheet, TaskAssignment, TaskTodo } = db;

// helper kecil (tetap dipertahankan)
const sum = (arr) => arr.reduce((a, b) => a + (Number(b) || 0), 0);
const toHM = (minutes) => {
  const m = Math.max(0, Number(minutes) || 0);
  const h = Math.floor(m / 60);
  const mm = m % 60;
  return { h, m: mm, label: `${h}h ${mm}m` };
};

function isTruthy(v) {
  return v === true || v === "true" || v === 1 || v === "1";
}

function isHodUser(u) {
  return (
    isTruthy(u?.is_hod) ||
    String(u?.user_role || "").toLowerCase() === "hod"
  );
}

export const GET = withActive(async function GET_HANDLER(req, { params }, currentUser) {
  try {
    const url = new URL(req.url);
    const staffIdParam = url.searchParams.get("staffId");

    const isSuperadmin = isTruthy(currentUser?.is_superadmin);

    let deptId = currentUser?.department_id ?? null;
    let hodUserIdToExclude = null;

    // ✅ Superadmin boleh override staffId (untuk melihat team bawahannya HOD terpilih)
    if (isSuperadmin && staffIdParam) {
      const parsed = parseInt(staffIdParam, 10);
      if (!Number.isNaN(parsed) && parsed > 0) {
        const picked = await User.findOne({
          where: { user_id: parsed },
          attributes: ["user_id", "department_id", "is_hod", "user_role"],
        });

        if (!picked) {
          return NextResponse.json({ department_id: null, team: [] }, { status: 200 });
        }

        deptId = picked.department_id ?? null;

        // kalau staff yg dipilih bukan HOD → tidak punya team
        if (!isHodUser(picked) || !deptId) {
          return NextResponse.json({ department_id: deptId, team: [] }, { status: 200 });
        }

        // exclude HOD yang dipilih biar yang tampil beneran bawahan
        hodUserIdToExclude = picked.user_id;
      }
    } else {
      // mode normal: kalau yang login HOD, exclude dirinya
      if (isHodUser(currentUser)) {
        hodUserIdToExclude = currentUser?.user_id ?? null;
      }
    }

    if (!deptId) {
      return NextResponse.json({ department_id: null, team: [] }, { status: 200 });
    }

    // 1) Ambil semua anggota satu department (logic asli tetap)
    let members = await User.findAll({
      where: { department_id: deptId },
      attributes: [
        "user_id",
        "fullname",
        "email",
        "user_role",
        "profile_pic",
        "department_id",
      ],
      order: [["fullname", "ASC"]],
    });

    // ✅ kalau konteksnya HOD → tampilkan bawahan (exclude HOD)
    if (hodUserIdToExclude) {
      members = members.filter((m) => Number(m?.user_id) !== Number(hodUserIdToExclude));
    }

    // 2) Untuk tiap member: total timesheet + grouping task status (logic asli tetap)
    const team = await Promise.all(
      members.map(async (u) => {
        // Timesheet total (menit)
        const tsMinutes = await Timesheet.sum("duration_minutes", {
          where: { user_id: u.user_id },
        }).then((v) => Number(v) || 0);

        // Task yang di-assign ke user
        const assignments = await TaskAssignment.findAll({
          where: { user_id: u.user_id },
          attributes: ["task_id"],
          raw: true,
        });

        const taskIds = [...new Set(assignments.map((a) => a.task_id))];

        let in_progress = 0,
          done = 0,
          pending = 0;

        if (taskIds.length) {
          // Ambil current state di task_todo
          const todos = await TaskTodo.findAll({
            where: { task_id: taskIds },
            attributes: ["task_id", "todo"],
            raw: true,
          });

          for (const t of todos) {
            if (t.todo === "in_progress") in_progress += 1;
            else if (t.todo === "done" || t.todo === "completed") done += 1;
            else pending += 1; // new, need_review, revision → pending
          }
        }

        const total_tasks = in_progress + done + pending;

        return {
          user_id: u.user_id,
          name: `${u.fullname || ""}`.trim() || "—",
          title: u.user_role || "",
          profile_pic: u.profile_pic || null,
          timesheet_minutes: tsMinutes,
          timesheet_label: toHM(tsMinutes).label, // "32h 37m"
          tasks: { in_progress, done, pending, total: total_tasks },
        };
      })
    );

    return NextResponse.json({ department_id: deptId, team }, { status: 200 });
  } catch (error) {
    console.error("Team Performance API error:", error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
});
