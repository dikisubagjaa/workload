// src/app/api/dashboard/route.js
export const dynamic = "force-dynamic";
export const revalidate = 0;

import { NextResponse } from "next/server";
import db from "@/database/models";
import { Op } from "sequelize";
import dayjs from "dayjs";
import { withAuth } from "@/utils/session";
// import department from "@/database/models/department"; // (tidak dipakai)

const { Task, Project, TaskAssignment, ProjectType, Client, User } = db;

// Robust parser utk kolom project_type (bisa JSON, array, atau string CSV)
function parseProjectType(raw) {
  if (raw == null) return [];
  if (Array.isArray(raw)) return raw;
  if (typeof raw === "string" && raw.trim() !== "") {
    try {
      const parsed = JSON.parse(raw);
      return Array.isArray(parsed) ? parsed : [];
    } catch {
      // fallback: "9,10" → [9,10]
      return raw
        .split(",")
        .map((s) => parseInt(s.trim(), 10))
        .filter((n) => !Number.isNaN(n));
    }
  }
  // Bila Sequelize JSON sudah mem-parsing ke object non-array
  return [];
}

function isTruthy(v) {
  return v === true || v === "true" || v === 1 || v === "1";
}

export const GET = withAuth(async function GET_HANDLER(req, { params }, currentUser) {
  try {
    // ====== staffId override (SUPERADMIN only) ======
    const url = new URL(req.url);
    const staffIdParam = url.searchParams.get("staffId");

    const isSuperadmin = isTruthy(currentUser?.is_superadmin);

    let effectiveUserId = currentUser.user_id;
    let effectiveDepartmentId = currentUser.department_id;

    if (isSuperadmin && staffIdParam) {
      const parsed = parseInt(staffIdParam, 10);
      if (!Number.isNaN(parsed) && parsed > 0) {
        const targetUser = await User.findOne({
          where: { user_id: parsed },
          attributes: ["user_id", "department_id"],
        });

        if (!targetUser) {
          return NextResponse.json({ error: "Staff tidak ditemukan" }, { status: 404 });
        }

        effectiveUserId = targetUser.user_id;
        effectiveDepartmentId = targetUser.department_id;
      }
    }

    const nowStart = dayjs().startOf("day").unix();
    const todayEnd = dayjs().endOf("day").unix();
    const hPlus3 = dayjs().add(3, "day").endOf("day").unix();
    const hPlus7 = dayjs().add(7, "day").endOf("day").unix();

    const assignedInclude = [
      {
        model: TaskAssignment,
        as: "Assignments",
        where: { user_id: effectiveUserId },
        required: true,
      },
      { model: Project, as: "Project" },
    ];

    const dueToday = await Task.count({
      distinct: true,
      include: assignedInclude,
      where: { end_date: { [Op.gte]: nowStart, [Op.lte]: todayEnd } },
      subQuery: false,
    });

    const overdue = await Task.count({
      distinct: true,
      include: assignedInclude,
      where: { end_date: { [Op.lt]: nowStart } },
      subQuery: false,
    });

    const critical = await Task.count({
      distinct: true,
      include: assignedInclude,
      where: { end_date: { [Op.gte]: nowStart, [Op.lte]: hPlus3 } },
      subQuery: false,
    });

    const dueThisWeek = await Task.count({
      distinct: true,
      include: assignedInclude,
      where: { end_date: { [Op.gte]: nowStart, [Op.lte]: hPlus7 } },
      subQuery: false,
    });

    const totalTask = await Task.count({
      distinct: true,
      include: assignedInclude,
      subQuery: false,
    });

    const needReview = await Task.count({
      distinct: true,
      include: assignedInclude,
      where: { todo: "need_review" },
      subQuery: false,
    });

    const overview = [
      { title: "Due Today", value: dueToday, cardBorder: "!border-l-4 border-[#00939F]" },
      { title: "Overdue Task", value: overdue, cardBorder: "!border-l-4 border-[#EC221F]" },
      { title: "Critical Deadlines", value: critical, cardBorder: "!border-l-4 border-[#E8B931]" },
      { title: "Due This Week", value: dueThisWeek, cardBorder: "!border-l-4 border-[#00939F]" },
      { title: "New task assigned", value: 0, cardBorder: "!border-l-4 border-[#E8B931]" }, // sesuaikan kalau ada logika
      { title: "Need Review", value: needReview, cardBorder: "!border-l-4 border-[#00939F]" },
      { title: "Total Task", value: totalTask, cardBorder: "!border-l-4 border-[#00939F]" },
    ];

    // ===== Lists (3 blok penting) =====
    const task = await Task.findAll({
      where: {
        todo: { [Op.in]: ["new", "done", "in_progress", "revise_hod", "revise_account"] },
      },
      limit: 5,
      include: assignedInclude,
      order: [["end_date", "ASC"]],
      subQuery: false,
    });

    const taskHod = await Task.findAll({
      where: {
        todo: { [Op.in]: ["done", "need_review_hod", "revision"] },
      },
      include: [
        {
          model: User,
          as: "AssignedUser",
          required: true,
          where: {
            department_id: {
              [Op.ne]: null,
              [Op.eq]: effectiveDepartmentId,
            },
          },
        },
        { model: Project, as: "Project" },
      ],
      limit: 5,
      order: [["end_date", "ASC"]],
    });

    const taskDataReview = await Task.findAll({
      where: {
        todo: { [Op.in]: ["need_review_ae"] },
        created_by: effectiveUserId,
      },
      include: [{ model: Project, as: "Project" }],
      order: [["end_date", "ASC"]],
      limit: 5,
      subQuery: false,
    });

    const projects = await Project.findAll({
      where: { created_by: effectiveUserId, published: "published" },
    });

    // Kumpulkan semua pt_id & client_id untuk query massal (hemat query)
    const allPtIds = [...new Set(projects.flatMap((p) => parseProjectType(p.project_type)))];
    const allClientIds = [...new Set(projects.map((p) => p.client_id).filter(Boolean))];

    // Ambil kamus tipe dan client
    const [ptRows, clientRows] = await Promise.all([
      allPtIds.length
        ? ProjectType.findAll({
            where: { pt_id: allPtIds },
            attributes: ["pt_id", "title"],
          })
        : [],
      allClientIds.length
        ? Client.findAll({
            where: { client_id: allClientIds },
            attributes: ["client_id", "client_name"],
          })
        : [],
    ]);

    const ptMap = new Map(ptRows.map((r) => [Number(r.pt_id), r.title]));
    const clientMap = new Map(clientRows.map((c) => [Number(c.client_id), c.client_name]));

    // Normalisasi output → tambahkan 3 field yang dibutuhkan FE:
    // - projectType: array of string (nama tipe)
    // - brand: string (client_name)
    // - dueDate: string terformat (DD MMM YYYY)
    const project = projects.map((p) => {
      const ptIds = parseProjectType(p.project_type);
      const projectType = ptIds
        .map((id) => ptMap.get(Number(id)) ?? String(id)) // fallback ke id jika belum ada titlenya
        .filter(Boolean);

      const brand = clientMap.get(Number(p.client_id)) ?? null;
      const dueDate = p.due_date ? dayjs(p.due_date).format("DD MMM YYYY") : null;

      return {
        ...p.toJSON(),
        projectType,
        brand,
        dueDate,
      };
    });

    return NextResponse.json({ overview, task, taskHod, project, taskDataReview }, { status: 200 });
  } catch (error) {
    console.error("Error fetching Dashboard:", error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
});
