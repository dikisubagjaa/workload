import NextAuth from "next-auth";
import GoogleProvider from "next-auth/providers/google";
import CredentialsProvider from "next-auth/providers/credentials";
import { findOrCreateUser } from "@/database/services/authService";
import { Menu, User, Role } from "@/database/models";

function parseAccessList(src) {
  let arr = [];
  if (Array.isArray(src)) arr = src;
  else if (typeof src === "string") {
    const s = src.trim();
    if (!s || s.toLowerCase() === "null" || s.toLowerCase() === "undefined") arr = [];
    else if ((s.startsWith("[") && s.endsWith("]")) || (s.startsWith("{") && s.endsWith("}"))) {
      try { const p = JSON.parse(s); arr = Array.isArray(p) ? p : []; } catch { arr = s.split(","); }
    } else arr = s.split(",");
  }
  arr = arr.map(v => (typeof v === "string" ? v.trim() : v)).filter(Boolean);

  const idSet = new Set(
    arr
      .map(v => (typeof v === "string" && /^[0-9]+$/.test(v) ? Number(v) : v))
      .filter(v => typeof v === "number")
  );
  const pathSet = new Set(
    arr
      .map(v => (typeof v === "number" ? "" : String(v)))
      .map(s => s.trim().toLowerCase())
      .filter(s => !!s && !/^[0-9]+$/.test(s))
  );
  return { idSet, pathSet };
}

function isAllowed(row, idSet, pathSet) {
  const byId = idSet.has(row.menu_id);
  const byPath = row.path && pathSet.has(String(row.path).toLowerCase());
  return byId || byPath;
}

/**
 * buildMenuTree(menuRows, allowedFn)
 * - Bangun tree dari semua rows "page".
 * - Node dianggap "allowed" jika lulus allowedFn.
 * - Saat pruning: node muncul bila dirinya allowed ATAU punya child allowed.
 * - Parent otomatis ikut agar hierarki utuh.
 */
function buildMenuTree(menuRows, allowedFn = () => true) {
  const nodesById = new Map();

  // 1) Normalisasi node
  for (const row of menuRows) {
    nodesById.set(row.menu_id, {
      id: row.menu_id,
      parentId: row.parent_id ?? null,
      order: row.ordered ?? 0,
      key: row.path || String(row.menu_id),
      path: row.path || null,
      label: row.title || "",
      icon: row.icon || null,
      isShow: row.is_show,
      allowed: !!allowedFn(row),
      children: [],
    });
  }

  // 2) Link parent-child
  const roots = [];
  for (const node of nodesById.values()) {
    if (node.parentId && nodesById.has(node.parentId)) {
      nodesById.get(node.parentId).children.push(node);
    } else {
      roots.push(node);
    }
  }

  // 3) Sort
  const sortByOrder = (a, b) => (a.order || 0) - (b.order || 0);
  function sortTree(n, depth = 0) {
    if (depth > 50) return; // guard loop sederhana
    n.children.sort(sortByOrder);
    n.children.forEach(c => sortTree(c, depth + 1));
  }
  roots.sort(sortByOrder);
  roots.forEach(n => sortTree(n));

  // 4) Prune: tampilkan jika allowed atau punya anak allowed
  function prune(n) {
    const keptChildren = n.children.map(prune).filter(Boolean);
    const keepThis = n.allowed || keptChildren.length > 0;
    if (!keepThis) return null;
    const out = {
      key: n.key,
      path: n.path,
      label: n.label,
      icon: n.icon,
      isShow: n.isShow,
    };
    if (keptChildren.length) out.children = keptChildren;
    return out;
  }

  return roots.map(prune).filter(Boolean);
}

export const authOptions = {
  trustHost: true,
  debug: process.env.AUTH_GOOGLE_DEBUG,
  secret: process.env.NEXTAUTH_SECRET,
  session: { strategy: "jwt" },
  providers: [
    GoogleProvider({
      clientId: process.env.AUTH_GOOGLE_ID,
      clientSecret: process.env.AUTH_GOOGLE_SECRET,
      authorization: {
        params: {
          prompt: "select_account",
          hd: process.env.AUTH_GOOGLE_DOMAIN || "vp-digital.com",
        },
      },
    }),
    CredentialsProvider({
      name: "Credentials",
      credentials: {
        username: { label: "Username", type: "text" },
        password: { label: "Password", type: "password" },
      },
      async authorize(credentials) {
        const { username, password } = credentials ?? {};

        if (!username || !password) return null;

        // SESUAIKAN dengan struktur tabel user kamu
        // Di sini diasumsikan ada kolom: username, password_hash, dll.
        const user = await User.findOne({
          where: { email: username },
          raw: true,
        });

        if (!user) return null;

        // Bandingkan password
        const bcrypt = (await import("bcryptjs")).default;
        const ok = await bcrypt.compare(password, user.password);
        if (!ok) return null;

        return {
          user_id: user.user_id,
          uuid: user.uuid,
          fullname: user.fullname,
          email: user.email,
          user_role: user.user_role,
          profile_pic: user.profile_pic,
          department_id: user.department_id,
          is_hod: user.is_hod,
          is_ae: user.is_ae,
          is_superadmin: user.is_superadmin,
          is_operational_director: user.is_operational_director,
          status: user.status,
          attendance_type: user.attendance_type,
          menu_access: user.menu_access,
        };
      },
    })
  ],
  cookies: {
    state: {
      name: "__Secure-next-auth.state",
      options: {
        httpOnly: true,
        sameSite: "lax",
        secure: true,
        path: "/",
      },
    },
  },

  callbacks: {
    // 1) signIn: pastikan user ada (create jika belum)
    async signIn({ user, account, profile }) {
      if (account?.provider === "google" && profile?.email) {
      
        const dbUser = await findOrCreateUser(user);
        return !!dbUser;
      }

      if (account?.provider === "credentials" && user?.email) {
        // authorize() sudah cek ke DB, jadi di sini cukup true
        return true;
      }
      return false;
    },

    // 2) jwt: rehydrate + role fallback (user.menu_access → role.menu_access)
    async jwt({ token, user, account, profile, trigger }) {
      const isGoogle = account?.provider === "google" && profile?.email;
      const isCredentials = account?.provider === "credentials" && user;
      const firstGoogleLogin = account?.provider === "google" && profile?.email;
      const tokenIncomplete = !token?.user_id || !token?.email || !token?.fullname;
      const forced = trigger === "update";

      if (!firstGoogleLogin && !tokenIncomplete && !forced) {
        return token;
      }

      let dbUser = null;
      if (isGoogle) {
        // Login via Google → tetap pakai findOrCreateUser
        dbUser = await findOrCreateUser(profile);
      } else if (isCredentials) {
        // Login via credentials → pakai user hasil authorize()
        dbUser = user;
      } else if (token?.email) {
        // Refresh / update → ambil ulang dari DB
        dbUser = await User.findOne({
          where: { email: token.email },
          raw: true,
        });
      }

      // ---- Ambil user
      if (!dbUser) return token;

      // ---- Isi token basic
      token.user_id = dbUser.user_id;
      token.uuid = dbUser.uuid || null;
      token.fullname = dbUser.fullname;
      token.email = dbUser.email;
      token.user_role = dbUser.user_role || null;
      token.profile_pic = dbUser.profile_pic || null;
      token.department_id = dbUser.department_id || null;
      token.is_hod = dbUser.is_hod ?? "false";
      token.is_hrd = dbUser.is_hrd ?? "false";
      token.is_ae = dbUser.is_ae ?? "false";
      token.is_superadmin = dbUser.is_superadmin ?? "false";
      token.is_operational_director = dbUser.is_operational_director ?? "false";
      token.status = dbUser.status ?? null;
      token.attendance_type = dbUser.attendance_type ?? null;

      return token;
    },

   async session({ session, token }) {
      // Basic user info dari token (kecil saja)
      session.user = {
        uuid: token.uuid || null,
        user_id: token.user_id,
        email: token.email,
        fullname: token.fullname,
        user_role: token.user_role,
        profile_pic: token.profile_pic,
        department_id: token.department_id,
        is_hod: token.is_hod,
        is_hrd: token.is_hrd,
        is_superadmin: token.is_superadmin,
        is_ae: token.is_ae,
        status: token.status,
        attendance_type: token.attendance_type,
        menu: { pages: [], dashboardKeys: [], buttons: [] }, // default kosong
      };

      try {
        if (!token?.email) {
          return session;
        }

        // Ambil menu_access & role user dari DB
        const dbUser = await User.findOne({
          where: { email: token.email },
          attributes: ["menu_access", "user_role","user_id"],
          raw: true,
        });

        if (!dbUser) {
          return session;
        }

        // ---- Siapkan whitelist: user.menu_access → (fallback) role.menu_access
        let { idSet, pathSet } = parseAccessList(dbUser.menu_access);
        if (idSet.size === 0 && pathSet.size === 0 && dbUser.user_role) {
          const roleRow = await Role.findOne({
            where: { slug: dbUser.user_role },
            attributes: ["menu_access"],
            raw: true,
          });
          const parsed = parseAccessList(roleRow?.menu_access);
          idSet = parsed.idSet;
          pathSet = parsed.pathSet;

           //update user
          if(roleRow?.menu_access){
            await User.update(
              { menu_access: roleRow?.menu_access },
              {
                where: {
                  user_id: dbUser.user_id,
                },
              }
            );
          }
        }

        const allowedFn = (row) => isAllowed(row, idSet, pathSet);

        // ---- SINGLE QUERY: semua menu aktif
        const allMenuRows = await Menu.findAll({
          where: { is_active: "true" },
          attributes: [
            "menu_id",
            "title",
            "path",
            "icon",
            "ordered",
            "is_show",
            "type",
            "parent_id",
          ],
          order: [["ordered", "ASC"]],
          raw: true,
        });

        // ---- Split 3 kategori
        const pageRows = allMenuRows.filter((r) => r.type === "page");
        const dashboardRows = allMenuRows.filter(
          (r) => r.type === "dashboard"
        );
        const buttonRows = allMenuRows.filter((r) => r.type === "button");

        // Pages (tree) dengan whitelist; parent otomatis ikut
        const pages = buildMenuTree(pageRows, allowedFn);

        // Dashboard: filter whitelist juga
        const dashboardKeys = dashboardRows
          .filter(allowedFn)
          .sort((a, b) => (a.ordered || 0) - (b.ordered || 0))
          .map((r) => r.path || String(r.menu_id));

        // Buttons: filter whitelist juga
        const buttons = buttonRows
          .filter(allowedFn)
          .sort((a, b) => (a.ordered || 0) - (b.ordered || 0))
          .map((r) => ({
            key: r.path || String(r.menu_id),
            path: r.path || null,
            label: r.title || "",
            icon: r.icon || null,
            isShow: r.is_show,
          }));

        session.user.menu = { pages, dashboardKeys, buttons };
      } catch (err) {
        console.error("Error building menu in session callback:", err);
      }

      return session;
    },
  },

  pages: { signIn: "/", signOut: "/" },
};

const handler = NextAuth(authOptions);
export { handler as GET, handler as POST };
