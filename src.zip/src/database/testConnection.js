const sequelize = require('./config/database');

async function testDatabaseConnection() {
    try {
        await sequelize.authenticate();
        console.log('✅ Koneksi ke database berhasil!');
    } catch (error) {
        console.error('❌ Gagal konek ke database:', error);
    }
}

testDatabaseConnection();
