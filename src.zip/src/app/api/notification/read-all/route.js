export const dynamic = 'force-dynamic';
export const revalidate = 0;

import { NextResponse } from 'next/server';
import db from '@/database/models';

export async function PATCH(req) {
  const url = new URL(req.url);
  const userId = Number(url.searchParams.get('userId') || 1);
  const now = Math.floor(Date.now() / 1000);

  const { Notification } = db;
  const [aff] = await Notification.update(
    { is_read: 'true', updated: now },
    { where: { user_id: userId, is_read: 'false' } }
  );

  return NextResponse.json({ ok: true, updated: aff || 0 });
}
