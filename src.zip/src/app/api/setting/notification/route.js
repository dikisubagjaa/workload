export const dynamic = 'force-dynamic';
export const revalidate = 0;

import { NextResponse } from 'next/server';
import db from '@/database/models';

// Daftar type sesuai form Settings kamu
const TYPES = [
  'taskAssignment',
  'taskOverdue',
  'lateToWork',
  'approval',
  'reschedule',
  'reimbursement',
  'reminderToFollowUp',
  'clientHaveOverdueInvoice',
  'collection',
  'overbudget',
  'overtimeLimit',
  'newInvoice',
  'Sales',
  'TaskCompletion',
  'memberOverdue',
  'revenue',
];

// Helper konversi nama key
const keyOf = (type) => `notification_${type}_in_app`;

// Interpret 'description' -> boolean
function parseDescToBool(v) {
  const s = String(v ?? 'true').trim().toLowerCase();
  return !(s === 'false' || s === '0');
}

// bool -> 'true'/'false'
function boolToDesc(b) {
  return b ? 'true' : 'false';
}

export async function GET() {
  try {
    const { Setting } = db;
    const keys = TYPES.map(keyOf);

    const rows = await Setting.findAll({ where: { var_name: keys } });

    // default semua ON (true)
    const items = Object.fromEntries(TYPES.map((t) => [t, true]));

    for (const r of rows) {
      // var_name: notification_<Type>_in_app
      const t = r.var_name.replace(/^notification_/, '').replace(/_in_app$/, '');
      if (TYPES.includes(t)) {
        items[t] = parseDescToBool(r.description);
      }
    }

    return NextResponse.json(
      { ok: true, items },
      { headers: { 'Cache-Control': 'no-store' } },
    );
  } catch (err) {
    console.error('GET /setting/notification error:', err);
    return NextResponse.json({ ok: false, error: 'Internal error' }, { status: 500 });
  }
}

export async function PUT(req) {
  try {
    const body = await req.json();
    if (!body || typeof body !== 'object' || Array.isArray(body)) {
      return NextResponse.json({ ok: false, error: 'Bad request' }, { status: 400 });
    }

    const { Setting } = db;
    const now = Math.floor(Date.now() / 1000);
    const actor = 1; // TODO: ganti dari session user kalau sudah siap

    // Hanya proses keys yang dikenal di TYPES
    for (const t of TYPES) {
      if (!(t in body)) continue;

      const var_name = keyOf(t);
      const description = boolToDesc(!!body[t]);
      const title = `Notification ${t} (In-App)`;

      const [row, created] = await Setting.findOrCreate({
        where: { var_name },
        defaults: {
          title,
          var_name,
          description,
          created: now,
          created_by: actor,
          updated: now,
          updated_by: actor,
        },
      });

      if (!created) {
        // update existing
        row.description = description;
        row.updated = now;
        row.updated_by = actor;

        // jika title kosong/null, isi default (hindari unique clash jika sudah terpakai)
        if (!row.title) {
          try { row.title = title; } catch (_) { }
        }

        await row.save();
      }
    }

    return NextResponse.json({ ok: true });
  } catch (err) {
    console.error('PUT /setting/notification error:', err);
    return NextResponse.json({ ok: false, error: 'Internal error' }, { status: 500 });
  }
}
