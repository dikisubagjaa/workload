export const dynamic = "force-dynamic";
export const revalidate = 0;

import "server-only";
import { NextResponse } from "next/server";
import db from "@/database/models";

const { Task, User, Sequelize } = db;
const { Op } = Sequelize;

// hanya ambil yang belum di-delete
const activeDeletedClause = {
    [Op.or]: [{ deleted: null }, { deleted: 0 }, { deleted: "" }],
};

const toNumber = (val, fallback = 0) => {
    if (typeof val === "number") return val;
    const n = Number(val);
    return Number.isNaN(n) ? fallback : n;
};

export async function GET(req, { params }) {
    const projectIdRaw = params?.projectId;
    const projectId = Number(projectIdRaw);

    if (!projectId || !Number.isFinite(projectId) || projectId <= 0) {
        return NextResponse.json(
            { message: "projectId is required" },
            { status: 400 }
        );
    }

    try {
        const tasks = await Task.findAll({
            where: {
                project_id: projectId,
                ...activeDeletedClause,
                // hanya parent task (subtask item diambil via parent_id)
                [Op.or]: [{ parent_id: null }, { parent_id: 0 }, { parent_id: "" }],
            },
            include: [
                {
                    model: User,
                    as: "AssignedUser",
                    required: false,
                    attributes: ["user_id", "fullname", "profile_pic"],
                    through: { attributes: [] },
                },
            ],
            order: [["task_id", "ASC"]],
        });

        const normalized = tasks.map((task) => {
            const todo = String(task.todo || "").toLowerCase();

            // pakai kolom DB yang sudah kita rawat
            const totalChild = toNumber(task.count_task_child);
            const completedChild = toNumber(task.count_task_child_completed);

            let progress = 0;
            if (totalChild > 0) {
                const ratio = (completedChild / totalChild) * 100;
                progress = Math.max(0, Math.min(100, Math.round(ratio)));
            } else {
                // fallback ke kolom progress jika tidak ada child
                const p = toNumber(task.progress, 0);
                progress = Math.max(0, Math.min(100, Math.round(p)));
            }

            return {
                taskId: task.task_id,
                title: task.title,
                description: task.description,
                todo,
                priority: task.priority,
                endDate: task.end_date,      // unix time
                totalSubtask: totalChild,
                completedSubtask: completedChild,
                progress,
                members: (task.AssignedUser || []).map((u) => ({
                    user_id: u.user_id,
                    fullname: u.fullname,
                    profile_pic: u.profile_pic,
                })),
            };
        });

        // singular: `task` berisi array
        return NextResponse.json({ task: normalized }, { status: 200 });
    } catch (err) {
        console.error("[project task] error:", err);
        return NextResponse.json(
            { message: "Failed to fetch project task" },
            { status: 500 }
        );
    }
}
