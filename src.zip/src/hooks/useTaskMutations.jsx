// src/hooks/useTaskMutations.js
"use client"; // Pastikan ini ada di baris paling atas

import { useState, useCallback, useRef } from 'react';
import { message } from 'antd';
import axiosInstance from "@/utils/axios";
import { convertCamelToSnake } from "@/utils/stringHelpers";
import dayjs from 'dayjs';
import utc from 'dayjs/plugin/utc';
import timezone from 'dayjs/plugin/timezone';
import customParseFormat from 'dayjs/plugin/customParseFormat';
import relativeTime from 'dayjs/plugin/relativeTime'; // Diperlukan untuk fromNow() di frontend

dayjs.extend(utc);
dayjs.extend(timezone);
dayjs.extend(customParseFormat);
dayjs.extend(relativeTime); // Extend relativeTime


export const useTaskMutations = (taskId,
    setListTaskAttachment,
    setListSubTask, setListSubTaskItem, setTaskData, setActivityLog, fetchActivityLog, getDepartmentLabel = (id) => String(id)) => {
    const [loadingMutation, setLoadingMutation] = useState(false);
    const activeUploads = useRef(new Set()); // Untuk melacak upload yang sedang berjalan berdasarkan file.uid

    const handleError = useCallback((error, action) => {
        console.error(`Error ${action}:`, error.response || error.request || error.message);
        message.error(`${action} failed: ${error.response?.data?.error || error.message || 'Unknown error'}`);
    }, []);

    // ✅ Update judul Subtask
    const updateSubTask = useCallback(async (tsId, updates) => {
        setLoadingMutation(true);
        try {
            const body = { title: updates?.title };
            const response = await axiosInstance.put(`/task/${taskId}/subtask/${tsId}`, body);

            if (response.status === 200) {
                const updated = response.data?.subTask;
                if (setListSubTask && updated) {
                    setListSubTask(prev => prev.map(s => Number(s.ts_id) === Number(tsId) ? { ...s, ...updated } : s));
                }
                message.success("Subtask updated successfully!");
            } else {
                message.error("Failed to update subtask with status: " + response.status);
            }
        } catch (error) {
            handleError(error, "Update subtask");
        } finally {
            setLoadingMutation(false);
        }
    }, [taskId, handleError, setListSubTask]);

    // ✅ Delete Subtask
    const deleteSubTask = useCallback(async (tsId) => {
        setLoadingMutation(true);
        try {
            const response = await axiosInstance.delete(`/task/${taskId}/subtask/${tsId}`);
            if (response.status === 200) {
                if (setListSubTask) {
                    setListSubTask(prev => prev.filter(s => Number(s.ts_id) !== Number(tsId)));
                }
                if (setListSubTaskItem) {
                    setListSubTaskItem(prev => prev.filter(i => Number(i.ts_id) !== Number(tsId)));
                }
                message.success("Subtask deleted.");
            } else {
                message.error("Failed to delete subtask with status: " + response.status);
            }
        } catch (error) {
            handleError(error, "Delete subtask");
        } finally {
            setLoadingMutation(false);
        }
    }, [taskId, handleError, setListSubTask, setListSubTaskItem]);


    const saveTask = useCallback(async (values) => {
        setLoadingMutation(true);
        try {
            const payload = convertCamelToSnake(values);

            // Konversi start_date dan end_date ke Unix Timestamp (detik, UTC 0)
            if (payload.start_date) {
                const startDateDayjs = dayjs(payload.start_date);
                payload.start_date = startDateDayjs.isValid()
                    ? startDateDayjs.unix()
                    : null;
            } else {
                payload.start_date = null;
            }
            if (payload.end_date) {
                const endDateDayjs = dayjs(payload.end_date);
                payload.end_date = endDateDayjs.isValid()
                    ? endDateDayjs.unix()
                    : null;
            } else {
                payload.end_date = null;
            }

            // Tangani allotted_time (time string HH:mm:ss)
            let formattedAllottedTime = '00:00:00';
            if (payload.allotted_time) {
                const allottedTimeDayjs = dayjs(payload.allotted_time);
                if (allottedTimeDayjs.isValid()) {
                    formattedAllottedTime = allottedTimeDayjs.format('HH:mm:ss');
                } else {
                    console.warn("Invalid allotted_time detected during save, defaulting to '00:00:00'. Raw value:", payload.allotted_time);
                }
            } else {
                console.warn("allotted_time was falsy during save, defaulting to '00:00:00' due to being required.");
            }
            payload.allotted_time = formattedAllottedTime;

            const response = await axiosInstance.post(`/task`, payload);

            if (response.status === 200 || response.status === 201) {
                message.success("Task saved successfully!");
                return response.data;
            } else {
                message.error("Failed to save task with status: " + response.status);
            }
        } catch (error) {
            handleError(error, "Save task");
        } finally {
            setLoadingMutation(false);
        }
        return null;
    }, [handleError]);

    const updateTask = useCallback(async (type, value) => {
        setLoadingMutation(true);
        try {
            const body = { type: type, value: value };

            // Konversi start_date dan end_date ke Unix Timestamp (detik, UTC 0)
            if (type === "start_date" || type === "end_date") {
                if (value) {
                    const dateDayjs = dayjs(value);
                    body.value = dateDayjs.isValid() ? dateDayjs.unix() : null;
                } else {
                    body.value = null;
                }
            } else if (type === "allotted_time") {
                if (value) {
                    const timeDayjs = dayjs(value);
                    if (timeDayjs.isValid()) {
                        body.value = timeDayjs.format('HH:mm:ss');
                    } else {
                        body.value = '00:00:00';
                    }
                } else {
                    body.value = '00:00:00';
                }
            } else if (type === "department" && Array.isArray(value)) {
                body.value = value; // Mengirim hanya value dari objek {label, value}
            }

            let rollbackTask = null;
            if (type === "department" && Number.isInteger(Number(body.value))) {
                const depId = Number(body.value);

                setTaskData(prev => {
                    rollbackTask = prev; // simpan snapshot untuk rollback jika gagal
                    const current = Array.isArray(prev?.department) ? [...prev.department] : [];
                    const idx = current.findIndex(d => Number(d.department_id) === depId);

                    // Jika ADD, butuh label agar chip langsung tampil manis.
                    const next = idx >= 0
                        ? current.filter(d => Number(d.department_id) !== depId)
                        : [...current, {
                            department_id: depId,
                            title: getDepartmentLabel(depId)
                        }];

                    return { ...prev, department: next };
                });
            }
            const response = await axiosInstance.put(`/task/${taskId}`, body);

            if (response.status === 200 || response.status === 201) {
                message.success(`Task ${type.replace('_', ' ')} updated successfully!`);
                if (setTaskData) {
                    const serverTask = response.data?.task;
                    if (serverTask && setTaskData) {
                        setTaskData(serverTask);
                    }
                }
            } else {
                message.error(`Failed to update task ${type.replace('_', ' ')} with status: ` + response.status);
            }
        } catch (error) {
            handleError(error, `Update task ${type}`);
        } finally {
            setLoadingMutation(false);
        }
    }, [taskId, handleError, setTaskData, getDepartmentLabel]);

    const addSubTask = useCallback(async (title) => {
        setLoadingMutation(true);
        try {
            const body = { title };
            const response = await axiosInstance.post(`/task/${taskId}/subtask`, body);

            if (response.status === 200 || response.status === 201) {
                const newSubTask = response.data.subTask;
                setListSubTask(prev => [newSubTask, ...prev]);
                message.success("Subtask added successfully!");
            } else {
                message.error("Failed to add subtask with status: " + response.status);
            }
        } catch (error) {
            handleError(error, "Add subtask");
        } finally {
            setLoadingMutation(false);
        }
    }, [taskId, handleError, setListSubTask]);


    const addSubTaskItem = useCallback(async (tsId, title) => {
        setLoadingMutation(true);
        try {
            const body = { title, ts_id: tsId };
            const response = await axiosInstance.post(`/task/${taskId}/subtaskitem`, body);

            if (response.status === 200 || response.status === 201) {
                const newItem = response.data.taskSubtaskItem;
                setListSubTaskItem(prev => [newItem, ...prev]);
                message.success("Subtask item added successfully!");
            } else {
                message.error("Failed to add subtask item with status: " + response.status);
            }
        } catch (error) {
            handleError(error, "Add subtask item");
        } finally {
            setLoadingMutation(false);
        }
    }, [taskId, handleError, setListSubTaskItem]);

    const updateTaskSubtaskItem = useCallback(async (type, value, taskItemId) => {
        setLoadingMutation(true);
        try {
            const body = { type: type, value: value };
            if (type === "end_date" && value) {
                body.value = dayjs(value).format('YYYY-MM-DD HH:mm:ss');
            } else if (type === "assign_to" && Array.isArray(value)) {
                body.value = value;
            }

            const response = await axiosInstance.put(`/task/${taskId}/subtaskitem/${taskItemId}`, body);

            if (response.status === 200 || response.status === 201) {
                const updatedItem = response.data?.subTaskItem;
                setListSubTaskItem(prev =>
                    prev.map(item => item.task_id === updatedItem.task_id ? updatedItem : item)
                );
                message.success(`Subtask item ${type.replace('_', ' ')} updated successfully!`);
            } else {
                message.error(`Failed to update subtask item ${type.replace('_', ' ')} with status: ` + response.status);
            }
        } catch (error) {
            handleError(error, `Update subtask item ${type}`);
        } finally {
            setLoadingMutation(false);
        }
    }, [taskId, handleError, setListSubTaskItem]);

    // === FINAL: Upload attachment level Task ===
    const handleUploadTask = useCallback(async (fileData) => {
        const file = fileData.file;
        console.log(
            "handleUploadTask dipanggil. Status:", file.status,
            "Nama File:", file.name, "UID:", file.uid
        );

        if (file.status === "uploading" && file.originFileObj) {
            // cegah double-trigger untuk UID yang sama
            if (activeUploads.current.has(file.uid)) return;
            activeUploads.current.add(file.uid);

            const formData = new FormData();
            formData.append("file", file.originFileObj);

            try {
                message.loading(`Uploading ${file.name}...`, 0);

                const response = await axiosInstance.post(
                    `/task/${taskId}/upload-attachment`,
                    formData,
                    { headers: { "Content-Type": "multipart/form-data" } }
                );

                message.destroy();

                if (response.status === 200 || response.status === 201) {
                    const att = response.data?.taskAttachment;
                    if (att) {
                        setListTaskAttachment(prev => {
                            const arr = Array.isArray(prev) ? prev : [];
                            // dedup lewat id atau (real_filename + task_id)
                            const exists = arr.some(
                                a =>
                                    (a.attachment_id && att.attachment_id && a.attachment_id === att.attachment_id) ||
                                    (a.real_filename === att.real_filename && String(a.task_id) === String(att.task_id))
                            );
                            return exists ? arr : [...arr, att];
                        });
                        message.success(`${att.real_filename || "File"} uploaded successfully.`);
                    } else {
                        console.error("2xx tetapi payload tidak mengandung taskAttachment:", response.data);
                        message.error("Upload succeeded but response is incomplete.");
                    }
                } else {
                    console.error("Upload gagal:", response.status, response.data);
                    message.error(`File upload failed: Status ${response.status}`);
                }
            } catch (err) {
                message.destroy();
                handleError(err, "Upload file");
                throw err;
            } finally {
                activeUploads.current.delete(file.uid);
            }
        } else if (file.status === "done" && activeUploads.current.has(file.uid)) {
            activeUploads.current.delete(file.uid);
        }
    }, [taskId, handleError, setListTaskAttachment]);

    const deleteTaskAttachment = useCallback(async (taskId, attachmentId) => {
        setLoadingMutation(true);
        try {
            // Soft delete di server (ikuti pola route upload: /task/:taskId/attachment)
            const res = await axiosInstance.delete(`/task/${taskId}/upload-attachment/${attachmentId}`);

            if (res.status === 200 || res.status === 204) {
                // Sinkronkan state FE: keluarkan attachment yang dihapus
                if (setListTaskAttachment) {
                    setListTaskAttachment(prev => {
                        if (!Array.isArray(prev)) return prev;
                        const targetId = Number(attachmentId);
                        return prev.filter(att => Number(att.attachment_id ?? att.id ?? att.ta_id) !== targetId);
                    });
                }

                // (Opsional) refresh activity jika kamu log di backend
                if (fetchActivityLog) {
                    await fetchActivityLog();
                }

                message.success("Attachment deleted.");
            } else {
                message.error("Failed to delete attachment with status: " + res.status);
            }
        } catch (error) {
            handleError(error, "Delete attachment");
        } finally {
            setLoadingMutation(false);
        }
    }, [taskId, setListTaskAttachment, handleError, fetchActivityLog]);

    // ⬇️⬇️⬇️ Perubahan di sini: tambah parameter "mentionedAttachmentIds" & kirim ke payload
    const addComment = useCallback(
        async (
            commentContent,
            commentFor = null,
            mentionedUserIds = null,
            mentionedAttachmentIds = null,   // << baru
            filenameJson = null,
            type = 'comment'
        ) => {
            setLoadingMutation(true);
            try {
                const body = {
                    content: commentContent,
                    comment_for: commentFor,
                    mentioned_user_ids: mentionedUserIds,
                    filename: filenameJson,
                    type: type,
                };

                // hanya kirim kalau terisi; backend akan render mention file
                if (Array.isArray(mentionedAttachmentIds) && mentionedAttachmentIds.length > 0) {
                    body.mentioned_attachment_ids = mentionedAttachmentIds;
                } else if (
                    mentionedAttachmentIds !== null &&
                    mentionedAttachmentIds !== undefined
                ) {
                    // fallback: jika single value dikirim (number/string), bungkus jadi array
                    body.mentioned_attachment_ids = [mentionedAttachmentIds];
                }

                const response = await axiosInstance.post(`/task/${taskId}/comment`, body);

                if (response.status === 200 || response.status === 201) {
                    if (fetchActivityLog) {
                        await fetchActivityLog();
                    }
                    message.success("Comment added successfully!");
                } else {
                    message.error("Failed to add comment: " + response.status);
                }
            } catch (error) {
                handleError(error, "Add comment");
            } finally {
                setLoadingMutation(false);
            }
        },
        [taskId, handleError, fetchActivityLog]
    );

    const uploadSubtaskItemAttachment = useCallback(async (fileData, subtaskItemId, attachment_id) => {
        const file = fileData.file;

        if (file.status === "uploading" && file.originFileObj) {
            if (activeUploads.current.has(file.uid)) return;
            activeUploads.current.add(file.uid);

            const formData = new FormData();
            formData.append("file", file.originFileObj);
            // server kamu menerima 'attachment_id' untuk revision (biarkan kosong/null jika create baru)
            if (attachment_id != null) formData.append("attachment_id", attachment_id);

            try {
                message.loading(`Uploading ${file.name}...`, 0);

                const response = await axiosInstance.post(
                    `/task/${taskId}/subtaskitem/${subtaskItemId}/upload-attachment`,
                    formData,
                    { headers: { "Content-Type": "multipart/form-data" } }
                );

                message.destroy();

                if (response.status === 200 || response.status === 201) {
                    const updated = response.data?.taskSubtaskItem;
                    if (updated) {
                        setListSubTaskItem(prev =>
                            prev.map(item => item.task_id === updated.task_id ? updated : item)
                        );
                    }
                    const att = response.data?.taskAttachment;
                    message.success(`${(att && att.real_filename) || file.name} uploaded to subtask item.`);
                    if (fetchActivityLog) await fetchActivityLog();
                } else {
                    console.error("Upload gagal:", response.status, response.data);
                    message.error(`File upload failed: Status ${response.status}`);
                }
            } catch (err) {
                message.destroy();
                handleError(err, "Upload file to subtask item");
                throw err;
            } finally {
                activeUploads.current.delete(file.uid);
            }
        } else if (file.status === "done" && activeUploads.current.has(file.uid)) {
            activeUploads.current.delete(file.uid);
        }
    }, [taskId, handleError, setListSubTaskItem, fetchActivityLog]);

    const onPromoteStar = useCallback(async (subtaskItemId, attachmentId) => {
        setLoadingMutation(true);
        try {
            const body = { attachmentId };
            const response = await axiosInstance.post(`/task/${taskId}/subtaskitem/${subtaskItemId}/upload-attachment/${attachmentId}/star`, body);
            if (response.status === 200 || response.status === 201) {
                const updatedSubtaskItem = response.data?.taskSubtaskItem;
                if (setListSubTaskItem && updatedSubtaskItem) {
                    setListSubTaskItem(prev =>
                        prev.map(item => item.task_id === updatedSubtaskItem.task_id ? updatedSubtaskItem : item)
                    );
                }
                message.success("Promote Star added successfully!");
            } else {
                message.error("Failed to add Promote Star with status: " + response.status);
            }
        } catch (error) {
            handleError(error, "Promote Star");
        } finally {
            setLoadingMutation(false);
        }
    }, [taskId, handleError, setListSubTask]);

    return {
        loadingMutation,
        uploadSubtaskItemAttachment,
        saveTask,
        updateTask,
        addSubTask,
        addSubTaskItem,
        updateTaskSubtaskItem,
        handleUploadTask,
        deleteTaskAttachment,
        onPromoteStar,
        addComment,
        updateSubTask,
        deleteSubTask,
    };
};
