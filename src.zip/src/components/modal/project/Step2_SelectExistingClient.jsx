// /src/components/modal/project/Step2_SelectExistingClient.jsx
"use client"

import { useState } from 'react';
import { Button, Form, Select, message, Empty } from 'antd';
import axiosInstance from '@/utils/axios';

export default function Step2_SelectExistingClient({ form, onFinish, onCancel, loading }) {
    const [options, setOptions] = useState([]);
    const [fetching, setFetching] = useState(false);

    const handleFetchClients = async () => {
        if (options.length > 0 || fetching) return;
        setFetching(true);
        try {
            const response = await axiosInstance.get('/client');
            const clients = response.data.clients || [];
            const formattedOptions = clients.map(c => ({ 
                label: c.client_name, 
                value: c.client_id 
            }));
            setOptions(formattedOptions);
        } catch (error) {
            message.error("Failed to load client list.");
        } finally {
            setFetching(false);
        }
    };

    const handleNextClick = async () => {
        try {
            // Validasi field yang ada di langkah ini secara manual
            const values = await form.validateFields(['existingClientId']);
            // Jika valid, panggil fungsi onFinish untuk lanjut
            onFinish(values);
        } catch (errorInfo) {
            // Jika validasi gagal, tidak melakukan apa-apa
            console.log('Validation Failed:', errorInfo);
        }
    };

    // Tag <Form> yang sebelumnya membungkus return ini sudah dihapus
    return (
        <div>
            <Form.Item
                name="existingClientId"
                label="Choose Existing Client"
                rules={[{ required: true, message: 'Please select a client!' }]}
            >
                <Select
                    showSearch
                    size='large'
                    placeholder="Search and select a client"
                    options={options}
                    loading={fetching}
                    onFocus={handleFetchClients}
                    notFoundContent={fetching ? null : <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} description="No clients found" />}
                    filterOption={(input, option) =>
                        (option?.label ?? '').toLowerCase().includes(input.toLowerCase())
                    }
                />
            </Form.Item>
            <Form.Item className='mt-10 mb-0'>
                <div className="flex justify-end gap-3">
                    <Button size='large' onClick={onCancel}>
                        Back
                    </Button>
                    <Button 
                        size='large' 
                        type="primary"
                        className="btn-blue px-5" 
                        loading={loading} 
                        onClick={handleNextClick} // Menggunakan onClick, bukan htmlType="submit"
                    >
                        Next
                    </Button>
                </div>
            </Form.Item>
        </div>
    );
}