export const dynamic = 'force-dynamic';
export const revalidate = 0;

import { NextResponse } from 'next/server';
import db from "@/database/models";
import dayjs from 'dayjs';
import timezone from 'dayjs/plugin/timezone';
import { withAuth } from "@/utils/session";

const { Attendance } = db;

// Atur zona waktu agar tanggalnya akurat
dayjs.extend(timezone);
dayjs.tz.setDefault(process.env.NEXT_PUBLIC_APP_TIMEZONE || "Asia/Jakarta");

export const GET = withAuth(async function GET_HANDLER(req, context, currentUser) {
    try {
        const userId = currentUser.user_id;
        const todayDate = dayjs().format('YYYY-MM-DD');

        // Cari entri absensi untuk pengguna dan tanggal hari ini
        const todaysAttendance = await Attendance.findOne({
            where: {
                user_id: userId,
                date: todayDate,
            }
        });

        // Jika ada entri dan clock_in tidak kosong, berarti sudah absen
        if (todaysAttendance && todaysAttendance.clock_in) {
            return NextResponse.json({
                isClockedIn: true,
                attendanceData: todaysAttendance.toJSON()
            });
        }

        // Jika tidak, berarti belum absen
        return NextResponse.json({
            isClockedIn: false,
            attendanceData: null
        });

    } catch (error) {
        console.error("Error checking attendance status:", error);
        return NextResponse.json({ error: "Failed to check attendance status." }, { status: 500 });
    }
});