export const dynamic = 'force-dynamic';
export const revalidate = 0;

import { NextResponse } from 'next/server';
import { Pitching, Client, PitchingType, Brand } from "@/database/models"; // Pastikan path sesuai dengan lokasi model
import { getCurrentTimestamp } from "@/utils/dateHelpers";
import fs from "fs/promises";
import path from "path";
import dayjs from 'dayjs';

// Ambil data profil berdasarkan PitchingId
export async function GET(req, { params }) {
    const { uuid } = params;

    const pitchingData = await Pitching.findOne({ where: { uuid: uuid } });

    if (!pitchingData) {
        return NextResponse.json({ error: "Pitching tidak ditemukan" }, { status: 404 });
    }

    return NextResponse.json({ Pitching: pitchingData });
}

// Update data profil berdasarkan PitchingId
export async function PUT(req, { params }) {
    try {
        const { uuid } = params;
        const body = await req.json();

        const pitchingData = await Pitching.findOne({ where: { uuid: uuid } });
        if (!pitchingData) {
            return NextResponse.json({ error: "Pitching tidak ditemukan" }, { status: 404 });
        }
        let clientData;
        if (body?.exist_client) {
            clientData = await Client.findOne({ where: { uuid: body?.exist_client } });
            if (!clientData) {
                return NextResponse.json({ error: "Client tidak ditemukan" }, { status: 404 });
            }
            await Pitching.update({
                client_id: clientData?.client_id,
                updated: dayjs().format('YYYY-MM-DD HH:mm:ss'),
                updated_by: 1,
            }, {
                where: { Pitching_id: pitchingData?.Pitching_id } // Tambahkan kondisi di sini
            });
        } else {
            const formatPhoneNumber = (phone) => phone.replace(/^0/, '');
            const picPhone = `${body?.pic_phone_code}${formatPhoneNumber(body?.pic_phone_number)}`;
            const financePhone = `${body?.finance_phone_code}${formatPhoneNumber(body?.finance_phone_number)}`;

            clientData = await Client.create({
                type: body?.type,
                client_name: body?.client_name,
                brand: body?.brand,
                address: body?.address,
                division: body?.division,
                pic_name: body?.pic_name,
                pic_phone: picPhone,
                pic_email: body?.pic_email,
                finance_name: body?.finance_name,
                finance_phone: financePhone,
                finance_email: body?.finance_email,
                created: dayjs().format('YYYY-MM-DD HH:mm:ss'),
                created_by: 1,
                updated: dayjs().format('YYYY-MM-DD HH:mm:ss'),
                updated_by: 1,
            }, { returning: true } // Ini akan mengembalikan data yang baru dibuat
            )
        }

        if (body?.type_submit == "publish") {
            await Pitching.update({
                Pitching_name: body?.Pitching_name,
                client_id: clientData?.client_id,
                due_date: body?.due_date,
                start_date: body?.start_date,
                Pitching_type: body?.Pitching_type,
                max_hours: body?.max_hours,
                maintenance: body?.maintenance,
                currency: body?.currency,
                currency_value: body?.currency_value,
                duration: body?.Pitching_duration,
                terms_of_payment: body?.terms_of_payment,
                json_data: { client: clientData },
                published: 'published',
                updated: dayjs().format('YYYY-MM-DD HH:mm:ss'),
                updated_by: 1,
            }, {
                where: { Pitching_id: pitchingData?.Pitching_id } // Tambahkan kondisi di sini
            });
        }

        return NextResponse.json({ message: `Pitching berhasil diperbarui`, Pitching: pitchingData, client: clientData });
    } catch (error) {
        console.error("Error updating Pitching:", error);
        return NextResponse.json({ error: "Gagal memperbarui data" }, { status: 500 });
    }
}


export async function DELETE(req, { params }) {
    try {
        const { uuid } = params;

        // Cek apakah Pitching dengan uuid tersebut ada
        const Pitching = await Pitching.findOne({ where: { uuid: uuid } });

        if (!Pitching) {
            return NextResponse.json({ error: "Pitching tidak ditemukan" }, { status: 404 });
        }

        // Soft delete: update kolom deleted & deleted_by
        await Pitching.update({
            deleted: getCurrentTimestamp(),
            deleted_by: Pitching.Pitchings_id // ID Pitching yang melakukan delete    
        });

    } catch (error) {
        return NextResponse.json({ error: "Gagal melakukan soft delete" }, { status: 500 });
    }
}



// **Handle Upload dengan Streaming (Busboy)**
export async function POST(req, { params }) {
    try {
        const { uuid } = params;

        // **Cek apakah Pitching ada**
        const Pitching = await Pitching.findOne({ where: { uuid } });
        if (!Pitching) {
            return NextResponse.json({ error: "Pitching tidak ditemukan" }, { status: 404 });
        }

        // **Pastikan Content-Type ada dan sesuai**
        const headers = Object.fromEntries(req.headers);
        if (!headers["content-type"]?.includes("multipart/form-data")) {
            return NextResponse.json({ error: "Missing Content-Type" }, { status: 400 });
        }

        // Ambil file dari form-data
        const formData = await req.formData();
        const file = formData.get("file");

        if (!file) {
            return NextResponse.json({ error: "File tidak ditemukan" }, { status: 400 });
        }

        // Path penyimpanan
        const uploadDir = path.join(process.cwd(), `storage/Pitching/${uuid}`);
        await fs.mkdir(uploadDir, { recursive: true });

        const filePath = path.join(uploadDir, file.name);
        const buffer = Buffer.from(await file.arrayBuffer());
        await fs.writeFile(filePath, buffer);

        // **Update URL foto profil di database**
        // const imageUrl = `${file.name}`;
        // await Pitching.update({ profile_pic: imageUrl });

        return NextResponse.json({ message: "Upload berhasil!", fileName: file.name });

    } catch (error) {
        console.error("Error upload:", error);
        return NextResponse.json({ error: "Terjadi kesalahan server" }, { status: 500 });
    }
}
