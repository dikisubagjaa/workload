// src/app/api/project/stats/route.js
export const dynamic = 'force-dynamic';
export const revalidate = 0;

import { NextResponse } from 'next/server';
import db from "@/database/models";
import { withAuth } from "@/utils/session";
import dayjs from 'dayjs';

const { Task, Project, User, Sequelize } = db;
const { Op } = Sequelize;

export const GET = withAuth(async function GET_HANDLER(req, context, currentUser) {
    try {
        const today = dayjs().format('YYYY-MM-DD');
        const nextWeek = dayjs().add(7, 'day').format('YYYY-MM-DD');
        const userId = currentUser.user_id;

        // === Statistik widget (pakai kolom yang sudah ada) ===
        const dueTodayCount = await Task.count({ where: { end_date: today } });

        const overdueCount = await Task.count({ where: { is_overdue: 'true', end_date: { [Op.lt]: today } } });

        const dueThisWeekCount = await Task.count({
            where: { end_date: { [Op.between]: [today, nextWeek] } }
        });

        const totalTaskCount = await Task.count();

        const criticalDeadlinesCount = await Task.count({
            where: { priority: 'high' }
        });

        const needsReviewCount = await Task.count({
            where: { client_review: 'review' }
        });

        const newTaskAssignedCount = await Task.count({
            include: [{
                model: User,
                as: 'AssignedUser', // alias sesuai di model task.js
                where: { user_id: userId }
            }]
        });

        // === chartData per project (pakai subquery dengan kolom existing) ===
        const projectChartData = await Project.findAll({
            attributes: [
                'project_id',
                'title',
                [
                    Sequelize.literal(`(
                    SELECT COUNT(*) FROM task AS t
                    WHERE t.project_id = Project.project_id
                    AND t.todo = 'completed'
                )`),
                    'completed_task_count'
                ],
                [
                    Sequelize.literal(`(
                    SELECT COUNT(*) FROM task AS t
                    WHERE t.project_id = Project.project_id
                    AND t.todo NOT IN ('completed')
                )`),
                    'remaining_task_count'
                ],
                [
                    Sequelize.literal(`(
                    SELECT COUNT(*) FROM task AS t
                    WHERE t.project_id = Project.project_id
                    AND t.is_overdue = 'true'
                )`),
                    'overdue_task_count'
                ],
            ],
            where: { published: 'published' },
            limit: 5
        });

        const stats = {
            dueToday: dueTodayCount,
            overdue: overdueCount,
            dueThisWeek: dueThisWeekCount,
            totalTask: totalTaskCount,
            criticalDeadlines: criticalDeadlinesCount,
            needsReview: needsReviewCount,
            newTaskAssigned: newTaskAssignedCount,
        };

        return NextResponse.json({ stats, chartData: projectChartData });
    } catch (error) {
        console.error("Error fetching dashboard stats:", error);
        return NextResponse.json(
            { error: "Failed to fetch dashboard stats." },
            { status: 500 }
        );
    }
});
