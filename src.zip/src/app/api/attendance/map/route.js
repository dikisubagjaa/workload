// src/app/api/attendance/map/route.js
export const dynamic = "force-dynamic";
export const revalidate = 0;

import { NextResponse } from "next/server";
import db from "@/database/models";
import dayjs from "dayjs";
import utc from "dayjs/plugin/utc";
import timezone from "dayjs/plugin/timezone";
import { withActive } from "@/utils/session";

dayjs.extend(utc);
dayjs.extend(timezone);
dayjs.tz.setDefault(process.env.NEXT_PUBLIC_APP_TIMEZONE || "Asia/Jakarta");

const { Attendance, User, Sequelize } = db;
const { Op } = Sequelize;

// Normalisasi tanggal: pakai query ?date=YYYY-MM-DD, kalau kosong → hari ini
function resolveDate(searchParams) {
  const raw = (searchParams.get("date") || "").trim();
  if (raw) {
    const d = dayjs(raw, "YYYY-MM-DD", true);
    if (d.isValid()) return d;
  }
  return dayjs(); // pakai default tz yang sudah diset
}

function formatTime(unixSeconds) {
  if (!unixSeconds && unixSeconds !== 0) return "";
  const n = Number(unixSeconds);
  if (Number.isNaN(n) || n <= 0) return "";
  return dayjs.unix(n).tz().format("HH:mm");
}

export const GET = withActive(
  async function GET_ATTENDANCE_MAP(req, _ctx, currentUser) {
    try {
      if (!currentUser) {
        return NextResponse.json(
          { error: "Unauthenticated" },
          { status: 401 }
        );
      }

      const { searchParams } = new URL(req.url);

      const d = resolveDate(searchParams);
      const date = d.format("YYYY-MM-DD");

      const statusFilter = (searchParams.get("status") || "")
        .trim()
        .toLowerCase();
      const q = (searchParams.get("q") || "").trim();

      // Hanya attendance yang punya koordinat
      const whereAttendance = {
        date,
        location_latitude: { [Op.ne]: null },
        location_longitude: { [Op.ne]: null },
      };

      if (statusFilter) {
        whereAttendance.status = statusFilter;
      }

      const whereUser = {};
      if (q) {
        const like = `%${q}%`;
        whereUser[Op.or] = [
          { fullname: { [Op.like]: like } },
          { email: { [Op.like]: like } },
          { phone: { [Op.like]: like } },
        ];
      }

      const rows = await Attendance.findAll({
        where: whereAttendance,
        include: [
          {
            model: User,
            as: "User",
            required: true,
            attributes: ["user_id", "fullname", "email", "job_position", "phone"],
            where: whereUser,
          },
        ],
        order: [[{ model: User, as: "User" }, "fullname", "ASC"]],
      });

      const data = rows.map((row) => {
        const r = row.toJSON ? row.toJSON() : row;
        const u = r.User || {};
        return {
          attendanceId: r.attendance_id,
          userId: r.user_id,
          fullname: u.fullname || "",
          email: u.email || "",
          jobPosition: u.job_position || "",
          phone: u.phone || "",
          date: r.date,
          status: r.status,
          latitude:
            r.location_latitude != null ? Number(r.location_latitude) : null,
          longitude:
            r.location_longitude != null ? Number(r.location_longitude) : null,
          clockIn: formatTime(r.clock_in),
          clockOut: formatTime(r.clock_out),
          minutesLate: r.minutes_late || 0,
        };
      });

      return NextResponse.json(
        {
          ok: true,
          date,
          count: data.length,
          data,
        },
        { status: 200 }
      );
    } catch (err) {
      console.error("GET /api/attendance/map error:", err);
      return NextResponse.json(
        { error: err?.message || "Failed to fetch map attendance" },
        { status: 500 }
      );
    }
  }
);
