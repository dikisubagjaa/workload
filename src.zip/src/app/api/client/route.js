export const dynamic = 'force-dynamic';
export const revalidate = 0;

import { NextResponse } from 'next/server';
import db from "@/database/models";
const { Client, Brand } = db;
import dayjs from 'dayjs';
import utc from 'dayjs/plugin/utc';
dayjs.extend(utc);

import { getUnixTimestampUTC } from "@/utils/dateHelpers";
import { withActive } from "@/utils/session";

export const GET = withActive(async function GET_HANDLER(req, context, currentUser) {
    try {
        const clients = await Client.findAll({
            where: { deleted: null },
            order: [['client_id', 'ASC']]
        });

        const formattedClients = clients.map(client => {
            const clientJson = client.toJSON();
            const rawBrands = Array.isArray(clientJson.brand) ? clientJson.brand : [];
            return {
                ...clientJson,
                brand: rawBrands,
                created: clientJson.created ? dayjs.unix(clientJson.created) : null,
                updated: clientJson.updated ? dayjs.unix(clientJson.updated) : null,
                deleted: clientJson.deleted ? dayjs.unix(clientJson.deleted) : null,
            };
        });
        return NextResponse.json({ clients: formattedClients }, { status: 200 });
    } catch (error) {
        console.error("Error fetching clients:", error);
        return NextResponse.json({ error: error.message || "Failed to fetch clients." }, { status: 500 });
    }
});

// --- Handler POST untuk Menambah Client Baru ---
export const POST = withActive(async function POST_HANDLER(req, context, currentUser) {
    try {
        const body = await req.json();
        const nowUnix = getUnixTimestampUTC();

        if (!body.client_name || !body.type || !body.pic_name || !body.pic_email || !body.pic_phone || !body.brand) {
            return NextResponse.json({ error: "Client Name, Type, PIC Name, Email, Brand and Phone are required." }, { status: 400 });
        }

        let finalBrandsForDb = [];
        if (Array.isArray(body.brand) && body.brand.length > 0) {
            const fetchedBrandsByIds = await Brand.findAll({
                where: { brand_id: body.brand },
                attributes: ['brand_id', 'title']
            });
            finalBrandsForDb = fetchedBrandsByIds.map(b => b.toJSON());
        }

        const newClient = await Client.create({
            type: body.type,
            client_name: body.client_name,
            brand: finalBrandsForDb,
            division: body.division || null,
            address: body.address || null,
            pic_name: body.pic_name,
            pic_email: body.pic_email,
            pic_phone: body.pic_phone,
            finance_name: body.finance_name || null,
            finance_phone: body.finance_phone || null,
            finance_email: body.finance_email || null,
            created: nowUnix,
            created_by: currentUser.user_id,
            updated: nowUnix,
            updated_by: currentUser.user_id,
        });

        return NextResponse.json({ message: "Client created successfully!", client: newClient.toJSON() }, { status: 201 });
    } catch (error) {
        console.error("Error creating client:", error);
        if (error.name === 'SequelizeUniqueConstraintError') {
            return NextResponse.json({ error: "Client with this name/UUID already exists." }, { status: 409 });
        }
        return NextResponse.json({ error: error.message || "Failed to create client." }, { status: 500 });
    }
});
