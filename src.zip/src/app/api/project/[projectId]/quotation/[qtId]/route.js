export const dynamic = "force-dynamic";
export const revalidate = 0;

import { NextResponse } from "next/server";
import db from "@/database/models";
import { withAuth } from "@/utils/session";
import dayjs from "dayjs";
import { writeFile } from "fs/promises";
import path from "path";
import fs from "fs";

const { ProjectQuotation, ProjectPurchaseOrder } = db;

/**
 * Helper function to save an uploaded file.
 * @param {File} file - The file to save.
 * @param {string} subfolder - The subfolder within 'public/uploads' to save the file.
 * @returns {Promise<string>} The relative path to the saved file.
 */
async function saveFile(file, subfolder) {
  const bytes = await file.arrayBuffer();
  const buffer = Buffer.from(bytes);

  const fileExtension = path.extname(file.name);
  const uniqueSuffix = Date.now() + "-" + Math.round(Math.random() * 1e9);
  const newFilename = `${uniqueSuffix}${fileExtension}`;

  const uploadDir = path.join(process.cwd(), "public", "uploads", subfolder);
  const filePath = path.join(uploadDir, newFilename);

  if (!fs.existsSync(uploadDir)) {
    fs.mkdirSync(uploadDir, { recursive: true });
  }

  await writeFile(filePath, buffer);
  return `/uploads/${subfolder}/${newFilename}`;
}

/**
 * DELETE handler untuk menghapus quotation (soft delete) + semua PO-nya (soft delete).
 * Route: /api/project/[projectId]/quotation/[qtId]
 */
export const DELETE = withAuth(async function DELETE_HANDLER(req, { params }, currentUser) {
  const { projectId, qtId } = params;

  try {
    if (!qtId || qtId === "undefined") {
      return NextResponse.json(
        { status: "error", message: "Quotation ID is required." },
        { status: 400 }
      );
    }

    const quotation = await ProjectQuotation.unscoped().findByPk(qtId);

    // 404 kalau tidak ada / sudah deleted
    if (!quotation || quotation.deleted) {
      return NextResponse.json(
        { status: "error", message: "Quotation not found." },
        { status: 404 }
      );
    }

    // pastiin quotation milik project yg dimaksud
    if (String(quotation.project_id) !== String(projectId)) {
      // 404 biar gak bocorin eksistensi data project lain
      return NextResponse.json(
        { status: "error", message: "Quotation not found." },
        { status: 404 }
      );
    }

    const nowUnix = dayjs().unix();

    // soft delete semua PO yang terkait quotation ini
    await ProjectPurchaseOrder.unscoped().update(
      {
        deleted: nowUnix,
        deleted_by: currentUser.user_id,
        updated: nowUnix,
        updated_by: currentUser.user_id,
      },
      {
        where: {
          pq_id: qtId,
          deleted: null,
        },
      }
    );

    // soft delete quotation
    await quotation.update({
      deleted: nowUnix,
      deleted_by: currentUser.user_id,
      updated: nowUnix,
      updated_by: currentUser.user_id,
    });

    return NextResponse.json(
      { status: "success", message: "Quotation deleted." },
      { status: 200 }
    );
  } catch (error) {
    console.error("DELETE Quotation error:", error);
    return NextResponse.json(
      { status: "error", message: "Failed to delete quotation." },
      { status: 500 }
    );
  }
});

/**
 * POST handler untuk mengunggah dokumen PO ke kutipan yang sudah ada.
 * (legacy - dibiarkan sesuai file aslinya)
 */
export const POST = withAuth(async function POST_HANDLER(req, { params }, currentUser) {
  const { qtId } = params;

  try {
    const formData = await req.formData();
    const poFile = formData.get("po_file");
    const poNumber = formData.get("po_number");

    if (!poFile || !poNumber) {
      return NextResponse.json(
        { status: "error", message: "PO file and PO number are required." },
        { status: 400 }
      );
    }

    const quotation = await ProjectQuotation.findOne({ where: { pq_id: qtId } });

    if (!quotation) {
      return NextResponse.json(
        { status: "error", message: "Quotation not found." },
        { status: 404 }
      );
    }

    const poPath = await saveFile(poFile, "po");

    const poData = {
      po_number: poNumber,
      po_doc: poPath,
      uploaded_at: dayjs().unix(),
      uploaded_by: currentUser.user_id,
    };

    await quotation.update({
      po: poData,
      updated: dayjs().unix(),
      updated_by: currentUser.user_id,
    });

    return NextResponse.json(
      {
        status: "success",
        message: "PO document uploaded and linked successfully!",
        data: quotation,
      },
      { status: 200 }
    );
  } catch (error) {
    console.error("Error uploading PO document:", error);
    return NextResponse.json(
      { status: "error", message: "Failed to upload PO document." },
      { status: 500 }
    );
  }
});
