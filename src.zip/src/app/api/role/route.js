// src/app/api/role/route.js
import 'server-only';
import { NextResponse } from 'next/server';
import db from '@/database/models';

const { Role, Sequelize } = db;
const { Op } = Sequelize;

const nowUnix = () => Math.floor(Date.now() / 1000);

// --- Helpers ---
function parseIntSafe(v, def) {
  const n = parseInt(String(v ?? '').trim(), 10);
  return Number.isFinite(n) && n >= 0 ? n : def;
}
function normSlug(s) {
  if (!s) return '';
  return String(s).trim().toLowerCase().replace(/[^a-z0-9_-]+/g, '-').replace(/^-+|-+$/g, '');
}
function sanitizeMenuAccess(val) {
  if (!val) return [];
  if (Array.isArray(val)) {
    return val
      .map((x) => (typeof x === 'string' ? x.trim() : ''))
      .filter(Boolean)
      .filter((v, i, a) => a.indexOf(v) === i);
  }
  // allow JSON string
  try {
    const arr = JSON.parse(val);
    if (Array.isArray(arr)) return sanitizeMenuAccess(arr);
  } catch { }
  return [];
}

// ==========================================================
// GET /api/role  → list roles (search & pagination)
//  - query:
//      q        : optional string (search title/slug/description)
//      limit    : default 20
//      offset   : default 0
//      orderBy  : 'created' | 'updated' | 'title' | 'slug' (default: 'created')
//      orderDir : 'ASC' | 'DESC' (default: 'DESC')
// ==========================================================
export async function GET(req) {
  try {
    const { searchParams } = new URL(req.url);
    const q = (searchParams.get('q') || '').trim();
    const limit = parseIntSafe(searchParams.get('limit'), 20);
    const offset = parseIntSafe(searchParams.get('offset'), 0);

    const allowedOrderBy = new Set(['created', 'updated', 'title', 'slug']);
    const orderBy = allowedOrderBy.has(searchParams.get('orderBy')) ? searchParams.get('orderBy') : 'created';
    const orderDir = String(searchParams.get('orderDir') || 'DESC').toUpperCase() === 'ASC' ? 'ASC' : 'DESC';

    const where = {};
    if (q) {
      where[Op.or] = [
        { title: { [Op.like]: `%${q}%` } },
        { slug: { [Op.like]: `%${q}%` } },
        { description: { [Op.like]: `%${q}%` } },
      ];
    }

    const { rows, count } = await Role.findAndCountAll({
      where,
      limit,
      offset,
      order: [[orderBy, orderDir]],
    });

    return NextResponse.json(
      { ok: true, data: { rows, count, limit, offset }, roles: rows, total: count },
      { status: 200 }
    );
  } catch (error) {
    console.error('GET /api/role error:', error);
    return NextResponse.json(
      { ok: false, error: error?.message || 'Failed to fetch roles' },
      { status: 500 }
    );
  }
}

// ==========================================================
// POST /api/role  → create role
//  - body (JSON, camelCase):
//      title        : string (required)
//      slug         : string (required, unique)
//      description  : string (optional)
//      menu_access  : string[] (optional)
// ==========================================================
export async function POST(req) {
  let t = null;
  try {
    const body = await req.json().catch(() => ({}));
    const title = String(body?.title ?? '').trim();
    const slugRaw = body?.slug ?? '';
    const slug = normSlug(slugRaw);
    const description = body?.description != null ? String(body.description) : null;
    const menu_access = sanitizeMenuAccess(body?.menu_access);

    if (!title) {
      return NextResponse.json({ ok: false, error: 'title is required' }, { status: 400 });
    }
    if (!slug) {
      return NextResponse.json({ ok: false, error: 'slug is required' }, { status: 400 });
    }

    // Uniqueness check (defaultScope already hides soft-deleted)
    const exists = await Role.findOne({ where: { slug } });
    if (exists) {
      return NextResponse.json({ ok: false, error: 'slug already exists' }, { status: 409 });
    }

    t = await db.sequelize.transaction();

    const now = nowUnix();

    // NOTE: created_by / updated_by → jika kamu punya session user, isi di sini
    // const currentUserId = ...;
    const payload = {
      title,
      slug,
      description,
      menu_access,     // array → model JSON
      created: now,
      updated: now,
      // created_by: currentUserId ?? null,
      // updated_by: currentUserId ?? null,
    };

    const role = await Role.create(payload, { transaction: t });

    await t.commit();
    return NextResponse.json({ ok: true, role }, { status: 201 });
  } catch (error) {
    if (t) {
      try { await t.rollback(); } catch { }
    }
    console.error('POST /api/role error:', error);
    return NextResponse.json(
      { ok: false, error: error?.message || 'Failed to create role' },
      { status: 500 }
    );
  }
}
