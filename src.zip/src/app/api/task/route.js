export const dynamic = 'force-dynamic';
export const revalidate = 0;

import { NextResponse } from "next/server";
import db from "@/database/models";
const { Task, Project, ProjectQuotation, Sequelize } = db;

import dayjs from 'dayjs';
import utc from 'dayjs/plugin/utc';
import customParseFormat from 'dayjs/plugin/customParseFormat';
import { getUnixTimestampUTC } from "@/utils/dateHelpers";
import { withActive } from "@/utils/session";
dayjs.extend(utc);
dayjs.extend(customParseFormat);

// Handler untuk mengambil semua task dari database (Method: GET)
export async function GET() {
    try {
        const tasks = await Task.findAll();
        return NextResponse.json({ Task: tasks }, { status: 200 });
    } catch (error) {
        console.error("Error fetching Tasks:", error);
        return NextResponse.json({ error: "Gagal mengambil data task" }, { status: 500 });
    }
}

// Handler untuk membuat task baru di database (Method: POST)
export const POST = withActive(async function POST_HANDLER(req, context, currentUser) {
    try {
        const currentUserId = currentUser.user_id;

        const body = await req.json();

        // Helpers untuk HH:mm
        const parseHHMM = (str) => {
            if (typeof str !== 'string') return null;
            const m = /^(\d{1,2}):(\d{2})$/.exec(str.trim());
            if (!m) return null;
            const h = Math.min(23, Math.max(0, parseInt(m[1], 10)));
            const min = Math.min(59, Math.max(0, parseInt(m[2], 10)));
            return h * 60 + min; // menit
        };
        const formatHHMM = (mins) => {
            const m = Math.max(0, Math.floor(mins));
            const hh = String(Math.floor(m / 60)).padStart(2, '0');
            const mm = String(m % 60).padStart(2, '0');
            return `${hh}:${mm}`;
        };

        // Validasi keberadaan Project
        const projectData = await Project.findOne({ where: { project_id: body.project_id } });
        if (!projectData) {
            return NextResponse.json({ error: "Project tidak ditemukan" }, { status: 404 });
        }

        const pqData = await ProjectQuotation.findOne({ where: { pq_id: body.pq_id } });
        if (!pqData) {
            return NextResponse.json({ error: "Quotation tidak ditemukan" }, { status: 404 });
        }
        const nowUnix = getUnixTimestampUTC(); // Using global helper

        const finalStartDate = typeof body.start_date === 'number' ? body.start_date : null;
        const finalEndDate = typeof body.end_date === 'number' ? body.end_date : null;

        let finalAllottedTime = null;
        const sm = parseHHMM(body.start_time);
        const em = parseHHMM(body.end_time);
        if (sm != null && em != null) {
            // beda menit; kalau end < start, anggap nyebrang hari berikutnya
            let diff = em - sm;
            if (diff < 0) diff += 24 * 60;
            finalAllottedTime = formatHHMM(diff);
        } else if (finalStartDate != null && finalEndDate != null) {
            const diffMin = Math.max(0, Math.floor((finalEndDate - finalStartDate) / 60));
            finalAllottedTime = formatHHMM(diffMin);
        }

        // Helper validasi Project & Quotation (meniru logika existing)
        const ensureProject = async (project_id) => {
            const row = await Project.findOne({ where: { project_id } });
            if (!row) throw new Error("Project tidak ditemukan");
            return row;
        };
        const ensurePQ = async (pq_id) => {
            const row = await ProjectQuotation.findOne({ where: { pq_id } });
            if (!row) throw new Error("Quotation tidak ditemukan");
            return row;
        };

        // === UPDATE ===
        if (body?.task_id) {
            const task = await Task.findOne({ where: { task_id: body.task_id } });
            if (!task) {
                return NextResponse.json({ error: "Task tidak ditemukan" }, { status: 404 });
            }

            // Validasi bila field terkait dikirim
            if (body.project_id != null) await ensureProject(body.project_id);
            let quotationNumberToSave = undefined;
            if (body.quotation_number != null) {
                const pq = await ensurePQ(body.quotation_number); // body.quotation_number = pq_id
                quotationNumberToSave = pq.quotation_number;      // simpan string nomor quotation
            }

            const updatePayload = {
                // isi hanya bila dikirim, agar tidak mengosongkan tanpa sengaja
                ...(body.title != null && { title: body.title }),
                ...(body.project_id != null && { project_id: body.project_id }),
                ...(quotationNumberToSave != null && { quotation_number: quotationNumberToSave }),
                ...(body.po_number != null && { po_number: body.po_number }),
                ...(body.description != null && { description: body.description }),
                ...(finalStartDate !== null && { start_date: finalStartDate }),
                ...(finalEndDate !== null && { end_date: finalEndDate }),
                ...(finalAllottedTime !== null && { allotted_time: finalAllottedTime }),
                updated: nowUnix,
                updated_by: currentUser.user_id,
            };

            await Task.update(updatePayload, { where: { task_id: body.task_id } });
            const updatedTask = await Task.findOne({ where: { task_id: body.task_id } });
            return NextResponse.json({ message: "Task berhasil diubah", task: updatedTask }, { status: 200 });
        }


        const newTask = await Task.create({
            title: body.title,
            project_id: projectData.project_id,
            pq_id: body.pq_id,
            po_id: body.po_id,
            description: body.description,
            start_date: finalStartDate,
            end_date: finalEndDate,
            allotted_time: finalAllottedTime,
            todo: "new",
            created: nowUnix,
            created_by: currentUser.user_id,
            updated: nowUnix,
            updated_by: currentUser.user_id,
        });

        return NextResponse.json({ message: "Task berhasil ditambahkan", task: newTask }, { status: 201 });
    } catch (error) {
        console.error("Error adding Task:", error);
        return NextResponse.json({
            error: error.original?.sqlMessage || "Terjadi kesalahan pada server saat menambahkan task."
        }, { status: 500 });
    }
})