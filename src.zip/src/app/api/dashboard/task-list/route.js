// src/app/api/dashboard/task-list/route.js
export const dynamic = 'force-dynamic';
export const revalidate = 0;

import { NextResponse } from "next/server";
import { Task, User, Project, TaskAssignment } from "@/database/models";
import { Op } from 'sequelize';
import { withActive } from "@/utils/session";
import dayjs from 'dayjs';

// === Status (baru + legacy utk kompatibilitas)
const TODO_SET = [
    "new", "in_progress", "revision",
    "need_review_hod", "revise_hod",
    "need_review_ae", "revise_account", "approved_ae",
    "completed",
    // legacy, dibiarkan agar data lama tetap terlihat
    "pending", "cancel", "todo", "review", "done",
];

export const GET = withActive(async function GET_HANDLER(req, { params }, currentUser) {
    try {
        const { searchParams } = new URL(req.url);
        const userId = currentUser.user_id;

        // ====== Query params umum (dipertahankan longgar) ======
        const q = (searchParams.get("q") || "").trim();
        const projectId = Number(searchParams.get("projectId"));
        const category = (searchParams.get("category") || "").toLowerCase();
        const orderBy = (searchParams.get("orderBy") || "end_date").toLowerCase(); // end_date|created|updated
        const orderDir = (searchParams.get("orderDir") || "ASC").toUpperCase();    // ASC|DESC

        // ====== WHERE TASK ======
        const whereTask = {};
        const andFilters = [];

        // filter status/todo default
        andFilters.push({ todo: { [Op.in]: TODO_SET } });

        // filter keyword di title (ringan)
        if (q) {
            andFilters.push({ title: { [Op.substring]: q } });
        }

        // filter project
        if (Number.isFinite(projectId)) {
            andFilters.push({ project_id: projectId });
        }

        // kategori ringkas untuk dashboard
        const now = dayjs();
        const todayStart = now.startOf("day").unix();
        const todayEnd = now.endOf("day").unix();
        const thisWeekEnd = now.endOf("week").unix();

        switch (category) {
            case "due_today":
                andFilters.push({ due_date: { [Op.gte]: todayStart, [Op.lte]: todayEnd } });
                break;
            case "overdue":
                andFilters.push({ due_date: { [Op.lt]: todayStart } });
                break;
            case "this_week":
                andFilters.push({ due_date: { [Op.gte]: todayStart, [Op.lte]: thisWeekEnd } });
                break;
            case "need_review_hod":
                andFilters.push({ todo: "need_review_hod" });
                break;
            case "need_review_ae":
                andFilters.push({ todo: "need_review_ae" });
                break;
            case "completed":
                andFilters.push({ todo: "completed" });
                break;
            default:
                // no-op
                break;
        }

        if (andFilters.length) {
            whereTask[Op.and] = andFilters;
        }

        // ====== INCLUDE (assigned ke user login, seperti sebelumnya) ======
        // Catatan: kita pakai through TaskAssignment agar tetap 1:1 dengan gaya lama.
        const assignedInclude = [{
            model: User,
            as: "AssignedUser",
            attributes: ["user_id", "fullname", "email"],
            through: { attributes: [] },
            where: { user_id: userId },
            required: true,
        }, {
            model: Project,
            as: "Project",
            attributes: ["project_id", "title"],
            required: false,
        }];

        // ====== QUERY ======
        const taskData = await Task.findAll({
            where: whereTask,
            include: assignedInclude,
            order: (() => {
                if (orderBy === "created") return [["created", orderDir]];
                if (orderBy === "updated") return [["updated", orderDir]];
                return [["end_date", orderDir], ["created", "ASC"]];
            })(),
            subQuery: false,
        });

        // Response mengikuti pola lama
        return NextResponse.json({ task: taskData }, { status: 200 });
    } catch (error) {
        console.error("Error fetching Tasks:", error);
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
});
