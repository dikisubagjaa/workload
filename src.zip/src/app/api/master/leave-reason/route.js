// src/app/api/master/leave-reason/route.js
export const dynamic = 'force-dynamic';
export const revalidate = 0;

import { NextResponse } from 'next/server';
import db from '@/database/models';
import { withActive } from '@/utils/session';

const { LeaveConfig, Sequelize } = db;
const { Op } = Sequelize;

export const GET = withActive(async function GET_HANDLER(req) {
  try {
    const { searchParams } = new URL(req.url);

    const status = (searchParams.get('status') || 'active').toLowerCase();
    const q = (searchParams.get('q') || '').trim();

    const page = Math.max(parseInt(searchParams.get('page') || '1', 10), 1);
    const limit = Math.max(parseInt(searchParams.get('limit') || '50', 10), 1);
    const offset = (page - 1) * limit;

    const where = {};

    // filter status berdasarkan kolom deleted
    if (status === 'active') {
      // belum pernah dihapus
      where.deleted = { [Op.or]: [null, 0] };
    } else if (status === 'deleted') {
      // sudah dihapus
      where.deleted = { [Op.ne]: null };
    }
    // status === 'all' => tanpa filter deleted

    if (q) {
      where.title = { [Op.like]: `%${q}%` };
    }

    const { rows, count } = await LeaveConfig.findAndCountAll({
      where,
      order: [['title', 'ASC']],
      limit,
      offset,
      attributes: [
        'lconfig_id',
        'title',
        'total',
        'max_sequence',
        'created',
        'created_by',
        'updated',
        'updated_by',
        'deleted',
        'deleted_by',
      ],
    });

    return NextResponse.json(
      {
        ok: true,
        success: true, // untuk jaga kompatibilitas FE lama
        data: rows,
        meta: {
          page,
          limit,
          total: count,
        },
      },
      { status: 200 }
    );
  } catch (err) {
    console.error('GET /api/master/leave-reason error:', err);
    return NextResponse.json(
      { error: err?.message || 'Failed' },
      { status: 500 }
    );
  }
});
