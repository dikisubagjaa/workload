import { Page, sequelize } from "@/database/models/website";
import dayjs from "dayjs";
import utc from "dayjs/plugin/utc";
import { getUnixTimestampUTC } from "@/utils/dateHelpers";
import { withAuth } from "@/utils/session";
dayjs.extend(utc);

// Fungsi untuk hapus tag HTML
function stripHTML(html) {
    return html ? html.replace(/<[^>]*>?/gm, "").trim() : "";
}

// GET /api/website/page
export async function GET() {
    try {
        await sequelize.sync();
        const pages = await Page.findAll({
            order: [["page_id", "DESC"]],
            raw: true 
        });

        const formattedPages = pages.map(page => ({
            ...page,
            description: stripHTML(page.description),
            created: page.created
                ? dayjs.unix(page.created).format("YYYY-MM-DD HH:mm:ss")
                : null
        }));

        return Response.json(formattedPages);
    } catch (error) {
        console.error("❌ Error in GET /api/website/page:", error);
        return new Response(
            JSON.stringify({ message: "Failed to fetch pages", error: error.message }),
            { status: 500 }
        );
    }
}

// POST /api/website/page
export const POST = withAuth(async function POST_HANDLER(req, context, currentUser) {
    try {
        const nowUnix = getUnixTimestampUTC();
        const body = await req.json();

        const newPage = await Page.create({
            ...body,
            created: nowUnix,
            created_by: currentUser.user_id,
            updated: nowUnix,
            updated_by: currentUser.user_id,
        });

        // Bersihkan & format data yang baru dibuat
        const cleanPage = {
            ...newPage.get({ plain: true }),
            description: stripHTML(newPage.description),
            created: dayjs.unix(newPage.created).format("DD MMM YYYY")
        };

        return Response.json(cleanPage, { status: 201 });
    } catch (error) {
        console.error("❌ Error in POST /api/website/page:", error);
        return new Response(
            JSON.stringify({ message: "Failed to create page", error: error.message }),
            { status: 500 }
        );
    }
});
