export const dynamic = 'force-dynamic';
export const revalidate = 0;

import { NextResponse } from 'next/server';
import { Task, TaskAttachment } from "@/database/models";
import { getUnixTimestampUTC } from "@/utils/dateHelpers";
import { withAuth } from "@/utils/session";

export const DELETE = withAuth(async function DELETE_HANDLER(req, { params }, currentUser) {
    try {
        const { taskId, attachmentId } = params;
        console.error("taskId d: ", taskId);

        if (!attachmentId) {
            return NextResponse.json({ error: "Attachment ID is required." }, { status: 400 });
        }

        const nowUnix = getUnixTimestampUTC();
        const updatedRows = await TaskAttachment.update(
            {
                updated: nowUnix,
                updated_by: currentUser.user_id,
                deleted: nowUnix,
                deleted_by: currentUser.user_id
            },
            {
                where: {
                    attachment_id: attachmentId,
                    task_id: taskId,
                    deleted: null
                }
            }
        );

        if (updatedRows[0] === 0) {
            return NextResponse.json({ error: "Attachment not found or already deleted." }, { status: 404 });
        }

        return NextResponse.json({ message: "Attachment successfully soft-deleted." }, { status: 200 });

    } catch (error) {
        console.error("Error soft-deleting attachment:", error);
        return NextResponse.json({
            error: error.original?.sqlMessage || error.message || "An error occurred on the server while soft-deleting the attachment."
        }, { status: 500 });
    }
});