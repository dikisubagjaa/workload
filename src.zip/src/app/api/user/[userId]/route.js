// src/app/api/user/[userId]/route.js
import { NextResponse } from "next/server";
import models from "@/database/models";
const { User, UserEmployment, sequelize } = models;
import { withAuth } from "@/utils/session";
import { notify as notifyUser } from "@/utils/notifier";
import dayjs from "dayjs";

// Field user yang diizinkan (gabungan kebutuhan /profile & /user pada UI)
const ALLOWED_FIELDS = [
  // General / Personal / Statutory / Emergency (dipakai juga oleh UI)
  "job_position", "email", "phone",
  "status",
  "fullname", "birthdate", "marital_status", "nationality",
  "address", "address_on_identity",
  "identity_number", "identity_type", "npwp_number",
  "tax_start_date",
  "bank_code", "bank_account_number", "beneficiary_name", "currency",
  "bpjs_tk_number", "bpjs_tk_reg_date", "bpjs_tk_term_date",
  "bpjs_kes_number", "bpjs_kes_reg_date", "bpjs_kes_term_date",
  "pension_number",
  "emergency_fullname", "emergency_relationship",
  "emergency_contact", "emergency_address",
  "department_id",
  "user_role",
  "status",
  "user_type",
  "attendance_type",
  "absent_type",
  "is_hod",
  "is_hrd",
  "is_ae",
  "is_superadmin",
  "is_operational_director",
  "is_timesheet",
  "absent_type",
  "join_date",
  "contract_number", "start_date", "end_date",
  "duration_months", "salary_json",
  "evaluation_notes", "recommended_status",
  "notes",
];

// helper: ambil hanya kolom yang ada di model
function filterAttrs(payload, rawAttrs) {
  return Object.fromEntries(
    Object.entries(payload).filter(([k]) => rawAttrs?.[k])
  );
}
function toStrBoolEnum(v) {
  return String(v) === "true" || v === true ? "true" : "false";
}
// normalisasi tanggal (YYYY-MM-DD string → simpan apa adanya; UNIX → integer; Date → ISO)
function normDateLike(v) {
  if (v === null || v === undefined || v === "") return null;
  if (typeof v === "number") return v; // anggap UNIX seconds sudah benar dari FE
  if (typeof v === "string") return v; // untuk kolom yang string date (tax_start_date, dll)
  if (v instanceof Date) return dayjs(v).format("YYYY-MM-DD");
  return v;
}

export const PUT = withAuth(async (req, { params }, currentUser) => {
  // ==== Authorization: hanya superadmin yang bebas edit siapa pun ====
  const role = (currentUser?.user_role || currentUser?.role || "").toLowerCase();
  const isSuperadmin = currentUser?.is_superadmin === "true";
  if (!isSuperadmin) {
    return NextResponse.json({ error: "Forbidden: superadmin only." }, { status: 403 });
  }

  const userId = Number(params?.userId);
  if (!Number.isInteger(userId)) {
    return NextResponse.json({ error: "Invalid user id" }, { status: 400 });
  }

  let body;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON body" }, { status: 400 });
  }

  const t = await sequelize.transaction();
  try {
    const user = await User.findOne({ where: { user_id: userId }, transaction: t });
    if (!user) {
      await t.rollback();
      return NextResponse.json({ error: "User not found" }, { status: 404 });
    }

    const userAttrs = User?.rawAttributes || {};
    const prevStatus = user.status;

    // ==== bangun payload update user (filter kolom yang valid) ====
    const incoming = {};
    for (const k of ALLOWED_FIELDS) {
      if (Object.prototype.hasOwnProperty.call(body, k)) {
        incoming[k] = body[k];
      }
    }

    // normalisasi beberapa kolom
    if (incoming.is_timesheet !== undefined) incoming.is_timesheet = toStrBoolEnum(incoming.is_timesheet);
    if (incoming.is_hod !== undefined) incoming.is_hod = toStrBoolEnum(incoming.is_hod);
    if (incoming.is_hrd !== undefined) incoming.is_hrd = toStrBoolEnum(incoming.is_hrd);
    if (incoming.is_superadmin !== undefined) incoming.is_superadmin = toStrBoolEnum(incoming.is_superadmin);
    if (incoming.is_ae !== undefined) incoming.is_ae = toStrBoolEnum(incoming.is_ae);
    if (incoming.is_operational_director !== undefined) incoming.is_operational_director = toStrBoolEnum(incoming.is_operational_director);
    if (incoming.join_date !== undefined && incoming.join_date !== null) {
      incoming.join_date = Number(incoming.join_date);
    }
    // string tanggal (statutory) biarkan apa adanya; employment dates UNIX

    // Jika status menjadi active dan join_date kosong → isi sekarang
    if (incoming.status === "active" && !user.join_date && !incoming.join_date) {
      incoming.join_date = dayjs().unix();
    }

    // Mapping optional alias director_user_id → id_director (kalau ada perubahan)
    if (incoming.director_user_id !== undefined && userAttrs["id_director"]) {
      incoming.id_director = incoming.director_user_id;
      delete incoming.director_user_id;
    }

    // Akhirnya: filter terhadap kolom model User
    const safeUserUpdate = filterAttrs(incoming, userAttrs);

    // Update User
    if (Object.keys(safeUserUpdate).length > 0) {
      // normalize any "date-like string" fields that are string on user table
      if (safeUserUpdate.birthdate !== undefined) {
        safeUserUpdate.birthdate = normDateLike(safeUserUpdate.birthdate);
      }
      if (safeUserUpdate.tax_start_date !== undefined) {
        safeUserUpdate.tax_start_date = normDateLike(safeUserUpdate.tax_start_date);
      }
      // bpjs_kes/tk dates, etc
      for (const k of [
        "bpjs_tk_reg_date", "bpjs_tk_term_date",
        "bpjs_kes_reg_date", "bpjs_kes_term_date",
      ]) {
        if (safeUserUpdate[k] !== undefined) {
          safeUserUpdate[k] = normDateLike(safeUserUpdate[k]);
        }
      }

      await user.update(safeUserUpdate, { transaction: t });
    }

    // ==== Employment handling ====
    const empAttrs = UserEmployment?.rawAttributes || {};
    const nowUnix = dayjs().unix();

    // ambil tipe user_type terkini (dari input atau dari DB)
    const userType = (incoming.user_type ?? user.user_type) || "staff";

    // cari employment aktif (deleted IS NULL)
    let employment = await UserEmployment.findOne({
      where: { user_id: userId, deleted: null },
      transaction: t,
    });

    // jika belum ada → buat
    if (!employment) {
      const empPayload = filterAttrs({
        user_id: userId,
        type: userType,
        start_date: body.start_date ?? user.join_date ?? nowUnix,
        contract_number: body.contract_number ?? null,
        end_date: body.end_date ?? null,
        duration_months: body.duration_months ?? null,
        salary_json: body.salary_json ?? null,
        evaluation_notes: body.evaluation_notes ?? null,
        recommended_status: body.recommended_status ?? null,
        notes: body.notes ?? null,
        created: nowUnix,
        created_by: currentUser?.user_id ?? 1,
        updated: nowUnix,
      }, empAttrs);

      await UserEmployment.create(empPayload, { transaction: t });
    } else {
      // jika tipe berubah, tutup yang lama dan buat baru
      if (employment.type !== userType) {
        employment.end_date = employment.end_date || nowUnix;
        employment.deleted = employment.deleted ?? nowUnix;
        employment.updated = nowUnix;
        await employment.save({ transaction: t });

        const newEmp = filterAttrs({
          user_id: userId,
          type: userType,
          start_date: body.start_date ?? user.join_date ?? nowUnix,
          contract_number: body.contract_number ?? null,
          end_date: body.end_date ?? null,
          duration_months: body.duration_months ?? null,
          salary_json: body.salary_json ?? null,
          evaluation_notes: body.evaluation_notes ?? null,
          recommended_status: body.recommended_status ?? null,
          notes: body.notes ?? null,
          created: nowUnix,
          created_by: currentUser?.user_id ?? 1,
          updated: nowUnix,
        }, empAttrs);

        await UserEmployment.create(newEmp, { transaction: t });
      } else {
        // tipe sama → update kolom sesuai tipe
        const empUpdate = {};

        // UNIX seconds untuk kolom tanggal employment
        if (body.start_date !== undefined) empUpdate.start_date = body.start_date ? Number(body.start_date) : null;
        if (body.end_date !== undefined) empUpdate.end_date = body.end_date ? Number(body.end_date) : null;

        if (userType === "contract") {
          if (body.contract_number !== undefined) empUpdate.contract_number = body.contract_number ?? null;
          if (body.duration_months !== undefined) empUpdate.duration_months = body.duration_months ?? null;
          if (body.salary_json !== undefined) empUpdate.salary_json = body.salary_json ?? null;
        } else if (userType === "probation") {
          if (body.evaluation_notes !== undefined) empUpdate.evaluation_notes = body.evaluation_notes ?? null;
          if (body.recommended_status !== undefined) empUpdate.recommended_status = body.recommended_status ?? null;
        }
        if (body.notes !== undefined) empUpdate.notes = body.notes ?? null;

        if (Object.keys(empUpdate).length > 0) {
          const safeEmpUpdate = filterAttrs({ ...empUpdate, updated: nowUnix }, empAttrs);
          await employment.update(safeEmpUpdate, { transaction: t });
        }
      }
    }

    // ==== Notif saat status berubah menjadi active ====
    const newStatus = incoming.status ?? user.status;
    if (prevStatus !== "active" && newStatus === "active") {
      try {
        await notifyUser({
          userId: user.user_id, // WAJIB
          type: "user_status_changed",
          title: "Account status updated",
          description: `Hello ${user.fullname || user.email}, your account is now ACTIVE.`,
          email: true,
          meta: {
            user_id: user.user_id,
            status_from: prevStatus,
            status_to: newStatus,
          },
        });
      } catch (e) {
        // jangan gagalkan proses jika notifikasi gagal
        console.warn("Failed to send status change notification:", e?.message || e);
      }
    }

    await t.commit();
    return NextResponse.json({ message: "User updated", user: user.toJSON() }, { status: 200 });
  } catch (err) {
    await t.rollback();
    console.error("PUT /user/[userId] error:", err);
    return NextResponse.json({ error: "Failed to update user." }, { status: 500 });
  }
});
