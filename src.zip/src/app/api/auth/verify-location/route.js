import { NextResponse } from "next/server";
import db from "@/database/models";
import { withAuth } from "@/utils/session";
import { getUnixTimestampUTC } from "@/utils/dateHelpers";

const { UserLocation } = db;

function getClientIp(req) {
  const xff = req.headers.get("x-forwarded-for");
  if (xff) return xff.split(",")[0].trim();

  const xri = req.headers.get("x-real-ip");
  if (xri) return xri.trim();

  const cf = req.headers.get("cf-connecting-ip");
  if (cf) return cf.trim();

  return null;
}

export const POST = withAuth(async function POST_HANDLER(req, { params }, currentUser) {
  try {
    const { latitude, longitude } = await req.json();

    // jangan pakai !latitude karena 0 dianggap false
    if (latitude == null || longitude == null) {
      return NextResponse.json(
        { error: "Latitude and longitude are required." },
        { status: 400 }
      );
    }

    const ip_address = getClientIp(req);
    const device_info = req.headers.get("user-agent") || null;
    const nowUnix = getUnixTimestampUTC();

    await UserLocation.create({
      user_id: currentUser.user_id,
      latitude,
      longitude,
      ip_address,
      device_info,
      created_by: currentUser.user_id, // FIX: jangan kirim object
      created: nowUnix,
    });

    return NextResponse.json({ message: "Location recorded successfully." }, { status: 200 });
  } catch (error) {
    console.error("Error in verify-location API:", error);
    return NextResponse.json(
      { error: error.message || "An error occurred during location verification." },
      { status: 500 }
    );
  }
});
