// src/app/api/calendar/events/route.js
export const dynamic = 'force-dynamic';
export const revalidate = 0;

import { NextResponse } from 'next/server';
import db from '@/database/models';
import dayjs from 'dayjs';
import utc from 'dayjs/plugin/utc';
import timezone from 'dayjs/plugin/timezone';
import customParseFormat from 'dayjs/plugin/customParseFormat';
import { withActive } from '@/utils/session';

dayjs.extend(utc);
dayjs.extend(timezone);
dayjs.extend(customParseFormat);

const DEFAULT_TZ = process.env.NEXT_PUBLIC_APP_TIMEZONE || 'Asia/Jakarta';
dayjs.tz.setDefault(DEFAULT_TZ);

const { Sequelize, CalendarEvent } = db;
const { Op } = Sequelize;

/* ===== Helpers: sama gaya dengan API lain ===== */
const nowUnix = () => dayjs().unix(); // simple & konsisten

function toYMD(s) {
    const raw = String(s || '').trim();
    const d = dayjs(raw, 'YYYY-MM-DD', true);
    return d.isValid() ? d.format('YYYY-MM-DD') : null;
}

function toUnixStart(ymd) {
    if (!ymd) return null;
    const d = dayjs.tz(ymd, 'YYYY-MM-DD', DEFAULT_TZ);
    return d.isValid() ? d.startOf('day').unix() : null;
}

function toUnixEnd(ymd) {
    if (!ymd) return null;
    const d = dayjs.tz(ymd, 'YYYY-MM-DD', DEFAULT_TZ);
    return d.isValid() ? d.endOf('day').unix() : null;
}

function parseIntSafe(v, def, { min = 1, max = 1000 } = {}) {
    const n = Number.parseInt(String(v ?? ''), 10);
    if (Number.isFinite(n)) return Math.max(min, Math.min(max, n));
    return def;
}

function parseSortBy(raw) {
    const allowed = new Set(['start_at', 'end_at', 'created', 'updated']);
    const key = String(raw || '').trim().toLowerCase();
    return allowed.has(key) ? key : 'start_at';
}

function parseSortDir(raw) {
    const dir = String(raw || '').trim().toLowerCase();
    return dir === 'desc' ? 'DESC' : 'ASC';
}

/* ===== GET handler (gaya konsisten) ===== */
export const GET = withActive(async function GET_HANDLER(req, context, currentUser) {
    try {
        const url = new URL(req.url);
        const sp = url.searchParams;

        // Query params
        const fromYmd = toYMD(sp.get('from'));
        const toYmd = toYMD(sp.get('to'));
        const fromUnix = toUnixStart(fromYmd);
        const toUnix = toUnixEnd(toYmd);

        const limit = parseIntSafe(sp.get('limit'), 100, { min: 1, max: 1000 });
        const sortBy = parseSortBy(sp.get('sortBy'));
        const sortDir = parseSortDir(sp.get('sortDir'));

        // WHERE: ambil event yang overlap dengan rentang [from..to] bila keduanya ada.
        // - kalau hanya 'from': start_at >= from
        // - kalau hanya 'to'  : start_at <= to
        const where = {};
        if (fromUnix != null && toUnix != null) {
            // overlap window: (start <= to) AND (end >= from)
            where[Op.and] = [
                { start_at: { [Op.lte]: toUnix } },
                { end_at: { [Op.gte]: fromUnix } },
            ];
        } else if (fromUnix != null) {
            where.start_at = { [Op.gte]: fromUnix };
        } else if (toUnix != null) {
            where.start_at = { [Op.lte]: toUnix };
        }

        const rows = await CalendarEvent.findAll({
            where,
            order: [[sortBy, sortDir]],
            limit,
        });

        return NextResponse.json({
            ok: true,
            data: rows,
            meta: {
                now_unix: nowUnix(),
                from: fromYmd,
                to: toYmd,
                limit,
                sortBy,
                sortDir,
            },
        });
    } catch (err) {
        return NextResponse.json(
            { ok: false, error: 'INTERNAL_ERROR', message: err?.message || 'Unknown error' },
            { status: 500 }
        );
    }
});

// ---------- POST /api/calendar/events ----------
export const POST = withActive(async function GET_HANDLER(req, context, currentUser) {

    let body;
    try {
        body = await req.json();
    } catch {
        return NextResponse.json({ error: 'Invalid JSON' }, { status: 400 });
    }

    const title = String(body?.title || '').trim();
    const description = body?.description ? String(body.description) : null;
    const start_at = Number(body?.start_at);
    const end_at = Number(body?.end_at);
    const color = body?.color ? String(body.color) : null;
    const is_public = typeof body?.is_public === 'boolean' ? body.is_public : false;

    if (!title || title.length > 150) {
        return NextResponse.json({ error: 'Title is required (1..150 chars).' }, { status: 400 });
    }
    if (!Number.isInteger(start_at) || !Number.isInteger(end_at)) {
        return NextResponse.json({ error: 'start_at and end_at must be unix seconds (integer).' }, { status: 400 });
    }
    if (end_at < start_at) {
        return NextResponse.json({ error: 'end_at must be greater than or equal to start_at.' }, { status: 400 });
    }

    const created = await CalendarEvent.create({
        user_id: currentUser.user_id,
        title: title,
        description: description,
        start_at: start_at,
        end_at: end_at,
        color: color,
        is_public: is_public,
        created_by: currentUser.user_id,
        updated_by: currentUser.user_id,
        created: nowUnix,
        updated: nowUnix,
    });

    return NextResponse.json({ ok: true, data: created }, { status: 201 });
});
