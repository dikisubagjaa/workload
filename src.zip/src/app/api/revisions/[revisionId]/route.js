export const dynamic = 'force-dynamic';
export const revalidate = 0;

import { NextResponse } from "next/server";
import db from "@/database/models";
import dayjs from "dayjs";
import { withAuth } from "@/utils/session";

const { TaskRevision } = db;

export const PATCH = withAuth(async function PATCH_HANDLER(req, { params }, currentUser) {
  try {
    const { revisionId } = params;
    const body = await req.json();
    const now = dayjs().unix();

    const rev = await TaskRevision.findByPk(revisionId);
    if (!rev) return NextResponse.json({ error: "Revision not found." }, { status: 404 });

    const fields = {
      updated: now,
      updated_by: currentUser?.user_id ?? null,
    };
    if (body.status) {
      const s = String(body.status).toLowerCase();
      if (!["in_review", "revise", "done"].includes(s)) {
        return NextResponse.json({ error: "Invalid status." }, { status: 400 });
      }
      fields.status = s;
      if (s === "done") fields.done_at = now;
    }
    if (typeof body.note === "string") fields.note = body.note;

    await TaskRevision.update(fields, { where: { revision_id: revisionId } });

    const updated = await TaskRevision.findByPk(revisionId);
    return NextResponse.json({ message: "Revision updated.", revision: updated.toJSON() }, { status: 200 });
  } catch (err) {
    console.error("PATCH revision error:", err);
    return NextResponse.json({ error: err.message || "Failed to update revision." }, { status: 500 });
  }
});
