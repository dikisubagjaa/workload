"use client";

import TableProjectList from "@/components/table/TableProjectList";

export default function ProjectList({ title = "Ongoing Projects", projects, loading, setModalProject }) {
  console.log("projects", projects);
  return (
    <section className="mb-7">
      <p className="fc-base text-lg mb-4">{title}</p>
      <TableProjectList
        dataSource={projects}
        loading={loading}
        setModalProject={setModalProject}
      />
    </section>
  );
}
