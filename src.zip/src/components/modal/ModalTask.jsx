// src/components/modal/ModalTask.jsx
"use client";

import Image from 'next/image';
import { Form, Input, Modal, Button, Spin, Select } from 'antd';
import { useEffect, useState, useCallback, useRef } from 'react';
import { useSearchParams, useRouter } from 'next/navigation';
import { LoadingOutlined } from '@ant-design/icons';

import TaskDetailForm from '../task/TaskDetailForm';
import TaskDescription from '../task/TaskDescription';
import TaskAttachments from '../task/TaskAttachments';
import SubtaskSection from '../task/SubtaskSection';
import TaskSidebar from '../task/TaskSidebar';
import TaskActivity from '../task/TaskActivity';

import { useTaskData } from '@/hooks/useTaskData';
import { useTaskMutations } from '@/hooks/useTaskMutations';

import { useSession } from "next-auth/react";
import dayjs from 'dayjs';

// Tahap 2: util fokus item (sessionStorage)
import { consumeTaskFocusItem } from '@/utils/focusItemStore';
import { asset } from '@/utils/url';

const colorMap = { low: '#EC221F', medium: '#E8B931', high: '#0FA3B1' };
export const renderColorProgress = (progress) => {
    const range = progress < 31 ? 'low' : (progress < 60 ? 'medium' : 'high');
    return colorMap[range];
};

export default function ModalTask({ modalTask, onCancel }) {
    const searchParams = useSearchParams();
    const router = useRouter();

    const modul = searchParams.get('modul');
    const openmodal = searchParams.get('openmodal');
    const taskId = searchParams.get('task'); // string saat edit, null saat create
    const legacyFocusItem = searchParams.get('item'); // legacy param (akan dibersihkan)

    const { data: session } = useSession();
    const currentUserFrontend = session?.user;

    const activityRef = useRef(null);
    const [form] = Form.useForm();

    const {
        taskData,
        projectOptions,
        quotationOptions,
        poOptions,
        departmentOptions,
        userOptions,
        listTaskAttachment,
        listSubTask,
        listSubTaskItem,
        loadingData,
        loadingProjects,
        loadingQuotations,
        loadingPOs,
        loadingDepartments,
        loadingUsers,
        activityLog,
        loadingActivity,
        fetchDetailTask,
        fetchDepartment,
        fetchUsers,
        fetchQuotation,
        fetchPo,
        fetchProject,
        fetchActivityLog,
        setListTaskAttachment,
        setListSubTask,
        setListSubTaskItem,
        setTaskData,
        setActivityLog,
        getFileDisplay
    } = useTaskData(taskId, form);

    const getDepartmentLabel = useCallback((id) => {
        const num = Number(id);
        const opts = Array.isArray(departmentOptions) ? departmentOptions : [];
        const found = opts.find(
            o => Number(o?.value) === num || Number(o?.department_id) === num
        );
        return found?.label || found?.title || String(num);
    }, [departmentOptions]);

    const {
        loadingMutation,
        saveTask,
        updateTask,
        addSubTask,
        addSubTaskItem,
        updateTaskSubtaskItem,
        handleUploadTask,
        deleteTaskAttachment,
        addComment,
        uploadSubtaskItemAttachment,
        onPromoteStar,
        updateSubTask,
        deleteSubTask,
        deleteSubtaskItemAttachment,
    } = useTaskMutations(
        taskId,
        setListTaskAttachment,
        setListSubTask,
        setListSubTaskItem,
        setTaskData,
        setActivityLog,
        fetchActivityLog,
        getDepartmentLabel
    );

    const isEditMode = (modul === 'task' && openmodal === 'true' && !!taskId);
    const canEdit = isEditMode && taskData?.created_by === currentUserFrontend?.user_id;

    const sideBarDisabled = !isEditMode;
    const [isDisabled, setIsDisabled] = useState(isEditMode);
    const [labelSubmit, setLabelSubmit] = useState("Save");
    const [attachmentToComment, setAttachmentToComment] = useState(null);

    // ✅ NEW: target comment untuk subTaskItem
    const [itemToComment, setItemToComment] = useState(null);

    // Tahap 2: fokus item dipegang sebagai state lokal (bukan query)
    const [focusItemId, setFocusItemId] = useState(null);

    useEffect(() => {
        setIsDisabled(isEditMode);
    }, [isEditMode]);


    const setEditFunc = (value) => {
        form.setFieldsValue({ task_id: Number(taskId) || taskId || null });
        setIsDisabled(value);
        setLabelSubmit("Update");
    };

    const handleCloseModal = useCallback(() => {
        onCancel?.();
        form.resetFields();
        setTaskData(null);
        setListTaskAttachment([]);
        setListSubTask([]);
        setListSubTaskItem([]);
        setActivityLog([]);
        setFocusItemId(null);
        setItemToComment(null);
        setAttachmentToComment(null);
    }, [
        onCancel, router, form,
        setTaskData, setListTaskAttachment, setListSubTask, setListSubTaskItem, setActivityLog
    ]);

    const handleSaveTask = async (values) => {
        const result = await saveTask(values);
        const newId = result?.task?.task_id;
        if (newId) {
            onCancel?.();
            setIsDisabled(true);
            router.push(`/dashboard?modul=task&openmodal=true&task=${newId}`);
        }
    };

    useEffect(() => {
        if (!taskId) return;

        if (legacyFocusItem) {
            setFocusItemId(legacyFocusItem);
            router.replace(`/dashboard?modul=task&openmodal=true&task=${taskId}`);
            return;
        }

        const v = consumeTaskFocusItem(taskId);
        if (v) setFocusItemId(v);
    }, [taskId, legacyFocusItem, router]);

    return (
        <Modal
            open={modalTask}
            onCancel={handleCloseModal}
            width={900}
            footer={null}
            maskClosable={false}
            className='custom-modaltask'
        >
            <Spin
                spinning={loadingData || loadingMutation || loadingActivity}
                indicator={<LoadingOutlined style={{ fontSize: 24 }} spin />}
                tip="Loading..."
            >
                <Form form={form} onFinish={handleSaveTask} layout="vertical" className='mb-10'>
                    {/* Header */}
                    <div className="flex items-start flex-col sm:flex-row gap-x-5">
                        <div className='order-last sm:order-first w-full mb-5 sm:mb-0'>
                            <div className="flex items-start gap-3 mb-3">
                                <Form.Item name="task_id" hidden>
                                    <Input type="hidden" />
                                </Form.Item>
                                <Image src={asset('static/images/icon/app_registration.png')} width={50} height={50} className='w-6 mt-2 hidden sm:block' alt="Task Icon" />
                                <div className="flex flex-col w-full">
                                    <div className="w-full">
                                        <Form.Item
                                            name="title"
                                            rules={[{ required: true, message: 'Please input Task Name!' }]}
                                        >
                                            <Input placeholder="Task Name Here" className='text-lg' variant="underlined" disabled={isDisabled} />
                                        </Form.Item>
                                    </div>
                                    <div className="flex items-center gap-3">
                                        <div className="select2-header flex items-center gap-2">
                                            <span className="text-sm me-3">in</span>
                                            <Form.Item
                                                name="projectId"
                                                className='sm:w-44 mb-0'
                                                rules={[{ required: true, message: 'Please select a Project!' }]}
                                            >
                                                {isDisabled == false ? (
                                                    <Select
                                                        showSearch
                                                        placeholder="Select Project"
                                                        className='w-full'
                                                        loading={loadingProjects}
                                                        notFoundContent={loadingProjects ? null : 'No Data'}
                                                        onDropdownVisibleChange={(open) => {
                                                            if (open) fetchProject();
                                                        }}
                                                        onChange={(projectId) => {
                                                            fetchQuotation(projectId);
                                                            form.setFieldsValue({ quotationNumber: undefined, poNumber: undefined });
                                                        }}
                                                        options={projectOptions.map((item) => ({
                                                            label: item.title,
                                                            value: item.project_id,
                                                        }))}
                                                    />
                                                ) : (
                                                    <Select
                                                        showSearch
                                                        className='w-full'
                                                        disabled={isDisabled}
                                                        options={projectOptions.map((item) => ({
                                                            label: item.title,
                                                            value: item.project_id,
                                                        }))}
                                                    />
                                                )}
                                            </Form.Item>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className='order-first sm:order-last sm:pt-5 mb-3 sm:mb-0 w-auto'>
                            <div className='sm:mb-0 sm:text-end'>
                                <h4 className="text-sm mb-1 text-gray-400 whitespace-nowrap">
                                    {taskData?.created ? dayjs.unix(taskData.created).format('DD MMMM YYYY HH:mm:ss') : '-'}
                                </h4>
                                <h3 className="text-sm text-gray-400 whitespace-nowrap">
                                    Created by: <span className="font-semibold fc-base">
                                        {taskData?.creator?.fullname
                                            ? `${taskData?.creator?.fullname ?? ""}`.trim()
                                            : "-"}
                                    </span>
                                </h3>
                            </div>
                        </div>
                    </div>

                    {/* Main Content */}
                    <div className="flex flex-wrap gap-6">
                        <div className="flex-1 order-last sm:order-first">
                            {/* Details */}
                            <div className='mb-10'>
                                <div className="flex items-center gap-2 mb-3">
                                    <Image src={asset('static/images/icon/article.png')} width={50} height={50} alt='' className='w-5 h-5' />
                                    <h3 className="text-base fc-blue">Details</h3>
                                </div>
                                <div className="sm:ps-6">
                                    <TaskDetailForm
                                        isDisabled={isDisabled}
                                        quotationOptions={quotationOptions}
                                        poOptions={poOptions}
                                        loadingQuotations={loadingQuotations}
                                        loadingPOs={loadingPOs}
                                        fetchQuotation={fetchQuotation}
                                        fetchPo={fetchPo}
                                        form={form}
                                    />
                                </div>
                            </div>

                            {/* Description */}
                            <div className="mb-10">
                                <div className="flex items-center gap-2 mb-3">
                                    <Image src={asset('static/images/icon/segment.png')} width={50} height={50} alt='' className='w-5 h-5' />
                                    <h3 className="text-base fc-blue">Description</h3>
                                </div>
                                <div className="sm:ps-6 mb-7">
                                    <TaskDescription
                                        isDisabled={isDisabled}
                                        userOptions={userOptions}
                                        fetchUsers={fetchUsers}
                                    />
                                </div>
                                {!isDisabled && (
                                    <Form.Item>
                                        <div className="flex justify-end gap-3">
                                            <Button size='large' onClick={handleCloseModal} className='px-5'>Cancel</Button>
                                            <Button size='large' htmlType="submit" className="btn-blue px-5" loading={loadingMutation}>
                                                {labelSubmit}
                                            </Button>
                                        </div>
                                    </Form.Item>
                                )}
                            </div>

                            {/* Attachments */}
                            <div className="mb-10">
                                <div className="flex items-center gap-2 mb-3">
                                    <Image src={asset('static/images/icon/article.png')} width={50} height={50} alt='' className='w-5 h-5' />
                                    <h3 className="text-base fc-blue">Supporting Attachments</h3>
                                </div>
                                <div className="sm:ps-6">
                                    <TaskAttachments
                                        onCommentAttachment={(item) => setAttachmentToComment({ ...item })}
                                        taskId={taskId}
                                        listTaskAttachment={listTaskAttachment}
                                        handleUploadTask={handleUploadTask}
                                        sideBarDisabled={sideBarDisabled}
                                        taskTitle={taskData?.title || 'Unknown Task'}
                                        setListTaskAttachment={setListTaskAttachment}
                                        deleteTaskAttachment={deleteTaskAttachment}
                                    />
                                </div>
                            </div>
                        </div>

                        <div className="w-full sm:w-52 mb-10">
                            <TaskSidebar
                                taskId={taskId}
                                priority={taskData?.priority || 'Medium'}
                                priorityOptions={['low', 'medium', 'high', 'urgent']}
                                updateTask={updateTask}
                                departmentOptions={departmentOptions}
                                listDepartment={Array.isArray(taskData?.department) ? taskData.department : []}
                                loadingDepartments={loadingDepartments}
                                fetchDepartment={fetchDepartment}
                                sideBarDisabled={sideBarDisabled}
                                handleUploadTask={handleUploadTask}
                                onEditClick={() => {
                                    if (canEdit) {
                                        setEditFunc(false);
                                    } else {
                                        Modal.warning({
                                            title: "Not Allowed",
                                            content: "Hanya pembuat task yang bisa mengedit.",
                                        });
                                    }
                                }}
                            />
                        </div>
                    </div>

                    <div className="pt-10 border-t border-[#0FA3B1]">
                        {/* Subtasks */}
                        <div className="mb-10">
                            <SubtaskSection
                                taskId={taskId}
                                listSubTask={listSubTask}
                                listSubTaskItem={listSubTaskItem}
                                userOptions={userOptions}
                                loadingUsers={loadingUsers}
                                fetchUsers={fetchUsers}
                                addSubTask={addSubTask}
                                addSubTaskItem={addSubTaskItem}
                                updateTaskSubtaskItem={updateTaskSubtaskItem}
                                uploadSubtaskItemAttachment={uploadSubtaskItemAttachment}
                                onPromoteStar={onPromoteStar}
                                getFileDisplay={getFileDisplay}
                                updateSubTask={updateSubTask}
                                deleteSubTask={deleteSubTask}
                                deleteTaskAttachment={deleteTaskAttachment}
                                focusItemId={focusItemId}
                                onCommentAttachment={(item) => setAttachmentToComment({ ...item })}
                                onCommentItem={(it) => {
                                    setItemToComment(it);
                                    setAttachmentToComment(null);
                                }}
                            />
                        </div>

                        {/* Activity */}
                        <TaskActivity
                            attachmentToComment={attachmentToComment}
                            itemToComment={itemToComment}
                            taskId={taskId}
                            taskTitle={taskData?.title || 'Unknown Task'}
                            activityLog={activityLog}
                            currentUser={currentUserFrontend}
                            addComment={addComment}
                            loadingComments={loadingActivity}
                            fetchActivityLog={fetchActivityLog}
                            userOptions={userOptions}
                            loadingUsers={loadingUsers}
                            fetchUsers={fetchUsers}
                        />
                    </div>
                </Form>
            </Spin>
        </Modal>
    );
}
